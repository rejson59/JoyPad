import { useCallback, useEffect, useRef, useState } from 'react';
import Menu from './components/Menu';
import Hud from './components/Hud';
import { Game, GameSettings, HudState } from './game/game';

type Screen = 'menu' | 'loading' | 'game' | 'error';

const DEFAULT: GameSettings = {
  name: 'Gracz',
  colorIdx: 0,
  difficulty: 1,
  quality: 1,
  laps: 3,
  rain: true,
};

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [settings, setSettings] = useState<GameSettings>(DEFAULT);
  const [hud, setHud] = useState<HudState | null>(null);
  const [runId, setRunId] = useState(0);
  const [error, setError] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [game, setGame] = useState<Game | null>(null);

  useEffect(() => {
    if (screen !== 'loading') return;
    const id = setTimeout(() => {
      if (!containerRef.current) return;
      try {
        const g = new Game(containerRef.current, settings, (h) => setHud(h));
        gameRef.current = g;
        setGame(g);
        g.start();
        setScreen('game');
      } catch (e) {
        console.error(e);
        setError(String(e));
        setScreen('error');
      }
    }, 80);
    return () => clearTimeout(id);
  }, [screen, settings, runId]);

  const stopGame = useCallback(() => {
    gameRef.current?.dispose();
    gameRef.current = null;
    setGame(null);
    setHud(null);
  }, []);

  useEffect(() => () => gameRef.current?.dispose(), []);

  const start = (s: GameSettings) => {
    setSettings(s);
    setScreen('loading');
  };

  const restart = () => {
    stopGame();
    setRunId((r) => r + 1);
    setScreen('loading');
  };

  const toMenu = () => {
    stopGame();
    setScreen('menu');
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#05030c]">
      <div ref={containerRef} className="absolute inset-0" />

      {screen === 'menu' && <Menu initial={settings} onStart={start} />}

      {screen === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#05030c] text-white">
          <div className="font-display text-5xl font-black italic neon-text">
            NEON<span className="text-fuchsia-400 neon-pink"> RUSH</span>
          </div>
          <div className="mt-6 h-1.5 w-64 overflow-hidden rounded-full bg-white/10">
            <div className="h-full w-1/2 animate-pulse rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500" />
          </div>
          <div className="mt-3 text-sm tracking-widest text-white/60">GENEROWANIE MEGAMIASTA…</div>
        </div>
      )}

      {screen === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-6 text-center text-white">
          <div className="text-2xl font-bold">Nie udało się uruchomić WebGL</div>
          <div className="max-w-lg text-sm text-white/60">{error}</div>
          <button onClick={toMenu} className="rounded-xl border border-cyan-300 px-6 py-2">
            Powrót
          </button>
        </div>
      )}

      {screen === 'game' && hud && <Hud hud={hud} game={game} onRestart={restart} onMenu={toMenu} />}
    </div>
  );
}
