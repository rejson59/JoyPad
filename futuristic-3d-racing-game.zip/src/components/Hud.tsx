import { useEffect, useRef, useState } from 'react';
import type { Game, HudState, TouchState } from '../game/game';
import type { ItemType } from '../game/kart';

const ITEMS: Record<ItemType, { icon: string; name: string; color: string }> = {
  boost: { icon: '🔥', name: 'TURBO', color: '#ffb000' },
  triple: { icon: '🔥', name: 'POTRÓJNE TURBO', color: '#ff5a00' },
  rocket: { icon: '🚀', name: 'RAKIETA', color: '#ff3b3b' },
  mine: { icon: '💣', name: 'MINA EMP', color: '#ff2bd6' },
  shield: { icon: '🛡️', name: 'TARCZA', color: '#00f0ff' },
};
const ROLL: ItemType[] = ['boost', 'rocket', 'mine', 'shield', 'triple'];

export function fmt(t: number) {
  if (!t || t <= 0) return '--:--.---';
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const ms = Math.floor((t * 1000) % 1000);
  return `${m}:${String(s).padStart(2, '0')}.${String(ms).padStart(3, '0')}`;
}

function suffix(n: number) {
  return n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th';
}

interface Props {
  hud: HudState;
  game: Game | null;
  onRestart: () => void;
  onMenu: () => void;
}

export default function Hud({ hud, game, onRestart, onMenu }: Props) {
  const mm = useRef<HTMLCanvasElement>(null);
  const [rollIdx, setRollIdx] = useState(0);
  const [msgVisible, setMsgVisible] = useState(false);
  const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

  useEffect(() => {
    if (game && mm.current) game.setMinimap(mm.current);
    return () => game?.setMinimap(null);
  }, [game]);

  useEffect(() => {
    if (!hud.rolling) return;
    const id = setInterval(() => setRollIdx((i) => (i + 1) % ROLL.length), 70);
    return () => clearInterval(id);
  }, [hud.rolling]);

  useEffect(() => {
    if (!hud.messageId) return;
    setMsgVisible(true);
    const id = setTimeout(() => setMsgVisible(false), 1800);
    return () => clearTimeout(id);
  }, [hud.messageId]);

  const setTouch = (k: keyof TouchState, v: boolean) => {
    if (game) game.touch[k] = v;
  };

  const maxGauge = 260;
  const ratio = Math.min(1, hud.speed / maxGauge);
  const arcLen = 2 * Math.PI * 70 * 0.75;
  const driftColors = ['#ffffff', '#3aa8ff', '#ff9a1a', '#c050ff'];
  const shownItem = hud.rolling ? ROLL[rollIdx] : hud.item;
  const placeColor = hud.place === 1 ? '#ffd400' : hud.place === 2 ? '#dfe7f5' : hud.place === 3 ? '#ff9a4a' : '#ffffff';

  return (
    <div className="pointer-events-none absolute inset-0 select-none text-white">
      {/* pozycja + okrążenie */}
      <div className="absolute left-3 top-3 md:left-6 md:top-5">
        <div className="flex items-end gap-1 font-display italic">
          <span className="text-6xl md:text-8xl font-black leading-none" style={{ color: placeColor, textShadow: `0 0 20px ${placeColor}88, 0 4px 0 #000` }}>
            {hud.place}
          </span>
          <span className="mb-2 text-2xl md:text-3xl font-bold" style={{ color: placeColor }}>
            {suffix(hud.place)}
          </span>
          <span className="mb-2 ml-1 text-lg text-white/60">/{hud.total}</span>
        </div>
        <div className="glass mt-2 rounded-xl px-4 py-2 font-display">
          <div className="text-xs text-cyan-300 tracking-widest">OKRĄŻENIE</div>
          <div className="text-2xl font-bold">
            {hud.lap}
            <span className="text-white/50">/{hud.laps}</span>
          </div>
          <div className="mt-1 text-xs text-white/60">CZAS</div>
          <div className="font-mono text-lg">{fmt(hud.raceTime)}</div>
          <div className="text-xs text-white/60">OKRĄŻENIE · NAJLEPSZE</div>
          <div className="font-mono text-sm">
            {fmt(hud.lapTime)} · <span className="text-fuchsia-300">{fmt(hud.bestLap)}</span>
          </div>
        </div>
      </div>

      {/* przedmiot */}
      <div className="absolute left-1/2 top-3 -translate-x-1/2 md:top-5">
        <div
          className="relative flex h-20 w-20 md:h-24 md:w-24 items-center justify-center rounded-2xl border-2 bg-black/50 backdrop-blur"
          style={{
            borderColor: shownItem ? ITEMS[shownItem].color : 'rgba(255,255,255,0.2)',
            boxShadow: shownItem ? `0 0 25px ${ITEMS[shownItem].color}88, inset 0 0 20px ${ITEMS[shownItem].color}44` : 'none',
          }}
        >
          {shownItem ? (
            <span className={`text-5xl md:text-6xl ${hud.rolling ? 'item-roll' : ''}`}>{ITEMS[shownItem].icon}</span>
          ) : (
            <span className="text-3xl text-white/20">?</span>
          )}
          {hud.item === 'triple' && !hud.rolling && (
            <span className="absolute -bottom-2 -right-2 rounded-full bg-orange-500 px-2 font-display text-sm font-bold">×{hud.itemCount}</span>
          )}
        </div>
        {shownItem && !hud.rolling && (
          <div className="mt-1 text-center font-display text-xs tracking-widest" style={{ color: ITEMS[shownItem].color }}>
            {ITEMS[shownItem].name}
            <div className="text-[10px] text-white/50">[E]</div>
          </div>
        )}
      </div>

      {/* minimapa + ranking */}
      <div className="absolute right-3 top-3 flex flex-col items-end gap-2 md:right-6 md:top-5">
        <div className="glass rounded-2xl p-1">
          <canvas ref={mm} width={400} height={300} className="h-[120px] w-[160px] md:h-[165px] md:w-[220px]" />
        </div>
        <div className="glass hidden w-[220px] rounded-xl p-2 text-sm md:block">
          {hud.standings.map((s) => (
            <div
              key={s.name}
              className={`flex items-center gap-2 rounded px-2 py-0.5 ${s.isPlayer ? 'bg-white/15 font-bold' : ''}`}
            >
              <span className="w-5 font-display text-white/60">{s.place}</span>
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color, boxShadow: `0 0 8px ${s.color}` }} />
              <span className="flex-1 truncate">{s.name}</span>
              {s.finished && <span className="text-xs">🏁</span>}
            </div>
          ))}
        </div>
      </div>

      {/* prędkościomierz */}
      <div className="absolute bottom-3 right-3 md:bottom-6 md:right-8">
        <div className="relative h-[150px] w-[150px] md:h-[190px] md:w-[190px]">
          <svg viewBox="0 0 180 180" className="h-full w-full">
            <defs>
              <linearGradient id="spd" x1="0" x2="1">
                <stop offset="0%" stopColor="#00f0ff" />
                <stop offset="70%" stopColor="#b04dff" />
                <stop offset="100%" stopColor="#ff2bd6" />
              </linearGradient>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3" result="b" />
                <feMerge>
                  <feMergeNode in="b" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <circle cx="90" cy="90" r="84" fill="rgba(5,3,15,0.65)" stroke="rgba(120,220,255,0.2)" />
            <circle
              cx="90"
              cy="90"
              r="70"
              fill="none"
              stroke="rgba(255,255,255,0.1)"
              strokeWidth="10"
              strokeDasharray={`${arcLen} 1000`}
              transform="rotate(135 90 90)"
              strokeLinecap="round"
            />
            <circle
              cx="90"
              cy="90"
              r="70"
              fill="none"
              stroke={hud.boosting ? '#ffb000' : 'url(#spd)'}
              strokeWidth="10"
              strokeDasharray={`${arcLen * ratio} 1000`}
              transform="rotate(135 90 90)"
              strokeLinecap="round"
              filter="url(#glow)"
            />
            {Array.from({ length: 14 }).map((_, i) => {
              const a = ((135 + (i / 13) * 270) * Math.PI) / 180;
              return (
                <line
                  key={i}
                  x1={90 + Math.cos(a) * 56}
                  y1={90 + Math.sin(a) * 56}
                  x2={90 + Math.cos(a) * 61}
                  y2={90 + Math.sin(a) * 61}
                  stroke="rgba(255,255,255,0.4)"
                  strokeWidth="2"
                />
              );
            })}
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center font-display">
            <div className="text-4xl md:text-5xl font-black italic" style={{ textShadow: '0 0 12px rgba(0,240,255,0.7)' }}>
              {hud.speed}
            </div>
            <div className="text-xs text-white/60">KM/H</div>
            {hud.boosting && <div className="mt-1 text-xs font-bold text-amber-300 animate-pulse">TURBO</div>}
            {hud.shield && <div className="text-xs font-bold text-cyan-300">🛡️ TARCZA</div>}
          </div>
        </div>
        {hud.drifting && (
          <div className="mt-1 text-center font-display text-sm font-bold italic" style={{ color: driftColors[hud.driftLevel], textShadow: `0 0 10px ${driftColors[hud.driftLevel]}` }}>
            DRIFT {'▮'.repeat(hud.driftLevel + 1)}
            {'▯'.repeat(3 - hud.driftLevel)}
          </div>
        )}
      </div>

      {/* komunikaty */}
      {hud.countdown && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            key={hud.countdown}
            className={`anim-pop font-display font-black italic ${hud.countdown === 'START!' ? 'text-7xl md:text-9xl text-lime-300' : 'text-8xl md:text-[10rem]'}`}
            style={{ textShadow: '0 0 30px currentColor, 0 6px 0 #000' }}
          >
            {hud.countdown}
          </div>
        </div>
      )}
      {hud.phase === 'intro' && (
        <div className="absolute bottom-24 left-0 right-0 text-center">
          <div className="font-display text-2xl md:text-4xl font-black italic neon-text">NEO KRAKÓW CIRCUIT</div>
          <div className="text-white/70">Przygotuj się… wciśnij gaz tuż przed startem!</div>
        </div>
      )}
      {msgVisible && hud.message && hud.message !== 'START!' && (
        <div className="absolute left-0 right-0 top-[28%] text-center">
          <div key={hud.messageId} className="anim-pop inline-block font-display text-3xl md:text-5xl font-black italic neon-pink">
            {hud.message}
          </div>
        </div>
      )}
      {hud.wrongWay && (
        <div className="absolute left-0 right-0 top-[40%] text-center">
          <div className="inline-block animate-pulse rounded-xl border-2 border-red-500 bg-red-600/40 px-8 py-3 font-display text-3xl font-black text-white">
            ⚠ ZŁY KIERUNEK
          </div>
        </div>
      )}

      {/* podpowiedzi */}
      {!isTouch && hud.phase !== 'finished' && (
        <div className="absolute bottom-4 left-6 hidden text-xs text-white/40 md:block">
          SHIFT drift · E przedmiot · C tył · R powrót · M muzyka {hud.musicOn ? '🔊' : '🔇'} · ESC pauza
        </div>
      )}

      {/* sterowanie dotykowe */}
      {isTouch && hud.phase !== 'finished' && (
        <div className="pointer-events-auto">
          <div className="absolute bottom-6 left-4 flex gap-3">
            {(['left', 'right'] as const).map((k) => (
              <button
                key={k}
                onTouchStart={() => setTouch(k, true)}
                onTouchEnd={() => setTouch(k, false)}
                className="h-20 w-20 rounded-full border-2 border-cyan-300/50 bg-black/40 text-3xl active:bg-cyan-400/40"
              >
                {k === 'left' ? '◀' : '▶'}
              </button>
            ))}
          </div>
          <div className="absolute bottom-48 right-4 flex flex-col gap-3 md:bottom-60">
            <button onTouchStart={() => setTouch('item', true)} onTouchEnd={() => setTouch('item', false)} className="h-14 w-14 rounded-full border-2 border-fuchsia-300/60 bg-black/40 text-xl">
              ❓
            </button>
            <button onTouchStart={() => setTouch('drift', true)} onTouchEnd={() => setTouch('drift', false)} className="h-14 w-14 rounded-full border-2 border-amber-300/60 bg-black/40 text-sm font-bold">
              DRIFT
            </button>
            <button onTouchStart={() => setTouch('brake', true)} onTouchEnd={() => setTouch('brake', false)} className="h-14 w-14 rounded-full border-2 border-red-300/60 bg-black/40 text-sm font-bold">
              HAM
            </button>
            <button onTouchStart={() => setTouch('gas', true)} onTouchEnd={() => setTouch('gas', false)} className="h-20 w-20 rounded-full border-2 border-lime-300/60 bg-lime-400/20 text-lg font-bold">
              GAZ
            </button>
          </div>
        </div>
      )}

      {/* pauza */}
      {hud.paused && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="glass w-80 rounded-2xl p-6 text-center">
            <div className="font-display text-4xl font-black italic neon-text">PAUZA</div>
            <div className="mt-6 flex flex-col gap-3">
              <button onClick={() => game?.togglePause()} className="rounded-xl border border-cyan-300 bg-cyan-400/20 py-3 font-display font-bold hover:bg-cyan-400/40">
                WZNÓW
              </button>
              <button onClick={() => game?.toggleMusic()} className="rounded-xl border border-white/20 bg-white/5 py-3 font-display hover:bg-white/10">
                MUZYKA: {hud.musicOn ? 'WŁ' : 'WYŁ'}
              </button>
              <button onClick={onRestart} className="rounded-xl border border-white/20 bg-white/5 py-3 font-display hover:bg-white/10">
                RESTART
              </button>
              <button onClick={onMenu} className="rounded-xl border border-fuchsia-300/50 bg-fuchsia-500/10 py-3 font-display hover:bg-fuchsia-500/30">
                MENU GŁÓWNE
              </button>
            </div>
          </div>
        </div>
      )}

      {/* wyniki */}
      {hud.results && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm">
          <div className="glass w-full max-w-lg rounded-2xl p-6">
            <div className="text-center font-display text-4xl font-black italic neon-text">WYNIKI</div>
            {(() => {
              const me = hud.results!.find((r) => r.isPlayer)!;
              return (
                <div className="mt-2 text-center text-lg">
                  {me.place === 1 ? '🏆 ZWYCIĘSTWO!' : me.place <= 3 ? '🥇 PODIUM!' : 'Następnym razem będzie lepiej!'}
                </div>
              );
            })()}
            <div className="mt-4 space-y-1">
              {hud.results.map((r) => (
                <div
                  key={r.name}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 ${r.isPlayer ? 'bg-cyan-400/20 ring-1 ring-cyan-300' : 'bg-white/5'}`}
                >
                  <span className="w-6 font-display text-xl font-black italic">{r.place}</span>
                  <span className="h-3 w-3 rounded-full" style={{ background: r.color, boxShadow: `0 0 8px ${r.color}` }} />
                  <span className="flex-1 font-semibold">{r.name}</span>
                  <span className="font-mono text-sm text-white/80">
                    {r.finished ? fmt(r.time) : `~${fmt(r.time)}`}
                  </span>
                  <span className="hidden w-24 text-right font-mono text-xs text-fuchsia-300 sm:block">{r.bestLap ? fmt(r.bestLap) : ''}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button onClick={onRestart} className="rounded-xl border border-cyan-300 bg-cyan-400/20 py-3 font-display font-bold hover:bg-cyan-400/40">
                JESZCZE RAZ
              </button>
              <button onClick={onMenu} className="rounded-xl border border-fuchsia-300/60 bg-fuchsia-500/15 py-3 font-display font-bold hover:bg-fuchsia-500/30">
                MENU
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
