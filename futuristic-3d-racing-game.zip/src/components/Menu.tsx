import { useState } from 'react';
import { KART_COLORS, GameSettings } from '../game/game';

interface Props {
  initial: GameSettings;
  onStart: (s: GameSettings) => void;
}

const DIFFS = [
  { label: '100cc', sub: 'Łatwy' },
  { label: '150cc', sub: 'Normalny' },
  { label: '200cc', sub: 'Szalony' },
];
const QUALITY = ['Niska', 'Średnia', 'Ultra'];

export default function Menu({ initial, onStart }: Props) {
  const [s, setS] = useState<GameSettings>(initial);
  const set = <K extends keyof GameSettings>(k: K, v: GameSettings[K]) => setS((p) => ({ ...p, [k]: v }));

  return (
    <div className="absolute inset-0 overflow-y-auto text-white">
      <div
        className="fixed inset-0 bg-cover bg-center scale-105"
        style={{ backgroundImage: 'url(/images/menu-bg.jpg)', filter: 'saturate(1.2) brightness(0.55)' }}
      />
      <div className="fixed inset-0 bg-gradient-to-b from-[#05030c]/40 via-[#05030c]/60 to-[#05030c]" />
      <div className="fixed inset-0 scanlines pointer-events-none opacity-60" />

      <div className="relative z-10 mx-auto flex min-h-full max-w-6xl flex-col items-center px-4 py-8 md:py-12">
        <div className="text-center">
          <div className="text-xs md:text-sm tracking-[0.5em] text-cyan-300/80 mb-2">GRAND PRIX · NEO KRAKÓW 2099</div>
          <h1 className="font-display text-5xl md:text-8xl font-black italic neon-text leading-none">
            NEON<span className="text-fuchsia-400 neon-pink"> RUSH</span>
          </h1>
          <p className="mt-3 text-white/70 max-w-xl mx-auto text-sm md:text-base">
            Futurystyczne wyścigi kartów przez megamiasto przyszłości. Drifty z mini-turbo, rakiety, miny EMP, skocznie i estakady
            nad neonowymi ulicami.
          </p>
        </div>

        <div className="mt-8 grid w-full gap-5 md:grid-cols-[1.2fr_1fr]">
          <div className="glass rounded-2xl p-5 md:p-6">
            <label className="text-xs tracking-widest text-cyan-300">PSEUDONIM KIEROWCY</label>
            <input
              value={s.name}
              maxLength={12}
              onChange={(e) => set('name', e.target.value)}
              className="mt-2 w-full rounded-lg border border-cyan-400/30 bg-black/40 px-4 py-3 font-display text-lg outline-none focus:border-cyan-300 focus:shadow-[0_0_20px_rgba(0,240,255,0.35)]"
            />

            <div className="mt-6 text-xs tracking-widest text-cyan-300">LAKIER BOLIDU</div>
            <div className="mt-3 grid grid-cols-3 gap-3 sm:grid-cols-6">
              {KART_COLORS.map((c, i) => (
                <button
                  key={c.name}
                  onClick={() => set('colorIdx', i)}
                  className={`group relative aspect-square rounded-xl border-2 transition-all ${
                    s.colorIdx === i ? 'scale-110 border-white' : 'border-white/10 hover:border-white/40'
                  }`}
                  style={{
                    background: `radial-gradient(circle at 35% 30%, ${c.css}, #${c.color.toString(16).padStart(6, '0')} 55%, #05030c)`,
                    boxShadow: s.colorIdx === i ? `0 0 25px ${c.css}` : 'none',
                  }}
                  title={c.name}
                />
              ))}
            </div>
            <div className="mt-2 text-sm" style={{ color: KART_COLORS[s.colorIdx].css }}>
              {KART_COLORS[s.colorIdx].name}
            </div>

            <div className="mt-6 text-xs tracking-widest text-cyan-300">KLASA SILNIKA</div>
            <div className="mt-3 grid grid-cols-3 gap-3">
              {DIFFS.map((d, i) => (
                <button
                  key={d.label}
                  onClick={() => set('difficulty', i)}
                  className={`rounded-xl border px-2 py-3 transition-all ${
                    s.difficulty === i
                      ? 'border-fuchsia-400 bg-fuchsia-500/20 shadow-[0_0_20px_rgba(255,43,214,0.35)]'
                      : 'border-white/10 bg-black/30 hover:border-white/30'
                  }`}
                >
                  <div className="font-display text-lg font-bold">{d.label}</div>
                  <div className="text-xs text-white/60">{d.sub}</div>
                </button>
              ))}
            </div>

            <div className="mt-6 grid grid-cols-2 gap-5">
              <div>
                <div className="text-xs tracking-widest text-cyan-300">OKRĄŻENIA</div>
                <div className="mt-3 flex gap-2">
                  {[1, 2, 3, 5].map((l) => (
                    <button
                      key={l}
                      onClick={() => set('laps', l)}
                      className={`flex-1 rounded-lg border py-2 font-display font-bold ${
                        s.laps === l ? 'border-cyan-300 bg-cyan-400/20' : 'border-white/10 bg-black/30'
                      }`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs tracking-widest text-cyan-300">GRAFIKA</div>
                <div className="mt-3 flex gap-2">
                  {QUALITY.map((q, i) => (
                    <button
                      key={q}
                      onClick={() => set('quality', i)}
                      className={`flex-1 rounded-lg border py-2 text-sm font-semibold ${
                        s.quality === i ? 'border-cyan-300 bg-cyan-400/20' : 'border-white/10 bg-black/30'
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => set('rain', !s.rain)}
              className="mt-6 flex w-full items-center justify-between rounded-xl border border-white/10 bg-black/30 px-4 py-3"
            >
              <span>🌧️ Deszcz i mokra nawierzchnia</span>
              <span className={`h-6 w-11 rounded-full p-1 transition-all ${s.rain ? 'bg-cyan-400' : 'bg-white/20'}`}>
                <span className={`block h-4 w-4 rounded-full bg-white transition-all ${s.rain ? 'translate-x-5' : ''}`} />
              </span>
            </button>
          </div>

          <div className="flex flex-col gap-5">
            <div className="glass rounded-2xl p-5 md:p-6">
              <div className="text-xs tracking-widest text-cyan-300 mb-3">STEROWANIE</div>
              <div className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
                {[
                  ['W / ↑', 'Gaz'],
                  ['S / ↓', 'Hamulec / wsteczny'],
                  ['A D / ← →', 'Skręt'],
                  ['SHIFT / SPACJA', 'Drift (przytrzymaj w zakręcie)'],
                  ['E / CTRL / ENTER', 'Użyj przedmiotu'],
                  ['C', 'Spójrz do tyłu'],
                  ['R', 'Powrót na tor'],
                  ['M · ESC', 'Muzyka · Pauza'],
                ].map(([k, v]) => (
                  <div key={k} className="contents">
                    <kbd className="rounded bg-white/10 px-2 py-0.5 font-mono text-xs text-cyan-200 whitespace-nowrap self-center">{k}</kbd>
                    <span className="text-white/80">{v}</span>
                  </div>
                ))}
              </div>
              <div className="mt-3 text-xs text-white/50">🎮 Obsługa pada: RT gaz, LT hamulec, RB drift, X przedmiot.</div>
            </div>
            <div className="glass rounded-2xl p-5 md:p-6 text-sm text-white/80 space-y-2">
              <div className="text-xs tracking-widest text-cyan-300 mb-1">PORADY PRO</div>
              <p>
                🔵🟠🟣 Driftuj dłużej, by naładować <b>mini-turbo</b> — kolor iskier pokazuje poziom.
              </p>
              <p>🚀 Wciśnij gaz tuż przed <b>START</b>, by wykonać rakietowy start.</p>
              <p>⚡ Żółte strzałki na jezdni to <b>boost pady</b>. Po skoku ze skoczni dostaniesz turbo.</p>
              <p>❓ Rozbijaj holo-skrzynki, by zdobyć rakiety, miny EMP, tarcze i turbo.</p>
            </div>
            <button
              onClick={() => onStart(s)}
              className="group relative mt-auto overflow-hidden rounded-2xl border-2 border-cyan-300 bg-gradient-to-r from-cyan-500/40 via-fuchsia-500/40 to-cyan-500/40 py-5 font-display text-3xl font-black italic tracking-widest shadow-[0_0_40px_rgba(0,240,255,0.45)] transition-all hover:scale-[1.02] hover:shadow-[0_0_60px_rgba(255,43,214,0.6)]"
            >
              <span className="relative z-10 neon-text">START ▸</span>
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
