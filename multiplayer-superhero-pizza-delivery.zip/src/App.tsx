import { useEffect, useRef, useState, type ReactNode } from "react";
import { Game, type TouchState } from "./game/Game";
import { GRADE_LINES, ROSTER, TIPS, formatTime, type PlayerHud, type Snapshot } from "./game/types";

const initial: Snapshot = {
  phase: "loading",
  mode: "coop",
  duration: 120,
  timeLeft: 120,
  countdown: 3,
  announcer: "",
  announcerSub: "",
  announcerId: 0,
  players: [],
  teamScore: 0,
  orders: 0,
  hint: "",
  music: true,
  soundReady: false,
  best: 0,
  newBest: false,
  stars: 0,
  grade: "D",
  gradeLine: GRADE_LINES.D,
  mvp: 0,
  tip: TIPS[0],
  load: 0.04,
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const touchRef = useRef<TouchState>({ on: false, x: 0, y: 0, action: false, fire: false });
  const [snap, setSnap] = useState<Snapshot>(initial);
  const [help, setHelp] = useState(false);
  const [touchUi, setTouchUi] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const mini = miniRef.current;
    if (!canvas || !mini) return;
    let alive = true;
    const game = new Game(canvas, mini, (s) => {
      if (alive) setSnap(s);
    });
    gameRef.current = game;
    const enableTouch = () => setTouchUi(true);
    window.addEventListener("touchstart", enableTouch, { passive: true });
    let raf = 0;
    const pump = () => {
      game.setTouch(touchRef.current);
      raf = requestAnimationFrame(pump);
    };
    raf = requestAnimationFrame(pump);
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("touchstart", enableTouch);
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const cards: PlayerHud[] = snap.players.length
    ? snap.players
    : ROSTER.map((r) => ({
        slot: r.slot,
        name: r.name,
        full: r.full,
        role: r.role,
        color: r.color,
        portrait: r.portrait,
        joined: false,
        score: 0,
        combo: 0,
        bestCombo: 0,
        pizzas: 6,
        maxPizzas: 6,
        deliveries: 0,
        perfects: 0,
        misses: 0,
        heat: 0,
        overdrive: 0,
        swinging: false,
        speed: 0,
        keyLabel: r.keyLabel,
        moveLabel: r.moveLabel,
        lead: false,
      }));

  const playing = snap.phase === "play" || snap.phase === "countdown" || snap.phase === "paused" || snap.phase === "results";
  const urgent = snap.phase === "play" && snap.timeLeft <= 10;

  return (
    <main className="relative h-full w-full overflow-hidden bg-[#07060c] text-[#f4efe6]">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      <canvas
        ref={miniRef}
        width={168}
        height={168}
        className={`pointer-events-none absolute z-20 h-28 w-28 rounded-2xl ring-1 ring-white/15 ${
          snap.phase === "play" || snap.phase === "paused" || snap.phase === "countdown" ? "right-3 top-20 hidden sm:block" : "opacity-0"
        }`}
      />
      <div className="vignette absolute inset-0 z-[1]" />

      <header className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-3 p-3 md:p-5">
        <div className="pointer-events-auto flex items-center gap-3">
          <img src="/images/emblem.png" alt="" className="h-11 w-11 rounded-xl object-cover shadow-lg shadow-black/40 ring-1 ring-white/20" />
          <div>
            <div className="font-display text-3xl leading-none logo-fill">WEBZA</div>
            <div className="text-[11px] uppercase tracking-[0.22em] text-white/60">Dzielnica Marinara</div>
          </div>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          {!snap.soundReady && snap.phase !== "loading" && (
            <span className="hidden text-xs text-white/50 sm:block">Kliknij, żeby odpalić dźwięk</span>
          )}
          <button className="glass rounded-full px-3 py-2 text-xs font-semibold" onClick={() => setTouchUi((v) => !v)}>
            {touchUi ? "Klawiatura" : "Dotyk"}
          </button>
          <button className="glass rounded-full px-3 py-2 text-sm font-semibold" onClick={() => gameRef.current?.toggleMusic()} aria-label="Dźwięk">
            {snap.music ? "Dźwięk" : "Cisza"}
          </button>
          {playing && snap.phase !== "results" && (
            <button className="glass rounded-full px-3 py-2 text-sm font-semibold" onClick={() => gameRef.current?.pause()}>
              Pauza
            </button>
          )}
        </div>
      </header>

      {snap.phase === "loading" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#07060c]">
          <div className="w-[min(440px,90vw)] text-center">
            <img src="/images/emblem.png" alt="" className="mx-auto mb-6 h-28 w-28 rounded-3xl object-cover shadow-2xl shadow-orange-900/40" />
            <div className="font-display logo-fill text-7xl">WEBZA</div>
            <p className="mt-2 text-sm tracking-[0.28em] uppercase text-white/50">Rozgrzewamy piec</p>
            <div className="mt-8 h-1.5 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-gradient-to-r from-[#ffb15a] to-[#ff3d6e]" style={{ width: `${Math.round(snap.load * 100)}%` }} />
            </div>
          </div>
        </div>
      )}

      {snap.phase === "menu" && !help && (
        <div className="pointer-events-none absolute inset-0 z-10">
          <section className="pointer-events-auto absolute left-3 top-20 w-[min(460px,calc(100%-1.5rem))] rise md:left-6 md:top-24">
            <div className="glass max-h-[calc(100dvh-13rem)] overflow-y-auto rounded-3xl p-5 md:p-7">
              <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-[#ffb15a]">Nocna zmiana · do 4 kurierów</p>
              <h1 className="font-display logo-fill mt-2 text-[88px] leading-[0.8] md:text-[108px]">WEBZA</h1>
              <p className="mt-3 max-w-sm text-lg leading-snug text-white/85">
                Pizza stygnie. Sieć nie. Dostarczacie szybciej, niż miasto zdąży zgłodnieć drugi raz.
              </p>
              <div className="mt-5 grid grid-cols-2 gap-2">
                <button
                  className={`rounded-2xl px-3 py-3 text-left ${snap.mode === "coop" ? "bg-white text-[#1a0d0a]" : "bg-white/5 text-white"}`}
                  onClick={() => gameRef.current?.setMode("coop")}
                >
                  <div className="text-sm font-bold">Ekipa</div>
                  <div className={`text-xs ${snap.mode === "coop" ? "text-black/60" : "text-white/50"}`}>Wspólna kasa</div>
                </button>
                <button
                  className={`rounded-2xl px-3 py-3 text-left ${snap.mode === "versus" ? "bg-white text-[#1a0d0a]" : "bg-white/5 text-white"}`}
                  onClick={() => gameRef.current?.setMode("versus")}
                >
                  <div className="text-sm font-bold">Rywalizacja</div>
                  <div className={`text-xs ${snap.mode === "versus" ? "text-black/60" : "text-white/50"}`}>Kto pierwszy, ten ma punkty</div>
                </button>
              </div>
              <div className="mt-3 flex gap-2">
                {[
                  [60, "Krótka"],
                  [120, "Nocna"],
                  [180, "Maraton"],
                ].map(([sec, label]) => (
                  <button
                    key={label}
                    className={`flex-1 rounded-xl px-2 py-2 text-xs font-bold ${snap.duration === sec ? "bg-[#ff6a2c] text-[#2a0c08]" : "bg-white/5 text-white/70"}`}
                    onClick={() => gameRef.current?.setDuration(Number(sec))}
                  >
                    {label}
                    <div className="font-normal opacity-70">{formatTime(Number(sec))}</div>
                  </button>
                ))}
              </div>
              <button className="cta mt-5 w-full rounded-2xl px-5 py-4 text-lg font-extrabold tracking-wide" onClick={() => gameRef.current?.start()}>
                Rozpocznij zmianę
              </button>
              <button className="mt-2 w-full rounded-2xl bg-white/5 px-5 py-3 text-sm font-semibold text-white/80" onClick={() => setHelp(true)}>
                Jak grać
              </button>
              <div className="mt-4 flex items-end justify-between text-xs text-white/50">
                <span>Rekord {snap.mode === "coop" ? "ekipy" : "rywalizacji"}</span>
                <span className="font-display text-2xl text-white">{snap.best.toLocaleString("pl-PL")}</span>
              </div>
            </div>
            <p className="mt-3 max-w-md px-1 text-sm text-white/70">{snap.tip}</p>
          </section>
        </div>
      )}

      {(snap.phase === "menu" || playing) && (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 p-3 md:p-4">
          {snap.phase !== "menu" && (
            <div className="pointer-events-none mb-3 flex items-end justify-between gap-3">
              <div className="glass pointer-events-auto rounded-2xl px-4 py-2">
                <div className="text-[10px] uppercase tracking-[0.2em] text-white/50">{snap.mode === "coop" ? "Kasa ekipy" : "Na prowadzeniu"}</div>
                <div className="font-display text-4xl leading-none">{snap.teamScore.toLocaleString("pl-PL")}</div>
              </div>
              <div className={`glass rounded-2xl px-5 py-2 text-center ${urgent ? "pulse-hot" : ""}`}>
                <div className="text-[10px] uppercase tracking-[0.22em] text-white/50">Zmiana</div>
                <div className={`font-display text-5xl leading-none ${urgent ? "text-[#ff5a6a]" : ""}`}>{formatTime(snap.timeLeft)}</div>
                <div className="text-[10px] text-white/45">{snap.orders} świateł w mieście</div>
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
            {cards.map((p) => (
              <PlayerCard
                key={p.slot}
                player={p}
                menu={snap.phase === "menu"}
                onJoin={() => gameRef.current?.join(p.slot)}
                onLeave={() => gameRef.current?.leave(p.slot)}
              />
            ))}
          </div>
          {snap.hint && snap.phase === "play" && (
            <div className="pointer-events-none mt-2 text-center text-sm font-medium text-white/80 drop-shadow">{snap.hint}</div>
          )}
        </div>
      )}

      {snap.phase === "countdown" && (
        <div key={snap.countdown} className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center">
          <div className="count-pop text-center">
            <div className="font-display text-[22vw] leading-none text-white drop-shadow-[0_10px_40px_rgba(0,0,0,0.55)]">{snap.countdown || "GO"}</div>
            <div className="text-sm uppercase tracking-[0.35em] text-white/70">Kurierzy na linię</div>
          </div>
        </div>
      )}

      {snap.announcer && snap.phase !== "loading" && (
        <div key={snap.announcerId} className="pointer-events-none absolute left-1/2 top-[16%] z-30 w-[min(900px,92vw)] -translate-x-1/2 text-center count-pop">
          <div className="text-5xl font-black uppercase tracking-tight text-white drop-shadow-[0_8px_24px_rgba(0,0,0,0.65)] md:text-7xl">{snap.announcer}</div>
          <div className="mt-1 text-sm text-white/75 md:text-base">{snap.announcerSub}</div>
        </div>
      )}

      {help && <Help onClose={() => setHelp(false)} />}

      {snap.phase === "paused" && (
        <Modal>
          <p className="text-xs uppercase tracking-[0.25em] text-[#ffb15a]">Pauza</p>
          <h2 className="mt-1 text-4xl font-black">Pizza czeka w piecu.</h2>
          <p className="mt-2 text-sm text-white/65">Sieci trzymają. Klienci trochę mniej.</p>
          <div className="mt-6 flex flex-col gap-2">
            <button className="cta rounded-2xl py-3 font-extrabold" onClick={() => gameRef.current?.resume()}>Wznów zmianę</button>
            <button className="rounded-2xl bg-white/10 py-3 font-semibold" onClick={() => gameRef.current?.endEarly()}>Zakończ i policz kasę</button>
            <button className="rounded-2xl bg-white/5 py-3 text-white/70" onClick={() => { setHelp(false); gameRef.current?.toMenu(); }}>Wyjdź do menu</button>
          </div>
        </Modal>
      )}

      {snap.phase === "results" && (
        <Modal wide>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-[#ffb15a]">Koniec zmiany</p>
              <h2 className="text-3xl font-black">Noc zamknięta.</h2>
            </div>
            <div className="text-right">
              <div className="font-display grade-glow text-7xl leading-none text-[#ffd27a]">{snap.grade}</div>
              <div className="mt-1 flex justify-end gap-1">
                {Array.from({ length: 5 }, (_, i) => (
                  <span key={i} className="star text-xl" style={{ opacity: i < snap.stars ? 1 : 0.25 }}>★</span>
                ))}
              </div>
            </div>
          </div>
          <p className="mt-2 text-sm text-white/70">{snap.gradeLine}</p>
          {snap.newBest && <p className="mt-2 text-sm font-bold text-[#ffd36a]">Nowy rekord dzielnicy.</p>}
          <div className="mt-4 text-sm text-white/50">Kasa {snap.mode === "coop" ? "ekipy" : "łącznie"} <span className="font-display text-3xl text-white">{snap.teamScore.toLocaleString("pl-PL")}</span></div>
          <div className="mt-4 grid gap-2">
            {cards.filter((p) => p.joined).map((p) => (
              <div key={p.slot} className="flex items-center gap-3 rounded-2xl bg-black/30 p-2" style={{ outline: p.slot === snap.mvp ? `1px solid ${p.color}` : undefined }}>
                <img src={p.portrait} alt="" className="h-12 w-12 rounded-xl object-cover" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold" style={{ color: p.color }}>{p.name}</span>
                    {p.slot === snap.mvp && <span className="rounded-full bg-[#ffd36a] px-2 py-0.5 text-[10px] font-black text-[#3a2504]">MVP</span>}
                  </div>
                  <div className="text-xs text-white/50">{p.deliveries} dostaw · {p.perfects} perfekt · seria {p.bestCombo} · pudła {p.misses}</div>
                </div>
                <div className="font-display text-3xl">{p.score.toLocaleString("pl-PL")}</div>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-col gap-2 sm:flex-row">
            <button className="cta flex-1 rounded-2xl py-3 font-extrabold" onClick={() => gameRef.current?.rematch()}>Jeszcze jedna tura</button>
            <button className="flex-1 rounded-2xl bg-white/10 py-3 font-semibold" onClick={() => gameRef.current?.toMenu()}>Menu</button>
          </div>
        </Modal>
      )}

      {touchUi && (snap.phase === "play" || snap.phase === "menu") && (
        <TouchHud
          onMove={(x, y) => {
            touchRef.current.on = true;
            touchRef.current.x = x;
            touchRef.current.y = y;
          }}
          onAction={(v) => {
            touchRef.current.on = true;
            touchRef.current.action = v;
          }}
          onFire={(v) => {
            touchRef.current.on = true;
            touchRef.current.fire = v;
          }}
        />
      )}
    </main>
  );
}

function PlayerCard({
  player,
  menu,
  onJoin,
  onLeave,
}: {
  player: PlayerHud;
  menu: boolean;
  onJoin: () => void;
  onLeave: () => void;
}) {
  return (
    <article
      className="pointer-events-auto glass rounded-2xl p-2.5"
      style={{ boxShadow: player.joined ? `inset 0 0 0 1px ${player.color}88` : undefined, opacity: player.joined || menu ? 1 : 0.45 }}
    >
      <div className="flex gap-2">
        <img src={player.portrait} alt="" className="h-14 w-12 rounded-xl object-cover" style={{ filter: player.joined ? "none" : "grayscale(0.7)" }} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-1">
            <div className="truncate text-sm font-extrabold" style={{ color: player.color }}>
              {player.name}
              {player.lead && <span className="ml-1 text-[10px] text-[#ffd36a]">★</span>}
            </div>
            {!menu && <div className="font-display text-2xl leading-none">{player.score}</div>}
          </div>
          <div className="truncate text-[11px] text-white/50">{player.moveLabel} · {player.keyLabel}</div>
          {menu ? (
            player.joined ? (
              <button className="mt-1 text-xs font-bold text-white/80" onClick={onLeave}>Gotowy · opuść</button>
            ) : (
              <button className="mt-1 rounded-lg px-2 py-1 text-xs font-bold text-[#1a0c08]" style={{ background: player.color }} onClick={onJoin}>
                Dołącz
              </button>
            )
          ) : (
            <div className="mt-1 flex items-center gap-1">
              {Array.from({ length: player.maxPizzas }, (_, i) => (
                <span key={i} className="h-1.5 w-3 rounded-full" style={{ background: i < player.pizzas ? "#ffb15a" : "rgba(255,255,255,0.15)" }} />
              ))}
              {player.combo > 1 && <span className="ml-auto text-[11px] font-black text-white">x{player.combo}</span>}
              {player.overdrive > 0 && <span className="text-[10px] font-black text-[#ff7a3c]">OGIEŃ</span>}
            </div>
          )}
        </div>
      </div>
      {!menu && player.joined && (
        <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full" style={{ width: `${player.overdrive > 0 ? 100 : player.heat}%`, background: player.overdrive > 0 ? "#ff5a2a" : player.color }} />
        </div>
      )}
    </article>
  );
}

function Modal({ children, wide = false }: { children: ReactNode; wide?: boolean }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/45 p-4 backdrop-blur-sm">
      <div className={`glass max-h-[88vh] overflow-auto rounded-3xl p-5 md:p-7 ${wide ? "w-[min(720px,96vw)]" : "w-[min(440px,96vw)]"}`}>
        {children}
      </div>
    </div>
  );
}

function Help({ onClose }: { onClose: () => void }) {
  return (
    <Modal wide>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-[#8ef6ff]">Podręcznik kuriera</p>
          <h2 className="text-3xl font-black">Trzy rzeczy. Reszta to styl.</h2>
        </div>
        <button className="rounded-full bg-white/10 px-3 py-1 text-sm" onClick={onClose}>Zamknij</button>
      </div>
      <div className="mt-5 grid gap-3 md:grid-cols-3">
        <Tip title="Sieć" color="#8ef6ff" text="Przytrzymaj, żeby zaczepić linę i się huśtać. Puść w dole łuku — lecicie. Krótki tap w powietrzu przyciąga do punktu. Tap na ziemi to skok.">
          <svg viewBox="0 0 220 90" className="h-16 w-full">
            <path d="M16 74 Q 110 4 204 58" fill="none" stroke="#8ef6ff" strokeWidth="3" />
            <circle cx="16" cy="74" r="5" fill="#ff6a2c" />
            <circle cx="204" cy="58" r="4" fill="#8ef6ff" />
          </svg>
        </Tip>
        <Tip title="Rzut" color="#ffb15a" text="Przytrzymaj rzut, żeby naładować dystans. Gra lekko naprowadza na zamówienie przed tobą. Gracz 1 może celować myszą.">
          <svg viewBox="0 0 220 90" className="h-16 w-full">
            <path d="M20 70 Q 90 20 190 28" fill="none" stroke="#ffb15a" strokeWidth="3" strokeDasharray="5 6" />
            <rect x="176" y="16" width="28" height="18" rx="3" fill="#ff6a2c" />
          </svg>
        </Tip>
        <Tip title="Zamówienie" color="#ffd36a" text="Słup światła to głodny klient: okno, drzwi albo dach. Wyżej i trudniej — grubsze punkty. Złoto to rush. Róż to VIP.">
          <svg viewBox="0 0 220 90" className="h-16 w-full">
            <rect x="96" y="18" width="28" height="58" rx="4" fill="#1c2433" stroke="#8ef6ff" />
            <circle cx="110" cy="14" r="6" fill="#ffd36a" />
          </svg>
        </Tip>
      </div>
      <p className="mt-4 text-sm text-white/70">Premie: perfekt, rzut z powietrza, rzut z huśtawki, seria i rozgrzanie. Pusty plecak napełnisz w pomarańczowym kręgu przy furgonetce.</p>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {ROSTER.map((r) => (
          <div key={r.slot} className="flex items-center gap-3 rounded-2xl bg-black/30 p-2">
            <img src={r.portrait} alt="" className="h-12 w-10 rounded-lg object-cover" />
            <div>
              <div className="text-sm font-extrabold" style={{ color: r.color }}>{r.full}</div>
              <div className="text-xs text-white/60">{r.moveLabel} · {r.keyLabel}</div>
            </div>
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs text-white/45">Pad w slocie 1–4: lewy drążek, A sieć/skok, B lub X rzut. Mysz gracza 1: lewy przycisk sieć, prawy rzut. Enter startuje zmianę, Esc pauza, M dźwięk.</p>
    </Modal>
  );
}

function Tip({ title, text, color, children }: { title: string; text: string; color: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl bg-black/30 p-3">
      <div className="text-sm font-extrabold" style={{ color }}>{title}</div>
      {children}
      <p className="mt-1 text-xs leading-relaxed text-white/65">{text}</p>
    </div>
  );
}

function TouchHud({
  onMove,
  onAction,
  onFire,
}: {
  onMove: (x: number, y: number) => void;
  onAction: (v: boolean) => void;
  onFire: (v: boolean) => void;
}) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-36 z-30 flex items-end justify-between px-4 pb-2 md:bottom-40">
      <Stick onVec={onMove} />
      <div className="pointer-events-auto flex gap-3">
        <HoldButton label="SIEĆ" color="#8ef6ff" onChange={onAction} />
        <HoldButton label="RZUT" color="#ffb15a" onChange={onFire} />
      </div>
    </div>
  );
}

function HoldButton({ label, color, onChange }: { label: string; color: string; onChange: (v: boolean) => void }) {
  return (
    <button
      className="h-20 w-20 rounded-full text-xs font-black text-[#1a0c08]"
      style={{ background: color, boxShadow: `0 8px 24px ${color}66` }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        onChange(true);
      }}
      onPointerUp={() => onChange(false)}
      onPointerCancel={() => onChange(false)}
    >
      {label}
    </button>
  );
}

function Stick({ onVec }: { onVec: (x: number, y: number) => void }) {
  const zone = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const active = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });

  const move = (clientX: number, clientY: number) => {
    const dx = clientX - origin.current.x;
    const dy = clientY - origin.current.y;
    const max = 46;
    const len = Math.hypot(dx, dy) || 1;
    const k = Math.min(max, len) / len;
    setKnob({ x: dx * k, y: dy * k });
    onVec((dx * k) / max, -(dy * k) / max);
  };
  const end = () => {
    active.current = null;
    setKnob({ x: 0, y: 0 });
    onVec(0, 0);
  };

  return (
    <div
      ref={zone}
      className="pointer-events-auto relative h-32 w-32 rounded-full border border-white/20 bg-black/35 backdrop-blur-md"
      onPointerDown={(e) => {
        active.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        const r = zone.current!.getBoundingClientRect();
        origin.current = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
        move(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (active.current !== e.pointerId) return;
        move(e.clientX, e.clientY);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div
        className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full bg-white/85"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}
