export type Phase = "loading" | "menu" | "countdown" | "play" | "paused" | "results";
export type Mode = "coop" | "versus";
export type OrderKind = "window" | "door" | "roof";

export interface KeyBind {
  up: string[];
  down: string[];
  left: string[];
  right: string[];
  action: string[];
  fire: string[];
  join: string[];
}

export interface CourierDef {
  slot: number;
  name: string;
  full: string;
  role: string;
  blurb: string;
  color: string;
  deep: string;
  accent: string;
  visor: string;
  skin: string;
  scarf: string;
  portrait: string;
  keys: KeyBind;
  keyLabel: string;
  moveLabel: string;
}

const bind = (
  up: string[],
  down: string[],
  left: string[],
  right: string[],
  action: string[],
  fire: string[],
): KeyBind => ({
  up,
  down,
  left,
  right,
  action,
  fire,
  join: [...up, ...down, ...left, ...right, ...action, ...fire],
});

export const ROSTER: CourierDef[] = [
  {
    slot: 0,
    name: "PEPE",
    full: "Peperoncino",
    role: "Ognisty nadgarstek",
    blurb: "Rzuca, zanim klient skończy myśleć o kolacji.",
    color: "#ff3d4a",
    deep: "#6e1420",
    accent: "#ffd0b0",
    visor: "#ffb15a",
    skin: "#c68642",
    scarf: "#ffe1c8",
    portrait: "/portraits/pepe.png",
    keys: bind(["KeyW"], ["KeyS"], ["KeyA"], ["KeyD"], ["Space"], ["KeyE"]),
    keyLabel: "Spacja sieć · E rzut",
    moveLabel: "WASD",
  },
  {
    slot: 1,
    name: "AZZU",
    full: "Azzurro",
    role: "Trajektoria z pamięci",
    blurb: "Widzi łuk pizzy trzy dachy wcześniej.",
    color: "#3ec6ff",
    deep: "#0e3c55",
    accent: "#d8f6ff",
    visor: "#9af6ff",
    skin: "#8d5524",
    scarf: "#e7fbff",
    portrait: "/portraits/azzu.png",
    keys: bind(["KeyI"], ["KeyK"], ["KeyJ"], ["KeyL"], ["KeyU"], ["KeyO"]),
    keyLabel: "U sieć · O rzut",
    moveLabel: "IJKL",
  },
  {
    slot: 2,
    name: "BASIL",
    full: "Basilico",
    role: "Ciche lądowania",
    blurb: "Na dachu jest wcześniej niż zapach oregano.",
    color: "#7dff6a",
    deep: "#145018",
    accent: "#e7ffd8",
    visor: "#d6ff6a",
    skin: "#e0ac7a",
    scarf: "#f3ffe8",
    portrait: "/portraits/basil.png",
    keys: bind(["KeyT"], ["KeyG"], ["KeyF"], ["KeyH"], ["KeyR"], ["KeyY"]),
    keyLabel: "R sieć · Y rzut",
    moveLabel: "TFGH",
  },
  {
    slot: 3,
    name: "FORMI",
    full: "Formaggio",
    role: "Złota seria",
    blurb: "Punkty lubią się do niej przyklejać.",
    color: "#ffc14a",
    deep: "#5a3d08",
    accent: "#fff1c4",
    visor: "#ffe08a",
    skin: "#6b3a22",
    scarf: "#fff6d8",
    portrait: "/portraits/formi.png",
    keys: bind(
      ["ArrowUp", "Numpad8"],
      ["ArrowDown", "Numpad5"],
      ["ArrowLeft", "Numpad4"],
      ["ArrowRight", "Numpad6"],
      ["ShiftRight", "Numpad0"],
      ["Period", "Numpad1", "NumpadEnter"],
    ),
    keyLabel: "Prawy Shift sieć · . rzut",
    moveLabel: "Strzałki",
  },
];

export interface PlayerHud {
  slot: number;
  name: string;
  full: string;
  role: string;
  color: string;
  portrait: string;
  joined: boolean;
  score: number;
  combo: number;
  bestCombo: number;
  pizzas: number;
  maxPizzas: number;
  deliveries: number;
  perfects: number;
  misses: number;
  heat: number;
  overdrive: number;
  swinging: boolean;
  speed: number;
  keyLabel: string;
  moveLabel: string;
  lead: boolean;
}

export interface Snapshot {
  phase: Phase;
  mode: Mode;
  duration: number;
  timeLeft: number;
  countdown: number;
  announcer: string;
  announcerSub: string;
  announcerId: number;
  players: PlayerHud[];
  teamScore: number;
  orders: number;
  hint: string;
  music: boolean;
  soundReady: boolean;
  best: number;
  newBest: boolean;
  stars: number;
  grade: string;
  gradeLine: string;
  mvp: number;
  tip: string;
  load: number;
}

export const TIPS = [
  "Przytrzymaj sieć, puść w dole łuku — tak się wystrzeliwuje zmianę.",
  "Krótki tap w powietrzu przyciąga cię do zaczepu.",
  "Słup światła to głodny klient. Wyżej okno, grubsze punkty.",
  "Rzut z huśtawki i z powietrza płaci premię za styl.",
  "Pusty plecak? Furgonetka WEBZA na placu nie ocenia.",
  "Seria nie lubi placków na asfalcie. Celuj w światło.",
  "Cztery osoby, jedna klawiatura. Pad też wchodzi na zmianę.",
  "Rush świeci złotem. Nie dyskutuj ze złotem.",
];

export const GRADE_LINES: Record<string, string> = {
  D: "Ciasto ostygło. Miasto udaje, że was nie widziało.",
  C: "Dowiezione. Ledwo, ale dowiezione.",
  B: "Solidna noc. Klienci przestaną dzwonić. Na chwilę.",
  A: "Dzielnica już plotkuje. W dobrym sensie.",
  S: "Legendy nocnej zmiany. Piec bije brawo.",
  "S+": "Fizyka się poddała. Klienci płaczą ze szczęścia.",
};

export function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}
export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}
export function damp(a: number, b: number, lambda: number, dt: number) {
  return lerp(a, b, 1 - Math.exp(-lambda * dt));
}
export function formatTime(s: number) {
  const t = Math.max(0, Math.ceil(s));
  return `${Math.floor(t / 60)}:${(t % 60).toString().padStart(2, "0")}`;
}
