import { useCallback, useEffect, useRef, useState } from 'react';
import { Game } from './game/Game';
import { ACCENTS } from './game/constants';
import type { GameSettings, GarageSettings, HudState, MatchSettings } from './game/types';
import { BoostGauge, CenterMessages, EndScreen, Feed, KeyHints, ReplayOverlay, ScoreBar, Scoreboard } from './ui/Hud';
import { ControlsScreen, GarageScreen, MainMenu, PauseMenu, SettingsScreen, SetupScreen } from './ui/Menu';

type Screen = 'main' | 'setup' | 'garage' | 'controls' | 'settings' | 'game';

const LS = 'nitro-league-v1-';
function load<T extends object>(k: string, d: T): T {
  try {
    const s = localStorage.getItem(LS + k);
    return s ? { ...d, ...JSON.parse(s) } : d;
  } catch {
    return d;
  }
}
function save(k: string, v: object) {
  try {
    localStorage.setItem(LS + k, JSON.stringify(v));
  } catch {
    /* brak dostępu do pamięci */
  }
}

const DEF_SETTINGS: GameSettings = { quality: 1, volume: 0.8, music: true, fov: 76, shake: true, showFps: false };
const DEF_MATCH: MatchSettings = { mode: 2, difficulty: 1, minutes: 5, team: 0 };
const DEF_GARAGE: GarageSettings = { body: 0, accent: ACCENTS[0], wheel: 0 };

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const mmEl = useRef<HTMLCanvasElement | null>(null);
  const screenRef = useRef<Screen>('main');
  const [screen, setScreenState] = useState<Screen>('main');
  const [hud, setHud] = useState<HudState | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<GameSettings>(() => load('settings', DEF_SETTINGS));
  const [match, setMatch] = useState<MatchSettings>(() => load('match', DEF_MATCH));
  const [garage, setGarage] = useState<GarageSettings>(() => load('garage', DEF_GARAGE));
  const settingsRef = useRef(settings);
  const garageRef = useRef(garage);
  const matchRef = useRef(match);
  settingsRef.current = settings;
  garageRef.current = garage;
  matchRef.current = match;

  const setScreen = useCallback((s: Screen) => {
    screenRef.current = s;
    setScreenState(s);
  }, []);

  // utworzenie gry
  useEffect(() => {
    let cancelled = false;
    let game: Game | null = null;
    const t = window.setTimeout(() => {
      if (cancelled || !containerRef.current) return;
      try {
        game = new Game(
          containerRef.current,
          {
            onHud: (h) => {
              if (screenRef.current === 'game') setHud(h);
            },
            onSettings: (p) => {
              const n = { ...settingsRef.current, ...p };
              settingsRef.current = n;
              setSettings(n);
              save('settings', n);
            },
          },
          { ...settingsRef.current },
        );
        game.setGarage(garageRef.current);
        game.setMatchTeam(matchRef.current.team);
        game.attachMinimap(mmEl.current);
        gameRef.current = game;
        setReady(true);
      } catch (e) {
        console.error(e);
        setError('Nie udało się uruchomić grafiki 3D (WebGL). Sprawdź, czy przeglądarka ma włączoną akcelerację sprzętową.');
      }
    }, 60);
    const onKey = () => gameRef.current?.unlockAudio();
    window.addEventListener('keydown', onKey);
    window.addEventListener('pointerdown', onKey);
    const onVis = () => {
      if (document.hidden && screenRef.current === 'game') gameRef.current?.setPaused(true);
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('pointerdown', onKey);
      document.removeEventListener('visibilitychange', onVis);
      game?.dispose();
      gameRef.current = null;
    };
  }, []);

  const mmRef = useCallback((el: HTMLCanvasElement | null) => {
    mmEl.current = el;
    gameRef.current?.attachMinimap(el);
  }, []);

  const changeSettings = (p: Partial<GameSettings>) => {
    const n = { ...settings, ...p };
    setSettings(n);
    save('settings', n);
    gameRef.current?.setSettings(p);
  };
  const changeMatch = (m: MatchSettings) => {
    setMatch(m);
    save('match', m);
    gameRef.current?.setMatchTeam(m.team);
  };
  const changeGarage = (p: Partial<GarageSettings>) => {
    const n = { ...garage, ...p };
    setGarage(n);
    save('garage', n);
    gameRef.current?.setGarage(p);
  };

  const go = (s: Screen) => {
    const g = gameRef.current;
    if (!g) return;
    g.unlockAudio();
    if (s === 'garage') g.enterGarage(true);
    else if (screen === 'garage') g.exitGarage();
    setScreen(s);
  };

  const startGame = () => {
    const g = gameRef.current;
    if (!g) return;
    g.unlockAudio();
    g.startMatch(match);
    setHud(null);
    setScreen('game');
  };

  const quit = () => {
    gameRef.current?.quitToMenu();
    setHud(null);
    setScreen('main');
  };

  const fullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen?.();
    else document.documentElement.requestFullscreen?.().catch(() => undefined);
  };

  const inMatch = screen === 'game' && hud;
  const playing = inMatch && hud.phase !== 'menu' && hud.phase !== 'garage';

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#04070d]">
      <div ref={containerRef} className="absolute inset-0" />

      {!ready && !error && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#04070d]">
          <h1 className="logo-shine font-display text-7xl font-black italic">NITRO</h1>
          <div className="font-display -mt-1 mb-8 text-3xl font-black italic tracking-[0.3em] text-white/90">LEAGUE</div>
          <div className="h-1.5 w-64 overflow-hidden rounded-full bg-white/10">
            <div className="h-full w-1/2 animate-pulse rounded-full bg-gradient-to-r from-cyan-400 to-blue-600" />
          </div>
          <p className="mt-4 text-xs font-bold tracking-[0.4em] text-white/50">GENEROWANIE ARENY…</p>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#04070d] p-8 text-center">
          <p className="max-w-md text-lg font-semibold text-red-300">{error}</p>
        </div>
      )}

      {ready && screen === 'main' && (
        <MainMenu onPlay={() => go('setup')} onGarage={() => go('garage')} onControls={() => go('controls')} onSettings={() => go('settings')} onFullscreen={fullscreen} />
      )}
      {ready && screen === 'setup' && <SetupScreen match={match} onChange={changeMatch} onStart={startGame} onBack={() => go('main')} />}
      {ready && screen === 'garage' && (
        <GarageScreen garage={garage} team={match.team} onChange={changeGarage} onTeam={(t) => changeMatch({ ...match, team: t })} onBack={() => go('main')} />
      )}
      {ready && screen === 'controls' && <ControlsScreen onBack={() => go('main')} />}
      {ready && screen === 'settings' && <SettingsScreen settings={settings} onChange={changeSettings} onBack={() => go('main')} />}

      {screen === 'game' && (
        <div className="pointer-events-none absolute inset-0 z-10">
          <canvas ref={mmRef} width={170} height={215} className={`absolute bottom-5 left-5 rounded-lg opacity-90 ${playing && hud.phase !== 'replay' ? '' : 'hidden'}`} />
          {settings.showFps && hud && <div className="absolute left-4 top-3 font-display text-xs font-bold text-lime-300">{hud.fps} FPS</div>}
          {playing && hud.phase !== 'replay' && hud.phase !== 'ended' && (
            <>
              <ScoreBar hud={hud} />
              <BoostGauge hud={hud} />
              <Feed hud={hud} />
              <KeyHints />
              <div className="absolute left-5 top-3 mt-4 text-[11px] font-bold tracking-[0.25em] text-white/50">ESC — PAUZA · {hud.ballCam ? 'KAMERA: PIŁKA' : 'KAMERA: AUTO'}</div>
            </>
          )}
          {playing && hud.phase === 'replay' && (
            <>
              <ScoreBar hud={hud} />
              <ReplayOverlay hud={hud} />
            </>
          )}
          {playing && hud.phase === 'ended' && <ScoreBar hud={hud} />}
          {playing && <CenterMessages hud={hud} />}
          {playing && hud.showScoreboard && hud.phase !== 'ended' && <Scoreboard hud={hud} />}
        </div>
      )}
      {screen === 'game' && hud && hud.phase === 'ended' && <EndScreen hud={hud} onRematch={() => gameRef.current?.restartMatch()} onMenu={quit} />}
      {screen === 'game' && hud && hud.paused && (
        <PauseMenu
          settings={settings}
          onChange={changeSettings}
          onResume={() => gameRef.current?.setPaused(false)}
          onRestart={() => {
            gameRef.current?.restartMatch();
          }}
          onQuit={quit}
        />
      )}
    </div>
  );
}
