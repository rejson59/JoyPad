export interface InputSample {
  throttle: number;
  steer: number;
  pitch: number;
  roll: number;
  jump: boolean;
  boost: boolean;
  handbrake: boolean;
}

const GAME_KEYS = new Set([
  'KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'ShiftLeft', 'ShiftRight',
  'KeyQ', 'KeyE', 'KeyX', 'KeyC', 'KeyR', 'Tab', 'ControlLeft', 'ControlRight', 'Escape', 'KeyP', 'Enter',
]);

export class InputManager {
  keys = new Set<string>();
  mouse = [false, false, false];
  private edges = new Set<string>();
  private steerSm = 0;
  private padPrev: Record<string, boolean> = {};
  enabled = true;
  usingPad = false;
  private handlers: [string, EventListener, EventTarget][] = [];

  constructor(el: HTMLElement) {
    const add = (t: EventTarget, n: string, f: (e: any) => void) => {
      t.addEventListener(n, f as EventListener);
      this.handlers.push([n, f as EventListener, t]);
    };
    add(window, 'keydown', (e: KeyboardEvent) => {
      const tg = e.target as HTMLElement;
      if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'SELECT' || tg.tagName === 'TEXTAREA')) return;
      if (GAME_KEYS.has(e.code) && this.enabled) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      if (e.code === 'Space') this.edges.add('jump');
      if (e.code === 'KeyC') this.edges.add('ballcam');
      if (e.code === 'Escape' || e.code === 'KeyP') this.edges.add('pause');
      if (e.code === 'KeyR') this.edges.add('reset');
      if (e.code === 'Space' || e.code === 'Enter') this.edges.add('skip');
    });
    add(window, 'keyup', (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    });
    add(window, 'blur', () => {
      this.keys.clear();
      this.mouse = [false, false, false];
    });
    add(el, 'mousedown', (e: MouseEvent) => {
      if (!this.enabled) return;
      this.mouse[e.button] = true;
      if (e.button === 2) this.edges.add('ballcam');
    });
    add(window, 'mouseup', (e: MouseEvent) => {
      this.mouse[e.button] = false;
    });
    add(el, 'contextmenu', (e: Event) => e.preventDefault());
  }

  dispose() {
    for (const [n, f, t] of this.handlers) t.removeEventListener(n, f);
    this.handlers = [];
  }

  consumeEdge(name: string): boolean {
    if (this.edges.has(name)) {
      this.edges.delete(name);
      return true;
    }
    return false;
  }

  clearEdges() {
    this.edges.clear();
  }

  held(code: string) {
    return this.keys.has(code);
  }

  private pad(): Gamepad | null {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (const p of pads) if (p && p.connected) return p;
    return null;
  }

  sample(dt: number): InputSample {
    const k = this.keys;
    const up = k.has('KeyW') || k.has('ArrowUp');
    const down = k.has('KeyS') || k.has('ArrowDown');
    const left = k.has('KeyA') || k.has('ArrowLeft');
    const right = k.has('KeyD') || k.has('ArrowRight');
    let throttle = (up ? 1 : 0) - (down ? 1 : 0);
    let pitch = throttle;
    const steerT = (right ? 1 : 0) - (left ? 1 : 0);
    this.steerSm += (steerT - this.steerSm) * Math.min(1, dt * 16);
    if (steerT === 0 && Math.abs(this.steerSm) < 0.02) this.steerSm = 0;
    let steer = this.steerSm;
    let roll = (k.has('KeyE') ? 1 : 0) - (k.has('KeyQ') ? 1 : 0);
    let jump = k.has('Space');
    let boost = k.has('ShiftLeft') || k.has('ShiftRight') || this.mouse[0];
    let handbrake = k.has('KeyX') || k.has('ControlLeft') || k.has('ControlRight');

    const p = this.pad();
    if (p) {
      const dz = (v: number) => (Math.abs(v) < 0.15 ? 0 : (v - Math.sign(v) * 0.15) / 0.85);
      const ax = dz(p.axes[0] || 0);
      const ay = dz(p.axes[1] || 0);
      const rt = p.buttons[7]?.value || 0;
      const lt = p.buttons[6]?.value || 0;
      const btn = (i: number) => !!p.buttons[i]?.pressed;
      const edge = (name: string, i: number) => {
        const cur = btn(i);
        if (cur && !this.padPrev[name]) this.edges.add(name);
        this.padPrev[name] = cur;
      };
      edge('jump', 0);
      edge('ballcam', 3);
      edge('pause', 9);
      edge('skip', 0);
      edge('reset', 8);
      const padActive = Math.abs(ax) > 0 || Math.abs(ay) > 0 || rt > 0.05 || lt > 0.05 || btn(0) || btn(1) || btn(2);
      if (padActive) {
        this.usingPad = true;
        if (Math.abs(ax) > 0) steer = ax;
        if (rt > 0.05 || lt > 0.05) throttle = rt - lt;
        if (Math.abs(ay) > 0) pitch = -ay;
        else if (rt > 0.05 || lt > 0.05) pitch = throttle;
        jump = jump || btn(0);
        boost = boost || btn(1) || btn(2);
        handbrake = handbrake || btn(4) || btn(5);
        if (btn(4) && Math.abs(ax) > 0) roll = ax;
      }
    }
    return { throttle, steer, pitch, roll, jump, boost, handbrake };
  }
}
