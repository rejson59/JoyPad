import type { HudState, PlayerStat } from '../game/types';
import { TEAM_HEX } from '../game/constants';

const fmt = (t: number) => {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const TEAM_TXT = ['NIEBIESCY', 'POMARAŃCZOWI'];

export function ScoreBar({ hud }: { hud: HudState }) {
  const low = !hud.overtime && hud.time <= 30 && hud.phase === 'playing';
  return (
    <div className="pointer-events-none absolute left-1/2 top-3 z-10 flex -translate-x-1/2 items-stretch anim-slide-down">
      <div
        className="flex w-56 items-center justify-end gap-3 px-6 py-1.5"
        style={{
          background: 'linear-gradient(90deg, rgba(10,30,90,0.3), rgba(30,100,255,0.85))',
          clipPath: 'polygon(0 0, 100% 0, calc(100% - 22px) 100%, 0 100%)',
          borderBottom: '3px solid #69a4ff',
        }}
      >
        <span className="font-display text-[11px] font-bold tracking-[0.25em] text-blue-100/80">NIEBIESCY</span>
        <span className="font-display text-5xl font-black leading-none text-white drop-shadow-[0_0_14px_rgba(120,170,255,0.9)]">{hud.scores[0]}</span>
      </div>
      <div className="relative z-10 -mx-3 flex min-w-[9.5rem] flex-col items-center justify-center bg-[#070c18]/90 px-6 py-1" style={{ clipPath: 'polygon(10px 0, calc(100% - 10px) 0, 100% 100%, 0 100%)', borderBottom: '3px solid rgba(255,255,255,0.6)' }}>
        <span className={`font-display text-3xl font-black leading-tight tabular-nums ${low ? 'anim-blink text-red-400' : 'text-white'}`}>
          {hud.overtime ? '+' : ''}
          {fmt(hud.time)}
        </span>
        {hud.overtime && <span className="font-display -mt-1 text-[10px] font-bold tracking-[0.3em] text-yellow-300">DOGRYWKA</span>}
      </div>
      <div
        className="flex w-56 items-center gap-3 px-6 py-1.5"
        style={{
          background: 'linear-gradient(270deg, rgba(90,40,5,0.3), rgba(255,130,30,0.88))',
          clipPath: 'polygon(22px 0, 100% 0, 100% 100%, 0 100%)',
          borderBottom: '3px solid #ffb36b',
        }}
      >
        <span className="font-display text-5xl font-black leading-none text-white drop-shadow-[0_0_14px_rgba(255,170,90,0.9)]">{hud.scores[1]}</span>
        <span className="font-display text-[11px] font-bold tracking-[0.25em] text-orange-100/80">POMARAŃCZ.</span>
      </div>
    </div>
  );
}

export function BoostGauge({ hud }: { hud: HudState }) {
  const b = Math.max(0, Math.min(100, hud.boost));
  const low = b < 18;
  const col = low ? '#ff4b4b' : b > 66 ? '#ffe27a' : '#ffa62b';
  const R = 68;
  return (
    <div className="pointer-events-none absolute bottom-5 right-6 z-10 select-none">
      <div className="relative h-[190px] w-[190px]">
        <svg viewBox="0 0 170 170" className="h-full w-full">
          <defs>
            <linearGradient id="bg1" x1="0" y1="1" x2="1" y2="0">
              <stop offset="0" stopColor="#ff5a1f" />
              <stop offset="0.6" stopColor="#ffb02b" />
              <stop offset="1" stopColor="#fff2a8" />
            </linearGradient>
          </defs>
          <circle cx="85" cy="85" r="74" fill="rgba(6,10,20,0.62)" stroke="rgba(120,180,255,0.18)" strokeWidth="1.5" />
          <circle cx="85" cy="85" r={R} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="12" strokeLinecap="round" pathLength={100} strokeDasharray="75 100" transform="rotate(135 85 85)" />
          <circle
            cx="85"
            cy="85"
            r={R}
            fill="none"
            stroke={low ? '#ff4b4b' : 'url(#bg1)'}
            strokeWidth="12"
            strokeLinecap="round"
            pathLength={100}
            strokeDasharray={`${Math.max(0.01, b * 0.75)} 100`}
            transform="rotate(135 85 85)"
            style={{ filter: `drop-shadow(0 0 8px ${col})`, transition: 'stroke-dasharray 0.08s linear' }}
            className={low ? 'anim-blink' : ''}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-5xl font-black leading-none text-white" style={{ textShadow: `0 0 18px ${col}` }}>
            {Math.round(b)}
          </span>
          <span className="font-display mt-1 text-[10px] font-bold tracking-[0.35em] text-orange-200/80">BOOST</span>
        </div>
      </div>
      <div className="mt-1 flex items-end justify-end gap-2 pr-2">
        {hud.supersonic && <span className="font-display anim-blink mr-2 text-[10px] font-bold tracking-[0.3em] text-cyan-300 text-glow-cyan">PONADDŹWIĘKOWA</span>}
        <span className="font-display text-3xl font-black tabular-nums text-white">{hud.speed}</span>
        <span className="mb-1 text-xs font-bold tracking-widest text-blue-200/70">KM/H</span>
      </div>
    </div>
  );
}

export function Feed({ hud }: { hud: HudState }) {
  return (
    <div className="pointer-events-none absolute right-5 top-20 z-10 flex w-72 flex-col items-end gap-1.5">
      {hud.feed.map((f) => (
        <div
          key={f.id}
          className="anim-slide-right w-full px-3 py-1.5 text-right text-sm font-bold tracking-wide text-white"
          style={{
            background: 'linear-gradient(270deg, rgba(8,12,24,0.85), rgba(8,12,24,0.3))',
            borderRight: `4px solid ${TEAM_HEX[f.team]}`,
          }}
        >
          {f.kind === 'goal' && <span className="mr-1">⚽</span>}
          {f.kind === 'save' && <span className="mr-1">🛡️</span>}
          {f.kind === 'demo' && <span className="mr-1">💥</span>}
          {f.text}
        </div>
      ))}
    </div>
  );
}

export function CenterMessages({ hud }: { hud: HudState }) {
  const g = hud.goalBanner;
  return (
    <>
      {hud.toast && !g && (
        <div key={hud.toast} className="anim-fade-up pointer-events-none absolute left-1/2 top-28 z-10 -translate-x-1/2 skew-btn bg-black/55 px-10 py-2">
          <span className="font-display text-lg font-bold tracking-[0.25em] text-white">{hud.toast}</span>
        </div>
      )}
      {hud.countdown > 0 && (
        <div key={hud.countdown} className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center">
          <span className="anim-pop font-display text-[14rem] font-black italic leading-none text-white" style={{ textShadow: '0 0 60px rgba(90,170,255,0.9), 0 0 120px rgba(90,170,255,0.5)' }}>
            {hud.countdown}
          </span>
        </div>
      )}
      {hud.countdown === 0 && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center">
          <span className="anim-pop font-display text-8xl font-black italic text-yellow-300" style={{ textShadow: '0 0 50px rgba(255,210,60,0.9)' }}>
            START!
          </span>
        </div>
      )}
      {g && (
        <div className="pointer-events-none absolute inset-x-0 top-[18%] z-10 flex flex-col items-center">
          <span
            className="anim-goal font-display text-[10rem] font-black italic leading-none"
            style={{
              color: '#fff',
              WebkitTextStroke: `4px ${TEAM_HEX[g.team]}`,
              textShadow: `0 0 50px ${TEAM_HEX[g.team]}, 0 0 120px ${TEAM_HEX[g.team]}`,
            }}
          >
            GOL!
          </span>
          <div className="anim-fade-up mt-2 skew-btn px-10 py-2" style={{ background: `linear-gradient(90deg, transparent, ${TEAM_HEX[g.team]}cc, transparent)`, animationDelay: '0.3s' }}>
            <span className="font-display text-2xl font-bold tracking-[0.2em] text-white">{g.name}</span>
          </div>
          <span className="anim-fade-up mt-2 text-sm font-bold tracking-[0.4em] text-white/80" style={{ animationDelay: '0.5s' }}>
            PRĘDKOŚĆ STRZAŁU {g.speed} KM/H
          </span>
        </div>
      )}
      {hud.demolished > 0 && (
        <div className="pointer-events-none absolute inset-x-0 top-1/3 z-10 flex flex-col items-center">
          <span className="font-display text-4xl font-black italic text-red-400" style={{ textShadow: '0 0 30px rgba(255,60,60,0.9)' }}>
            ZDEMOLOWANO!
          </span>
          <span className="mt-1 text-lg font-bold tracking-[0.3em] text-white/80">ODRODZENIE ZA {Math.ceil(hud.demolished)}</span>
        </div>
      )}
    </>
  );
}

export function ReplayOverlay({ hud }: { hud: HudState }) {
  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 h-24 bg-gradient-to-b from-black/70 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-28 bg-gradient-to-t from-black/70 to-transparent" />
      <div className="pointer-events-none absolute left-8 top-8 z-10 flex items-center gap-3">
        <span className="anim-blink h-4 w-4 rounded-full bg-red-500 shadow-[0_0_14px_#ff3b3b]" />
        <span className="font-display text-3xl font-black italic tracking-widest text-white">POWTÓRKA</span>
      </div>
      <div className="pointer-events-none absolute inset-x-10 bottom-8 z-10 flex items-center gap-4">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/20">
          <div className="h-full rounded-full bg-gradient-to-r from-cyan-300 to-blue-500" style={{ width: `${Math.min(100, hud.replayProgress * 100)}%` }} />
        </div>
        <span className="text-xs font-bold tracking-widest text-white/80">
          <kbd>SPACJA</kbd> POMIŃ
        </span>
      </div>
    </>
  );
}

function StatTable({ stats, team }: { stats: PlayerStat[]; team: number }) {
  const rows = stats.filter((s) => s.team === team).sort((a, b) => b.score - a.score);
  return (
    <div className="mb-3">
      <div className="flex items-center justify-between px-3 py-1.5" style={{ background: `linear-gradient(90deg, ${TEAM_HEX[team]}dd, ${TEAM_HEX[team]}33)` }}>
        <span className="font-display text-sm font-black tracking-[0.25em]">{TEAM_TXT[team]}</span>
        <span className="font-display text-lg font-black">{rows.reduce((a, r) => a + r.goals, 0)}</span>
      </div>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-[11px] tracking-widest text-blue-200/60">
            <th className="px-3 py-1 text-left">GRACZ</th>
            <th>WYNIK</th>
            <th>GOLE</th>
            <th>ASYSTY</th>
            <th>OBRONY</th>
            <th>STRZAŁY</th>
            <th>DEMOLKI</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.name} className={`text-center font-bold ${r.isPlayer ? 'bg-white/10 text-yellow-200' : 'text-white/90'}`}>
              <td className="px-3 py-1 text-left">{r.name}</td>
              <td className="font-display">{r.score}</td>
              <td>{r.goals}</td>
              <td>{r.assists}</td>
              <td>{r.saves}</td>
              <td>{r.shots}</td>
              <td>{r.demos}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Scoreboard({ hud }: { hud: HudState }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center bg-black/30">
      <div className="glass anim-fade-up w-[640px] max-w-[92vw] p-5">
        <div className="mb-3 text-center font-display text-xl font-black tracking-[0.4em] text-white">TABELA</div>
        <StatTable stats={hud.stats} team={0} />
        <StatTable stats={hud.stats} team={1} />
      </div>
    </div>
  );
}

export function EndScreen({ hud, onRematch, onMenu }: { hud: HudState; onRematch: () => void; onMenu: () => void }) {
  const draw = hud.winner === 2;
  const won = hud.winner === hud.playerTeam;
  const title = draw ? 'REMIS' : won ? 'ZWYCIĘSTWO!' : 'PORAŻKA';
  const col = draw ? '#ffd76a' : won ? '#5dffb0' : '#ff6a6a';
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-gradient-to-b from-black/70 via-black/40 to-black/80">
      <div className="anim-fade-up flex w-[760px] max-w-[94vw] flex-col items-center">
        <span className="font-display text-7xl font-black italic leading-none" style={{ color: col, textShadow: `0 0 40px ${col}` }}>
          {title}
        </span>
        <div className="mt-4 flex items-center gap-6">
          <span className="font-display text-6xl font-black text-blue-400">{hud.scores[0]}</span>
          <span className="font-display text-2xl text-white/50">:</span>
          <span className="font-display text-6xl font-black text-orange-400">{hud.scores[1]}</span>
        </div>
        <div className="glass mt-5 w-full p-4">
          <StatTable stats={hud.stats} team={0} />
          <StatTable stats={hud.stats} team={1} />
        </div>
        <div className="mt-6 flex gap-4">
          <button onClick={onRematch} className="skew-btn bg-gradient-to-r from-cyan-400 to-blue-600 px-10 py-3 font-display text-sm font-black tracking-[0.25em] text-white transition hover:brightness-125">
            REWANŻ
          </button>
          <button onClick={onMenu} className="skew-btn bg-white/10 px-10 py-3 font-display text-sm font-black tracking-[0.25em] text-white transition hover:bg-white/20">
            MENU GŁÓWNE
          </button>
        </div>
      </div>
    </div>
  );
}

export function KeyHints() {
  return (
    <div className="pointer-events-none absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 items-center gap-4 rounded-full bg-black/40 px-5 py-1.5 text-[11px] font-bold tracking-wider text-white/70">
      <span><kbd>W A S D</kbd> JAZDA</span>
      <span><kbd>SPACJA</kbd> SKOK / FLIP</span>
      <span><kbd>SHIFT</kbd> BOOST</span>
      <span><kbd>X</kbd> POŚLIZG</span>
      <span><kbd>C</kbd> KAMERA</span>
      <span><kbd>TAB</kbd> TABELA</span>
      <span><kbd>R</kbd> ODWRÓĆ AUTO</span>
    </div>
  );
}
