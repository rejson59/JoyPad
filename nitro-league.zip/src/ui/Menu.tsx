import type { ReactNode } from 'react';
import type { GameSettings, GarageSettings, MatchSettings } from '../game/types';
import { ACCENTS, TEAM_HEX } from '../game/constants';
import { BODY_NAMES } from '../game/carModel';

/* ---------- prymitywy ---------- */
export function MenuButton({
  children,
  onClick,
  primary,
  sub,
  delay = 0,
}: {
  children: ReactNode;
  onClick: () => void;
  primary?: boolean;
  sub?: string;
  delay?: number;
}) {
  return (
    <button
      onClick={onClick}
      style={{ animationDelay: `${delay}ms` }}
      className={`group anim-slide-right skew-btn relative w-full px-8 py-3.5 text-left transition-all duration-200 hover:translate-x-3 ${
        primary
          ? 'bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-700 text-white shadow-[0_0_40px_rgba(56,140,255,0.45)] hover:brightness-125'
          : 'bg-white/[0.07] text-white/90 hover:bg-white/[0.16]'
      }`}
    >
      <span className="font-display text-lg font-black italic tracking-[0.18em]">{children}</span>
      {sub && <span className="mt-0.5 block text-xs font-semibold tracking-widest text-white/50 group-hover:text-white/80">{sub}</span>}
    </button>
  );
}

function Label({ children }: { children: ReactNode }) {
  return <div className="mb-2 mt-5 font-display text-[11px] font-bold tracking-[0.35em] text-cyan-300/80 first:mt-0">{children}</div>;
}

function Card({
  active,
  onClick,
  children,
  color,
  className = '',
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative flex-1 rounded-md border px-3 py-3 text-center transition-all duration-150 ${className} ${
        active ? 'scale-[1.03] border-white/80 bg-white/15 shadow-[0_0_28px_rgba(90,170,255,0.4)]' : 'border-white/10 bg-white/[0.04] hover:border-white/40 hover:bg-white/10'
      }`}
      style={active && color ? { borderColor: color, boxShadow: `0 0 28px ${color}88`, background: `linear-gradient(160deg, ${color}44, rgba(255,255,255,0.05))` } : undefined}
    >
      {children}
    </button>
  );
}

function Panel({ title, children, width = 640, onBack }: { title: string; children: ReactNode; width?: number; onBack: () => void }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center bg-gradient-to-r from-black/85 via-black/45 to-transparent pl-10 md:pl-16">
      <div className="glass anim-fade-up max-h-[92vh] overflow-y-auto p-7" style={{ width, maxWidth: '94vw' }}>
        <div className="mb-5 flex items-center justify-between">
          <h2 className="font-display text-2xl font-black italic tracking-[0.2em] text-white">{title}</h2>
          <button onClick={onBack} className="rounded border border-white/20 px-4 py-1.5 text-xs font-bold tracking-[0.25em] text-white/80 transition hover:bg-white/15">
            ← WSTECZ
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ---------- menu główne ---------- */
export function MainMenu({
  onPlay,
  onGarage,
  onControls,
  onSettings,
  onFullscreen,
}: {
  onPlay: () => void;
  onGarage: () => void;
  onControls: () => void;
  onSettings: () => void;
  onFullscreen: () => void;
}) {
  return (
    <div className="absolute inset-0 z-20">
      <div className="absolute inset-0 bg-gradient-to-r from-[#02050b]/95 via-[#02050b]/50 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black/70 to-transparent" />
      <div className="relative flex h-full w-[560px] max-w-full flex-col justify-center pl-10 md:pl-16">
        <div className="anim-fade-up mb-10">
          <div className="mb-1 flex items-center gap-3">
            <svg viewBox="0 0 24 24" className="h-9 w-9 text-yellow-300 drop-shadow-[0_0_14px_rgba(255,220,80,0.9)]" fill="currentColor">
              <path d="M13 2 4 14h6l-1 8 9-12h-6z" />
            </svg>
            <span className="font-display text-xs font-bold tracking-[0.55em] text-cyan-200/80">SAMOCHODOWA PIŁKA NOŻNA</span>
          </div>
          <h1 className="logo-shine font-display text-[5.6rem] font-black italic leading-[0.9] tracking-tight">NITRO</h1>
          <h1 className="font-display -mt-1 text-[3.6rem] font-black italic leading-none tracking-[0.28em] text-white/95" style={{ textShadow: '0 0 30px rgba(80,160,255,0.6)' }}>
            LEAGUE
          </h1>
        </div>
        <div className="flex w-[380px] flex-col gap-3">
          <MenuButton primary onClick={onPlay} sub="1v1 · 2v2 · 3v3 przeciwko botom" delay={80}>
            MECZ TOWARZYSKI
          </MenuButton>
          <MenuButton onClick={onGarage} sub="Nadwozie, felgi, kolory" delay={160}>
            GARAŻ
          </MenuButton>
          <MenuButton onClick={onControls} sub="Klawiatura i pad" delay={240}>
            STEROWANIE
          </MenuButton>
          <MenuButton onClick={onSettings} sub="Grafika, dźwięk, kamera" delay={320}>
            USTAWIENIA
          </MenuButton>
        </div>
      </div>
      <div className="absolute bottom-5 left-16 text-xs font-semibold tracking-widest text-white/40">NITRO LEAGUE © 2026 · silnik fizyki i grafika 3D w przeglądarce</div>
      <button onClick={onFullscreen} className="absolute right-6 top-5 rounded border border-white/20 bg-black/30 px-4 py-1.5 text-xs font-bold tracking-[0.2em] text-white/80 transition hover:bg-white/15">
        ⛶ PEŁNY EKRAN
      </button>
      <div className="absolute bottom-6 right-8 max-w-sm text-right text-sm font-semibold text-white/60">
        <span className="font-display text-[10px] tracking-[0.4em] text-cyan-300/80">WSKAZÓWKA</span>
        <br />
        Zbieraj pady boostu i lataj po ścianach. Uderz w przeciwnika z prędkością ponaddźwiękową, aby go zdemolować!
      </div>
    </div>
  );
}

/* ---------- ustawienia meczu ---------- */
export function SetupScreen({
  match,
  onChange,
  onStart,
  onBack,
}: {
  match: MatchSettings;
  onChange: (m: MatchSettings) => void;
  onStart: () => void;
  onBack: () => void;
}) {
  const set = (p: Partial<MatchSettings>) => onChange({ ...match, ...p });
  return (
    <Panel title="MECZ TOWARZYSKI" onBack={onBack}>
      <Label>TRYB GRY</Label>
      <div className="flex gap-3">
        {[1, 2, 3].map((n) => (
          <Card key={n} active={match.mode === n} onClick={() => set({ mode: n })}>
            <div className="font-display text-3xl font-black italic">
              {n}<span className="text-white/40"> v </span>{n}
            </div>
            <div className="mt-1 text-[11px] font-bold tracking-widest text-white/50">{n === 1 ? 'POJEDYNEK' : n === 2 ? 'DRUŻYNA' : 'PEŁNA EKIPA'}</div>
          </Card>
        ))}
      </div>
      <Label>POZIOM BOTÓW</Label>
      <div className="flex gap-3">
        {['POCZĄTKUJĄCY', 'ZAWODOWIEC', 'LEGENDA'].map((n, i) => (
          <Card key={n} active={match.difficulty === i} onClick={() => set({ difficulty: i })}>
            <div className="font-display text-sm font-black tracking-widest">{n}</div>
            <div className="mt-1 flex justify-center gap-1">
              {[0, 1, 2].map((k) => (
                <span key={k} className={`h-1.5 w-6 rounded-full ${k <= i ? 'bg-cyan-300 shadow-[0_0_8px_#38e1ff]' : 'bg-white/15'}`} />
              ))}
            </div>
          </Card>
        ))}
      </div>
      <Label>CZAS MECZU</Label>
      <div className="flex gap-3">
        {[3, 5, 10].map((n) => (
          <Card key={n} active={match.minutes === n} onClick={() => set({ minutes: n })}>
            <div className="font-display text-2xl font-black">{n}:00</div>
            <div className="text-[11px] font-bold tracking-widest text-white/50">MINUT</div>
          </Card>
        ))}
      </div>
      <Label>TWOJA DRUŻYNA</Label>
      <div className="flex gap-3">
        {[0, 1].map((t) => (
          <Card key={t} active={match.team === t} color={TEAM_HEX[t]} onClick={() => set({ team: t })}>
            <div className="font-display text-base font-black tracking-[0.2em]" style={{ color: t === 0 ? '#9cc2ff' : '#ffc38a' }}>
              {t === 0 ? 'NIEBIESCY' : 'POMARAŃCZOWI'}
            </div>
          </Card>
        ))}
      </div>
      <div className="mt-7">
        <MenuButton primary onClick={onStart}>
          ROZPOCZNIJ MECZ
        </MenuButton>
      </div>
    </Panel>
  );
}

/* ---------- garaż ---------- */
export function GarageScreen({
  garage,
  team,
  onChange,
  onTeam,
  onBack,
}: {
  garage: GarageSettings;
  team: number;
  onChange: (g: Partial<GarageSettings>) => void;
  onTeam: (t: number) => void;
  onBack: () => void;
}) {
  const desc = ['Uniwersalny hatchback', 'Niski i szeroki muscle car', 'Agresywny klin z płetwą'];
  return (
    <Panel title="GARAŻ" width={520} onBack={onBack}>
      <Label>NADWOZIE</Label>
      <div className="flex flex-col gap-2">
        {BODY_NAMES.map((n, i) => (
          <Card key={n} active={garage.body === i} onClick={() => onChange({ body: i })} className="!text-left">
            <div className="flex items-baseline justify-between">
              <span className="font-display text-lg font-black italic tracking-widest">{n.toUpperCase()}</span>
              <span className="text-xs font-semibold text-white/50">{desc[i]}</span>
            </div>
          </Card>
        ))}
      </div>
      <Label>KOLOR AKCENTU · NEON · PŁOMIEŃ</Label>
      <div className="flex flex-wrap gap-2.5">
        {ACCENTS.map((c) => (
          <button
            key={c}
            onClick={() => onChange({ accent: c })}
            className={`h-9 w-9 rounded-full border-2 transition-transform hover:scale-110 ${garage.accent === c ? 'scale-110 border-white' : 'border-transparent'}`}
            style={{ background: c, boxShadow: garage.accent === c ? `0 0 18px ${c}` : 'none' }}
            aria-label={c}
          />
        ))}
      </div>
      <Label>FELGI</Label>
      <div className="flex gap-3">
        {['5 RAMION', 'TURBINA', 'GŁĘBOKIE'].map((n, i) => (
          <Card key={n} active={garage.wheel === i} onClick={() => onChange({ wheel: i })}>
            <div className="font-display text-xs font-black tracking-widest">{n}</div>
          </Card>
        ))}
      </div>
      <Label>PODGLĄD BARW DRUŻYNY</Label>
      <div className="flex gap-3">
        {[0, 1].map((t) => (
          <Card key={t} active={team === t} color={TEAM_HEX[t]} onClick={() => onTeam(t)}>
            <div className="font-display text-xs font-black tracking-[0.2em]">{t === 0 ? 'NIEBIESCY' : 'POMARAŃCZOWI'}</div>
          </Card>
        ))}
      </div>
      <p className="mt-5 text-xs font-semibold tracking-wide text-white/50">Zmiany zapisują się automatycznie i obowiązują we wszystkich meczach.</p>
    </Panel>
  );
}

/* ---------- sterowanie ---------- */
export function ControlsScreen({ onBack }: { onBack: () => void }) {
  const rows: [string[], string][] = [
    [['W', '↑'], 'Gaz · w powietrzu: nos w dół'],
    [['S', '↓'], 'Hamulec / wsteczny · w powietrzu: nos w górę'],
    [['A', 'D'], 'Skręt · w powietrzu: obrót w bok (yaw)'],
    [['SPACJA'], 'Skok · drugi raz + kierunek = DODGE / FLIP'],
    [['SHIFT', 'LPM'], 'Boost (przyspieszenie także w powietrzu)'],
    [['X', 'CTRL'], 'Ręczny — poślizg. W powietrzu + A/D = przechył'],
    [['Q', 'E'], 'Przechył w powietrzu (lewo / prawo)'],
    [['C', 'PPM'], 'Przełącz kamerę: na piłkę / na auto'],
    [['R'], 'Odwróć auto (co 3 s)'],
    [['TAB'], 'Tabela wyników (przytrzymaj)'],
    [['ESC', 'P'], 'Pauza'],
  ];
  return (
    <Panel title="STEROWANIE" width={760} onBack={onBack}>
      <div className="grid gap-x-8 gap-y-2 md:grid-cols-1">
        {rows.map(([keys, txt]) => (
          <div key={txt} className="flex items-center gap-4 border-b border-white/5 py-1.5">
            <div className="flex w-44 shrink-0 gap-1.5">
              {keys.map((k) => (
                <kbd key={k}>{k}</kbd>
              ))}
            </div>
            <span className="text-sm font-semibold text-white/80">{txt}</span>
          </div>
        ))}
      </div>
      <Label>PAD (XBOX / PS)</Label>
      <p className="text-sm font-semibold leading-relaxed text-white/70">
        Lewa gałka — skręt i pochylenie · RT/LT — gaz i wsteczny · A/✕ — skok i flip · B/X (○/□) — boost · LB/RB — poślizg · Y/△ — kamera · Start — pauza.
      </p>
      <Label>PORADY</Label>
      <ul className="list-disc space-y-1 pl-5 text-sm font-semibold text-white/70">
        <li>Jedź na ścianę z prędkością — auto „przykleja się” do powierzchni i możesz ścigać piłkę pod sufitem.</li>
        <li>Po skoku masz około sekundy na flip. Flip do przodu w piłkę = najmocniejsze uderzenie.</li>
        <li>Z boostem osiągniesz prędkość ponaddźwiękową — zderzenie z przeciwnikiem demoluje jego auto.</li>
        <li>Duże pady boostu (świecące kule) dają 100, małe — 12.</li>
      </ul>
    </Panel>
  );
}

/* ---------- ustawienia ---------- */
function Slider({ value, min, max, step = 1, onChange, suffix = '' }: { value: number; min: number; max: number; step?: number; onChange: (v: number) => void; suffix?: string }) {
  const p = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex items-center gap-4">
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} className="flex-1" style={{ ['--p' as string]: `${p}%` }} />
      <span className="w-14 text-right font-display text-sm font-bold">
        {Math.round(value * (max <= 1 ? 100 : 1))}
        {suffix}
      </span>
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button onClick={() => onChange(!on)} className="flex w-full items-center justify-between rounded border border-white/10 bg-white/[0.04] px-4 py-2.5 transition hover:bg-white/10">
      <span className="text-sm font-bold tracking-wider">{label}</span>
      <span className={`relative h-6 w-11 rounded-full transition ${on ? 'bg-cyan-400 shadow-[0_0_12px_#38e1ff]' : 'bg-white/20'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${on ? 'left-[22px]' : 'left-0.5'}`} />
      </span>
    </button>
  );
}

export function SettingsBody({ settings, onChange }: { settings: GameSettings; onChange: (s: Partial<GameSettings>) => void }) {
  return (
    <>
      <Label>JAKOŚĆ GRAFIKI</Label>
      <div className="flex gap-3">
        {['NISKA', 'WYSOKA', 'ULTRA'].map((n, i) => (
          <Card key={n} active={settings.quality === i} onClick={() => onChange({ quality: i })}>
            <div className="font-display text-sm font-black tracking-widest">{n}</div>
            <div className="mt-0.5 text-[10px] font-semibold text-white/50">{i === 0 ? 'bez bloom' : i === 1 ? 'bloom + cienie' : 'MSAA + 2× DPI'}</div>
          </Card>
        ))}
      </div>
      <Label>GŁOŚNOŚĆ</Label>
      <Slider value={settings.volume} min={0} max={1} step={0.01} suffix="%" onChange={(v) => onChange({ volume: v })} />
      <Label>POLE WIDZENIA (FOV)</Label>
      <Slider value={settings.fov} min={60} max={100} step={1} suffix="°" onChange={(v) => onChange({ fov: v })} />
      <div className="mt-5 flex flex-col gap-2">
        <Toggle on={settings.music} onChange={(v) => onChange({ music: v })} label="MUZYKA" />
        <Toggle on={settings.shake} onChange={(v) => onChange({ shake: v })} label="DRŻENIE KAMERY" />
        <Toggle on={settings.showFps} onChange={(v) => onChange({ showFps: v })} label="LICZNIK FPS" />
      </div>
    </>
  );
}

export function SettingsScreen({ settings, onChange, onBack }: { settings: GameSettings; onChange: (s: Partial<GameSettings>) => void; onBack: () => void }) {
  return (
    <Panel title="USTAWIENIA" width={560} onBack={onBack}>
      <SettingsBody settings={settings} onChange={onChange} />
    </Panel>
  );
}

/* ---------- pauza ---------- */
export function PauseMenu({
  settings,
  onChange,
  onResume,
  onRestart,
  onQuit,
}: {
  settings: GameSettings;
  onChange: (s: Partial<GameSettings>) => void;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/65 backdrop-blur-sm">
      <div className="glass anim-fade-up flex w-[860px] max-w-[95vw] gap-8 p-8">
        <div className="flex w-[330px] shrink-0 flex-col gap-3">
          <h2 className="font-display mb-3 text-4xl font-black italic tracking-[0.2em] text-white">PAUZA</h2>
          <MenuButton primary onClick={onResume}>
            WZNÓW
          </MenuButton>
          <MenuButton onClick={onRestart}>RESTART MECZU</MenuButton>
          <MenuButton onClick={onQuit}>WYJDŹ DO MENU</MenuButton>
          <p className="mt-3 text-xs font-semibold tracking-wide text-white/40">
            <kbd>ESC</kbd> — wznów grę
          </p>
        </div>
        <div className="min-w-0 flex-1">
          <SettingsBody settings={settings} onChange={onChange} />
        </div>
      </div>
    </div>
  );
}
