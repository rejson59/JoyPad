import { useEffect, useRef, useState } from 'react';
import { Game, CLASSES, ShipClass, Upgrades } from './game/Game';

interface Save { credits: number; xp: number; battles: number; wins: number; owned: ShipClass[]; up: Record<ShipClass, Upgrades>; }
const DEF: Save = { credits: 1500, xp: 0, battles: 0, wins: 0, owned: ['fighter'], up: { interceptor: { guns: 0, armor: 0, engine: 0 }, fighter: { guns: 0, armor: 0, engine: 0 }, heavy: { guns: 0, armor: 0, engine: 0 } } };
const load = (): Save => { try { return { ...DEF, ...JSON.parse(localStorage.getItem('starclash-save') || '') }; } catch { return DEF; } };
const upCost = (lvl: number) => 600 + lvl * 700;
const MOD = { guns: ['Działa laserowe', '+12% obrażeń'], armor: ['Pancerz i tarcza', '+12% HP / tarczy'], engine: ['Silniki fuzyjne', '+7% prędkości, +5% zwrotności'] } as const;

function Bar({ v, max, color, label }: { v: number; max: number; color: string; label: string }) {
  return (
    <div className="w-64">
      <div className="flex justify-between text-[10px] tracking-widest text-cyan-100/70"><span>{label}</span><span>{Math.max(0, Math.round(v))}/{Math.round(max)}</span></div>
      <div className="h-2 bg-black/60 border border-white/10 skew-x-[-20deg] overflow-hidden"><div className="h-full transition-all duration-150" style={{ width: `${Math.max(0, (v / max) * 100)}%`, background: color, boxShadow: `0 0 10px ${color}` }} /></div>
    </div>
  );
}

export default function App() {
  const ref = useRef<HTMLDivElement>(null);
  const game = useRef<Game | null>(null);
  const [save, setSave] = useState<Save>(load);
  const [sel, setSel] = useState<ShipClass>('fighter');
  const [screen, setScreen] = useState<'hangar' | 'battle' | 'end'>('hangar');
  const [hud, setHud] = useState<any>({});
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [tab, setTab] = useState(false);

  useEffect(() => { localStorage.setItem('starclash-save', JSON.stringify(save)); }, [save]);
  useEffect(() => {
    const g = new Game(ref.current!); game.current = g;
    g.onHud = setHud; g.onPause = setPaused;
    const kd = (e: KeyboardEvent) => { if (e.code === 'Tab') { e.preventDefault(); setTab(true); } };
    const ku = (e: KeyboardEvent) => { if (e.code === 'Tab') setTab(false); };
    addEventListener('keydown', kd); addEventListener('keyup', ku);
    return () => { removeEventListener('keydown', kd); removeEventListener('keyup', ku); };
  }, []);
  useEffect(() => {
    if (!game.current) return;
    game.current.onEnd = (r: any) => {
      setResult(r); setScreen('end');
      setSave((s) => ({ ...s, credits: s.credits + r.credits, xp: s.xp + r.xp, battles: s.battles + 1, wins: s.wins + (r.win ? 1 : 0) }));
    };
  });

  const pick = (c: ShipClass) => { setSel(c); game.current?.setHangarShip(c); };
  const owned = save.owned.includes(sel);
  const buy = () => { const p = CLASSES[sel].price; if (save.credits >= p) setSave({ ...save, credits: save.credits - p, owned: [...save.owned, sel] }); };
  const upgrade = (k: keyof Upgrades) => {
    const lvl = save.up[sel][k]; const cost = upCost(lvl);
    if (lvl >= 5 || save.credits < cost) return;
    setSave({ ...save, credits: save.credits - cost, up: { ...save.up, [sel]: { ...save.up[sel], [k]: lvl + 1 } } });
  };
  const start = () => { setScreen('battle'); setPaused(false); game.current!.startBattle(sel, save.up[sel], save.battles); };
  const toHangar = () => { setScreen('hangar'); setPaused(false); game.current!.setHangarShip(sel); };

  const c = CLASSES[sel]; const u = save.up[sel];
  const rank = Math.floor(Math.sqrt(save.xp / 200)) + 1;

  return (
    <div className="fixed inset-0 bg-black overflow-hidden select-none font-sans text-white">
      <div ref={ref} className="absolute inset-0" />

      {screen === 'hangar' && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 inset-x-0 flex items-center justify-between px-8 py-4 bg-gradient-to-b from-black/80 to-transparent pointer-events-auto">
            <div>
              <div className="text-3xl font-black tracking-[0.3em] bg-gradient-to-r from-cyan-300 to-blue-500 bg-clip-text text-transparent">STAR CLASH</div>
              <div className="text-[10px] tracking-[0.5em] text-cyan-200/60">WORLD OF STARSHIPS · HANGAR</div>
            </div>
            <div className="flex gap-6 text-sm">
              <div><span className="text-white/50">RANGA </span><b className="text-cyan-300">{rank}</b></div>
              <div><span className="text-white/50">BITWY </span><b>{save.battles}</b> <span className="text-white/50">WYGRANE </span><b className="text-green-400">{save.wins}</b></div>
              <div><span className="text-white/50">XP </span><b>{save.xp}</b></div>
              <div className="text-yellow-300 font-bold">◈ {save.credits.toLocaleString()} CR</div>
            </div>
          </div>

          <div className="absolute left-8 top-28 w-80 space-y-3 pointer-events-auto">
            <div className="text-xs tracking-[0.3em] text-white/50">WYBÓR STATKU</div>
            {(Object.keys(CLASSES) as ShipClass[]).map((k) => (
              <button key={k} onClick={() => pick(k)} className={`w-full text-left p-3 border backdrop-blur-md transition ${sel === k ? 'border-cyan-400 bg-cyan-500/20 shadow-[0_0_20px_rgba(0,200,255,0.3)]' : 'border-white/10 bg-black/50 hover:border-white/30'}`}>
                <div className="flex justify-between"><b>{CLASSES[k].name}</b>{!save.owned.includes(k) && <span className="text-yellow-300 text-xs">◈ {CLASSES[k].price}</span>}</div>
                <div className="text-[11px] text-white/50 uppercase tracking-wider">{k === 'interceptor' ? 'Lekki · szybki · kruchy' : k === 'fighter' ? 'Średni · wszechstronny' : 'Ciężki · potężne działa'}</div>
              </button>
            ))}
            <div className="p-4 bg-black/60 border border-white/10 backdrop-blur-md text-sm space-y-1.5">
              {[['Kadłub', Math.round(c.hp * (1 + u.armor * 0.12)), 260], ['Tarcza', Math.round(c.shield * (1 + u.armor * 0.12)), 130], ['Prędkość', Math.round(c.speed * (1 + u.engine * 0.07)), 125], ['Obrażenia', Math.round(c.dmg * (1 + u.guns * 0.12)), 30], ['Szybkostrzelność', Math.round(60 / c.rate), 720], ['Zwrotność', +(c.turn * (1 + u.engine * 0.05)).toFixed(2), 3]].map(([n, v, m]) => (
                <div key={n as string}><div className="flex justify-between text-xs"><span className="text-white/60">{n}</span><span>{v}</span></div>
                  <div className="h-1 bg-white/10"><div className="h-full bg-cyan-400" style={{ width: `${Math.min(100, (+v / +m) * 100)}%` }} /></div></div>
              ))}
              <div className="flex justify-between text-xs pt-1"><span className="text-white/60">Rakiety</span><span>{c.missiles}</span></div>
            </div>
          </div>

          <div className="absolute right-8 top-28 w-80 space-y-3 pointer-events-auto">
            <div className="text-xs tracking-[0.3em] text-white/50">MODUŁY · ULEPSZENIA</div>
            {(Object.keys(MOD) as (keyof Upgrades)[]).map((k) => (
              <div key={k} className="p-3 bg-black/60 border border-white/10 backdrop-blur-md">
                <div className="flex justify-between"><b className="text-sm">{MOD[k][0]}</b><span className="text-xs text-cyan-300">Poz. {u[k]}/5</span></div>
                <div className="text-[11px] text-white/50">{MOD[k][1]} / poziom</div>
                <div className="flex gap-1 my-2">{[0, 1, 2, 3, 4].map((i) => <div key={i} className={`h-1.5 flex-1 ${i < u[k] ? 'bg-cyan-400' : 'bg-white/10'}`} />)}</div>
                <button disabled={!owned || u[k] >= 5 || save.credits < upCost(u[k])} onClick={() => upgrade(k)} className="w-full text-xs py-1.5 bg-cyan-600/40 border border-cyan-400/40 disabled:opacity-30 hover:bg-cyan-500/50">
                  {u[k] >= 5 ? 'MAKSYMALNY' : `ULEPSZ · ◈ ${upCost(u[k])}`}
                </button>
              </div>
            ))}
            <div className="p-3 bg-black/50 border border-white/10 text-[11px] text-white/60 leading-relaxed">
              <b className="text-white/80">STEROWANIE</b><br />Mysz — kierunek lotu · LPM / Spacja — działa<br />PPM / F — rakieta (namierz cel trzymając go w celowniku)<br />W/S — ciąg · Shift — dopalacz · A/D — obrót<br />Q/E — ruch boczny · R — zmień cel · Tab — tabela · Esc — pauza
            </div>
          </div>

          <div className="absolute bottom-10 inset-x-0 flex justify-center pointer-events-auto">
            {owned ? (
              <button onClick={start} className="px-20 py-4 text-2xl font-black tracking-[0.4em] bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 skew-x-[-12deg] shadow-[0_0_40px_rgba(255,90,30,0.6)] border border-orange-300/50">DO BITWY!</button>
            ) : (
              <button onClick={buy} disabled={save.credits < c.price} className="px-16 py-4 text-xl font-black tracking-[0.3em] bg-yellow-600/80 disabled:opacity-40 skew-x-[-12deg] border border-yellow-300/50">KUP · ◈ {c.price}</button>
            )}
          </div>
        </div>
      )}

      {screen === 'battle' && hud.mode === 'battle' && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-4 text-sm font-bold">
            <div className="flex gap-1">{Array.from({ length: 6 }).map((_, i) => <div key={i} className={`w-3 h-5 skew-x-[-15deg] ${i < hud.allies ? 'bg-blue-400 shadow-[0_0_8px_#4af]' : 'bg-white/10'}`} />)}</div>
            <div className="px-4 py-1 bg-black/60 border border-white/15 font-mono">{String(Math.floor(hud.time / 60)).padStart(2, '0')}:{String(hud.time % 60).padStart(2, '0')}</div>
            <div className="flex gap-1">{Array.from({ length: 6 }).map((_, i) => <div key={i} className={`w-3 h-5 skew-x-[-15deg] ${i < hud.enemies ? 'bg-red-500 shadow-[0_0_8px_#f43]' : 'bg-white/10'}`} />)}</div>
          </div>
          {hud.msg && <div className="absolute top-20 left-1/2 -translate-x-1/2 text-lg font-bold tracking-[0.2em] text-amber-300 drop-shadow-[0_0_8px_rgba(255,180,0,0.8)] text-center">{hud.msg}</div>}
          {hud.bounds && <div className="absolute top-32 left-1/2 -translate-x-1/2 text-red-500 font-black tracking-widest animate-pulse">⚠ OPUSZCZASZ STREFĘ WALKI — ZAWRÓĆ</div>}
          <div className="absolute top-4 right-4 w-72 space-y-1">
            {hud.killfeed?.map((k: any, i: number) => (
              <div key={i} className="text-xs bg-black/50 px-2 py-1 flex gap-2 justify-end" style={{ opacity: Math.min(1, k.t) }}>
                <span className={k.at === 0 ? 'text-blue-300' : k.at === 1 ? 'text-red-400' : 'text-gray-400'}>{k.a}</span><span className="text-white/50">✹</span><span className={k.bt === 0 ? 'text-blue-300' : 'text-red-400'}>{k.b}</span>
              </div>
            ))}
          </div>
          {hud.target && (
            <div className="absolute top-16 left-4 p-3 bg-black/55 border-l-2 border-red-500 w-60 backdrop-blur-sm">
              <div className="text-[10px] tracking-widest text-red-300/70">CEL</div>
              <div className="font-bold">{hud.target.name}</div>
              <div className="text-[11px] text-white/60">{hud.target.cls} · {hud.target.dist} m</div>
              <div className="h-1 bg-white/10 mt-2"><div className="h-full bg-sky-400" style={{ width: `${hud.target.sh * 100}%` }} /></div>
              <div className="h-1.5 bg-white/10 mt-1"><div className="h-full bg-red-500" style={{ width: `${hud.target.hp * 100}%` }} /></div>
            </div>
          )}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-end gap-10">
            <div className="space-y-2">
              <Bar v={hud.sh} max={hud.maxSh} color="#38bdf8" label="TARCZA" />
              <Bar v={hud.hp} max={hud.maxHp} color={hud.hp / hud.maxHp < 0.3 ? '#ef4444' : '#22c55e'} label="KADŁUB" />
            </div>
            <div className="text-center">
              <div className="text-5xl font-black font-mono tabular-nums drop-shadow-[0_0_10px_rgba(0,200,255,0.6)]">{hud.speed}</div>
              <div className="text-[10px] tracking-[0.4em] text-cyan-200/60">KM/H {hud.boosting && <span className="text-orange-400">· BOOST</span>}</div>
              <div className="w-40 h-1 bg-white/10 mt-1"><div className="h-full bg-cyan-300" style={{ width: `${hud.throttle * 100}%` }} /></div>
            </div>
            <div className="space-y-2">
              <Bar v={hud.energy * 100} max={100} color="#f59e0b" label="DOPALACZ" />
              <div className="w-64 flex justify-between text-xs"><span className="text-white/60">RAKIETY</span><span className="font-bold">{'▮'.repeat(hud.missiles)}<span className="text-white/20">{hud.missiles === 0 ? 'BRAK' : ''}</span></span></div>
              <div className="w-64 flex justify-between text-xs"><span className="text-white/60">ZESTRZELENIA</span><span className="font-bold text-amber-300">{hud.kills}</span></div>
            </div>
          </div>
          {hud.hp / hud.maxHp < 0.3 && !hud.dead && <div className="absolute inset-0 shadow-[inset_0_0_150px_rgba(255,0,0,0.5)] animate-pulse" />}
          {hud.dead && <div className="absolute inset-0 flex items-center justify-center bg-red-950/20"><div className="text-4xl font-black tracking-[0.3em] text-red-500">ZESTRZELONY — TRYB OBSERWATORA</div></div>}
          {tab && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <div className="grid grid-cols-2 gap-6 p-6 bg-black/80 border border-white/15 min-w-[600px]">
                {[0, 1].map((t) => (
                  <div key={t}><div className={`font-bold mb-2 ${t ? 'text-red-400' : 'text-blue-300'}`}>{t ? 'WRÓG' : 'SOJUSZNICY'}</div>
                    {hud.roster.filter((r: any) => r.team === t).map((r: any, i: number) => (
                      <div key={i} className={`flex justify-between text-sm py-0.5 ${r.dead ? 'line-through text-white/30' : ''} ${r.me ? 'text-yellow-300' : ''}`}><span>{r.name} <span className="text-white/40 text-xs">{r.cls}</span></span><span>{r.kills}</span></div>
                    ))}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {screen === 'battle' && paused && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm gap-4">
          <div className="text-5xl font-black tracking-[0.4em]">PAUZA</div>
          <button onClick={() => game.current!.resume()} className="px-12 py-3 bg-cyan-600 hover:bg-cyan-500 font-bold tracking-widest">WZNÓW (kliknij)</button>
          <button onClick={toHangar} className="px-12 py-3 bg-white/10 hover:bg-white/20 font-bold tracking-widest">OPUŚĆ BITWĘ</button>
        </div>
      )}

      {screen === 'end' && result && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="text-center p-10 bg-black/70 border border-white/15 min-w-[460px]">
            <div className={`text-6xl font-black tracking-[0.3em] ${result.win ? 'text-green-400' : 'text-red-500'}`}>{result.win ? 'ZWYCIĘSTWO' : 'PORAŻKA'}</div>
            <div className="text-white/50 mt-2 mb-6">{result.survived ? 'Przetrwałeś bitwę' : 'Twój statek został zniszczony'} · {Math.floor(result.time / 60)}m {result.time % 60}s</div>
            <div className="grid grid-cols-3 gap-4 mb-6">
              {[['ZESTRZELENIA', result.kills], ['OBRAŻENIA', result.damage], ['CELNOŚĆ', result.accuracy + '%']].map(([a, b]) => (
                <div key={a} className="p-3 bg-white/5"><div className="text-[10px] tracking-widest text-white/50">{a}</div><div className="text-2xl font-bold">{b}</div></div>
              ))}
            </div>
            <div className="text-yellow-300 text-xl font-bold">+ ◈ {result.credits} CR</div>
            <div className="text-cyan-300 mb-6">+ {result.xp} XP</div>
            <button onClick={toHangar} className="px-12 py-3 bg-cyan-600 hover:bg-cyan-500 font-bold tracking-widest">POWRÓT DO HANGARU</button>
          </div>
        </div>
      )}
    </div>
  );
}
