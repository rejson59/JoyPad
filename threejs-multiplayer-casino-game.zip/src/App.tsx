import { useEffect, useState } from "react";
import { useGame } from "./game/store";
import { initInput } from "./game/input";
import { isMuted, setMuted } from "./game/audio";
import { CasinoScene } from "./three/CasinoScene";
import { HUD } from "./ui/HUD";
import { GameOverlay } from "./ui/GameOverlay";
import { MainMenu } from "./ui/MainMenu";
import { Lobby } from "./ui/Lobby";
import { DaySummary, GameOver, Victory } from "./ui/Screens";

export default function App() {
  const screen = useGame((s) => s.screen);
  const [muted, setM] = useState(false);
  useEffect(() => {
    initInput();
  }, []);
  const inWorld = screen === "game" || screen === "summary" || screen === "victory" || screen === "gameover";
  return (
    <div className="fixed inset-0 bg-black overflow-hidden font-sans">
      {inWorld && <CasinoScene />}
      {screen === "game" && (
        <>
          <HUD />
          <GameOverlay />
        </>
      )}
      {screen === "menu" && <MainMenu />}
      {screen === "lobby" && <Lobby />}
      {screen === "summary" && <DaySummary />}
      {screen === "gameover" && <GameOver />}
      {screen === "victory" && <Victory />}
      <button
        onClick={(e) => {
          setMuted(!isMuted());
          setM(isMuted());
          e.currentTarget.blur();
        }}
        className="absolute bottom-2 right-2 z-50 w-9 h-9 rounded-full bg-black/60 border border-white/20 text-white/70 hover:text-white text-base"
        title="Dźwięk"
      >
        {muted ? "🔇" : "🔊"}
      </button>
    </div>
  );
}
