// Lightweight procedural audio engine (no external assets needed)
let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let musicNodes: { osc: OscillatorNode; gain: GainNode }[] = [];
let musicTimer: number | null = null;
let muted = false;

function ac() {
  if (!ctx) {
    ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

export function setMuted(m: boolean) {
  muted = m;
  if (master) master.gain.value = m ? 0 : 0.5;
}
export function isMuted() {
  return muted;
}

function tone(freq: number, dur: number, type: OscillatorType = "sine", vol = 0.3, when = 0, slide?: number) {
  try {
    const c = ac();
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, c.currentTime + when);
    if (slide) o.frequency.exponentialRampToValueAtTime(slide, c.currentTime + when + dur);
    g.gain.setValueAtTime(0, c.currentTime + when);
    g.gain.linearRampToValueAtTime(vol, c.currentTime + when + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + when + dur);
    o.connect(g);
    g.connect(master!);
    o.start(c.currentTime + when);
    o.stop(c.currentTime + when + dur + 0.05);
  } catch {
    /* ignore */
  }
}

function noise(dur: number, vol = 0.2, when = 0) {
  try {
    const c = ac();
    const buf = c.createBuffer(1, c.sampleRate * dur, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    const s = c.createBufferSource();
    s.buffer = buf;
    const g = c.createGain();
    g.gain.value = vol;
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 1800;
    s.connect(f);
    f.connect(g);
    g.connect(master!);
    s.start(c.currentTime + when);
  } catch {
    /* ignore */
  }
}

export const sfx = {
  click: () => tone(880, 0.05, "square", 0.08),
  move: () => tone(520, 0.04, "triangle", 0.07),
  back: () => tone(300, 0.08, "square", 0.08, 0, 200),
  coin: () => {
    tone(1200, 0.08, "square", 0.12);
    tone(1800, 0.14, "square", 0.12, 0.06);
  },
  coins: () => {
    for (let i = 0; i < 8; i++) tone(1000 + Math.random() * 1200, 0.08, "square", 0.08, i * 0.05);
  },
  bigwin: () => {
    const notes = [523, 659, 784, 1046, 784, 1046, 1318, 1568];
    notes.forEach((n, i) => tone(n, 0.25, "square", 0.15, i * 0.09));
    for (let i = 0; i < 20; i++) tone(1500 + Math.random() * 1500, 0.06, "square", 0.06, 0.6 + i * 0.04);
  },
  lose: () => {
    tone(300, 0.25, "sawtooth", 0.12, 0, 150);
    tone(200, 0.4, "sawtooth", 0.1, 0.2, 80);
  },
  reel: () => tone(200 + Math.random() * 100, 0.03, "square", 0.05),
  reelStop: () => {
    tone(150, 0.08, "square", 0.15);
    noise(0.05, 0.1);
  },
  card: () => noise(0.08, 0.25),
  chip: () => {
    tone(2400, 0.03, "sine", 0.1);
    tone(3100, 0.04, "sine", 0.08, 0.03);
  },
  dice: () => {
    for (let i = 0; i < 6; i++) noise(0.04, 0.2, i * 0.07);
  },
  wheelTick: () => tone(1400, 0.02, "square", 0.05),
  register: () => {
    tone(1500, 0.08, "square", 0.1);
    tone(2000, 0.08, "square", 0.1, 0.1);
    noise(0.15, 0.2, 0.2);
  },
  drink: () => {
    tone(600, 0.1, "sine", 0.1, 0, 900);
    tone(400, 0.15, "sine", 0.1, 0.15, 700);
  },
  saw: () => {
    for (let i = 0; i < 10; i++) noise(0.08, 0.3, i * 0.06);
    tone(120, 0.6, "sawtooth", 0.15, 0, 60);
  },
  alarm: () => {
    for (let i = 0; i < 4; i++) {
      tone(900, 0.15, "square", 0.12, i * 0.3);
      tone(700, 0.15, "square", 0.12, i * 0.3 + 0.15);
    }
  },
  event: () => {
    tone(660, 0.1, "triangle", 0.15);
    tone(880, 0.15, "triangle", 0.15, 0.1);
  },
  fanfare: () => {
    [392, 523, 659, 784, 1046].forEach((n, i) => tone(n, 0.35, "square", 0.15, i * 0.13));
    tone(1046, 0.8, "square", 0.15, 0.7);
  },
  sad: () => {
    [392, 370, 349, 330].forEach((n, i) => tone(n, 0.4, "sawtooth", 0.1, i * 0.35));
  },
};

// ─── Ambient music: lo-fi jazz-ish chord loop ───
const SCALES = [
  [220, 261.6, 329.6, 392],
  [196, 246.9, 293.7, 349.2],
  [174.6, 220, 261.6, 329.6],
  [164.8, 196, 246.9, 293.7],
  [233.1, 293.7, 349.2, 440],
];

export function startMusic(style = 0) {
  stopMusic();
  try {
    const c = ac();
    const chords = SCALES;
    let step = 0;
    const tempo = 520 + style * 40;
    const play = () => {
      const chord = chords[(step + style) % chords.length];
      musicNodes.forEach((n) => {
        try {
          n.gain.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 1.2);
          n.osc.stop(c.currentTime + 1.3);
        } catch {
          /* ignore */
        }
      });
      musicNodes = [];
      chord.forEach((f, i) => {
        const o = c.createOscillator();
        const g = c.createGain();
        o.type = i === 0 ? "triangle" : "sine";
        o.frequency.value = f * (i === 0 ? 0.5 : 1);
        g.gain.setValueAtTime(0.0001, c.currentTime);
        g.gain.exponentialRampToValueAtTime(i === 0 ? 0.08 : 0.035, c.currentTime + 0.4);
        o.connect(g);
        g.connect(master!);
        o.start();
        musicNodes.push({ osc: o, gain: g });
      });
      // bass pluck + hi-hat
      tone(chord[0] * 0.25, 0.4, "sawtooth", 0.06);
      noise(0.03, 0.05, tempo / 1000);
      tone(chord[(step * 3) % 4] * 2, 0.3, "triangle", 0.03, tempo / 2000);
      step++;
    };
    play();
    musicTimer = window.setInterval(play, tempo * 4);
  } catch {
    /* ignore */
  }
}

export function stopMusic() {
  if (musicTimer) clearInterval(musicTimer);
  musicTimer = null;
  musicNodes.forEach((n) => {
    try {
      n.osc.stop();
    } catch {
      /* ignore */
    }
  });
  musicNodes = [];
}
