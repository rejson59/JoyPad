// ─── Core data for "Bezdomni w Kasynie" ────────────────────────────────────

export type PlayerId = 0 | 1 | 2 | 3;

export interface Avatar {
  skin: number;
  hair: number;
  hairColor: number;
  outfit: number;
  hat: number;
  glasses: number;
  beard: number;
  chain: boolean;
}

export interface Limbs {
  leftArm: boolean;
  rightArm: boolean;
  leftLeg: boolean;
  rightLeg: boolean;
  kidney: boolean;
  soul: boolean;
  teeth: number;
  dignity: number;
}

export type StationType =
  | "slots"
  | "blackjack"
  | "roulette"
  | "dice"
  | "wheel"
  | "poker"
  | "bar"
  | "shop"
  | "pawn"
  | "loan";

export interface Station {
  id: string;
  type: StationType;
  pos: [number, number];
  rot: number;
  label: string;
}

export const PLAYER_COLORS = ["#ff4d6d", "#4dd2ff", "#7cff4d", "#ffd84d"];
export const PLAYER_COLORS_DARK = ["#8a1030", "#0b5e80", "#2f7a12", "#8a6d0b"];

export const KEYMAPS: Record<
  PlayerId,
  { up: string; down: string; left: string; right: string; action: string; cancel: string; label: string }
> = {
  0: { up: "KeyW", down: "KeyS", left: "KeyA", right: "KeyD", action: "KeyE", cancel: "KeyQ", label: "WASD + E / Q" },
  1: { up: "ArrowUp", down: "ArrowDown", left: "ArrowLeft", right: "ArrowRight", action: "Enter", cancel: "ShiftRight", label: "Strzałki + Enter / Shift" },
  2: { up: "KeyI", down: "KeyK", left: "KeyJ", right: "KeyL", action: "KeyO", cancel: "KeyU", label: "IJKL + O / U" },
  3: { up: "KeyT", down: "KeyG", left: "KeyF", right: "KeyH", action: "KeyY", cancel: "KeyR", label: "TFGH + Y / R" },
};

export const SKIN_COLORS = ["#f1c9a5", "#d9a677", "#b57a4a", "#8a5431", "#5b3a21", "#c9e8b0"];
export const HAIR_COLORS = ["#1b1b1b", "#5a3a1a", "#b8862a", "#d9d9d9", "#d63a2f", "#3f8bff", "#c13fff", "#2fd66b"];
export const HAIR_STYLES = ["Łysy", "Krótkie", "Irokez", "Długie", "Afro", "Kok"];
export const BEARDS = ["Gładki", "Zarost", "Broda", "Wąs hipster"];
export const HATS = ["Brak", "Czapka z daszkiem", "Czapka bezdomnego", "Kapelusz", "Cylinder", "Korona", "Hełm wikinga"];
export const GLASSES = ["Brak", "Okulary", "Przeciwsłoneczne", "Monokl"];
export const OUTFITS = [
  { name: "Łachmany", color: "#5a4a35", price: 0, prestige: 0 },
  { name: "Dres z bazaru", color: "#1d3fb8", price: 600, prestige: 2 },
  { name: "Koszula hawajska", color: "#ff6b3d", price: 2500, prestige: 4 },
  { name: "Garnitur", color: "#1a1a22", price: 12000, prestige: 8 },
  { name: "Smoking z kaszmiru", color: "#2a0f3a", price: 60000, prestige: 15 },
  { name: "Złoty garnitur", color: "#d4a017", price: 300000, prestige: 30 },
];

export const SHOP_HATS = [
  { idx: 1, name: "Czapka z daszkiem", price: 300, prestige: 1 },
  { idx: 3, name: "Kapelusz", price: 2000, prestige: 3 },
  { idx: 4, name: "Cylinder", price: 15000, prestige: 6 },
  { idx: 6, name: "Hełm wikinga", price: 40000, prestige: 8 },
  { idx: 5, name: "Korona", price: 250000, prestige: 20 },
];
export const SHOP_GLASSES = [
  { idx: 1, name: "Okulary", price: 250, prestige: 1 },
  { idx: 2, name: "Przeciwsłoneczne", price: 1800, prestige: 3 },
  { idx: 3, name: "Monokl", price: 9000, prestige: 5 },
];

export interface Casino {
  tier: number;
  name: string;
  subtitle: string;
  target: number;
  minBet: number;
  maxBet: number;
  floor: "carpet_red" | "carpet_lux" | "marble";
  wallColor: string;
  accent: string;
  light: string;
  ambient: number;
  fog: string;
  music: number;
}

export const CASINOS: Casino[] = [
  {
    tier: 0,
    name: "Kasyno „Pod Mostem”",
    subtitle: "Nielegalne, śmierdzi rybą, ale automaty działają",
    target: 2500,
    minBet: 5,
    maxBet: 200,
    floor: "carpet_red",
    wallColor: "#3a2a24",
    accent: "#ff7a1a",
    light: "#ffb36b",
    ambient: 0.35,
    fog: "#1a1210",
    music: 0,
  },
  {
    tier: 1,
    name: "Złoty Kogut",
    subtitle: "Neony, dym i wódka po 5 zł",
    target: 15000,
    minBet: 25,
    maxBet: 1500,
    floor: "carpet_red",
    wallColor: "#2a1f3a",
    accent: "#ff2bd6",
    light: "#ff9ddb",
    ambient: 0.4,
    fog: "#160f1e",
    music: 1,
  },
  {
    tier: 2,
    name: "Royal Flush Palace",
    subtitle: "Tu już nie wpuszczają w klapkach",
    target: 80000,
    minBet: 100,
    maxBet: 8000,
    floor: "carpet_lux",
    wallColor: "#17233f",
    accent: "#3fb6ff",
    light: "#c9e4ff",
    ambient: 0.45,
    fog: "#0d1322",
    music: 2,
  },
  {
    tier: 3,
    name: "Diamentowa Wieża",
    subtitle: "Każdy żeton jest wart więcej niż twój dawny namiot",
    target: 400000,
    minBet: 500,
    maxBet: 50000,
    floor: "marble",
    wallColor: "#1f2b2a",
    accent: "#4dffd2",
    light: "#e8fff9",
    ambient: 0.5,
    fog: "#0e1a19",
    music: 3,
  },
  {
    tier: 4,
    name: "OLIMP – Kasyno Bogów",
    subtitle: "Ostateczne kasyno. Nie ma już dokąd awansować. Tylko wyżej.",
    target: 2000000,
    minBet: 2500,
    maxBet: 500000,
    floor: "marble",
    wallColor: "#2b2414",
    accent: "#ffd84d",
    light: "#fff2c2",
    ambient: 0.6,
    fog: "#1a160a",
    music: 4,
  },
];

export const DAY_LENGTH = 300; // seconds per day

export const STATIONS: Station[] = [
  { id: "slot1", type: "slots", pos: [-14, -9], rot: Math.PI / 2, label: "Automat „Skarpeta Fortuny”" },
  { id: "slot2", type: "slots", pos: [-14, -6], rot: Math.PI / 2, label: "Automat „Wiśniowy Sen”" },
  { id: "slot3", type: "slots", pos: [-14, -3], rot: Math.PI / 2, label: "Automat „Siódemka Zenka”" },
  { id: "slot4", type: "slots", pos: [-14, 0], rot: Math.PI / 2, label: "Automat „Diamentowa Dziura”" },
  { id: "bj", type: "blackjack", pos: [-5, -8], rot: 0, label: "Blackjack" },
  { id: "roulette", type: "roulette", pos: [5, -8], rot: 0, label: "Ruletka" },
  { id: "dice", type: "dice", pos: [-5, 1], rot: 0, label: "Kości" },
  { id: "poker", type: "poker", pos: [5, 1], rot: 0, label: "Video Poker" },
  { id: "wheel", type: "wheel", pos: [14, -7], rot: -Math.PI / 2, label: "Koło Fortuny" },
  { id: "bar", type: "bar", pos: [0, 10], rot: Math.PI, label: "Bar „U Grażyny”" },
  { id: "shop", type: "shop", pos: [14, 2], rot: -Math.PI / 2, label: "Butik „Elegancki Menel”" },
  { id: "pawn", type: "pawn", pos: [-14, 7], rot: Math.PI / 2, label: "Lombard „Części Zamienne”" },
  { id: "loan", type: "loan", pos: [14, 9], rot: -Math.PI / 2, label: "Lichwiarz Zenek" },
];

export const ROOM = { w: 36, d: 28 };

export const SLOT_SYMBOLS = ["🍒", "🍋", "🔔", "🧦", "💎", "7️⃣", "👑"];
export const SLOT_WEIGHTS = [26, 22, 16, 14, 10, 7, 5];
export const SLOT_PAYOUT: Record<string, number> = {
  "🍒": 4,
  "🍋": 6,
  "🔔": 10,
  "🧦": 15,
  "💎": 30,
  "7️⃣": 60,
  "👑": 200,
};

export interface BodyPart {
  key: keyof Limbs;
  name: string;
  price: number;
  desc: string;
}
export const BODY_PARTS: BodyPart[] = [
  { key: "teeth", name: "Złoty ząb", price: 400, desc: "Masz ich kilka. Na razie." },
  { key: "kidney", name: "Nerka", price: 9000, desc: "Druga ponoć niepotrzebna." },
  { key: "leftArm", name: "Lewa ręka", price: 6000, desc: "Nie potrzebujesz jej do ruletki." },
  { key: "rightArm", name: "Prawa ręka", price: 7000, desc: "Bez obu rąk nie zagrasz w karty!" },
  { key: "leftLeg", name: "Lewa noga", price: 8000, desc: "Będziesz kuśtykać." },
  { key: "rightLeg", name: "Prawa noga", price: 8500, desc: "Bez obu nóg dostajesz deskorolkę." },
  { key: "soul", name: "Dusza", price: 66600, desc: "Zenek ma na nią chrapkę." },
  { key: "dignity", name: "Godność", price: 1, desc: "Można sprzedawać wielokrotnie. Nikt nie zauważy." },
];

export const DRINKS = [
  { name: "Piwo „Mocny Bezdom”", price: 8, luck: 0.05, drunk: 0.25, desc: "+5% szczęścia, lekko kręci" },
  { name: "Wódka „Zenkówka”", price: 25, luck: 0.12, drunk: 0.6, desc: "+12% szczęścia, kręci mocno" },
  { name: "Szampan dla VIPów", price: 400, luck: 0.2, drunk: 0.3, desc: "+20% szczęścia, prestiż +2" },
  { name: "Tajemniczy płyn spod baru", price: 1, luck: 0.5, drunk: 1.5, desc: "+50% szczęścia?? Nie pytaj." },
];

export const LOANS = [
  { amount: 500, interest: 0.5 },
  { amount: 3000, interest: 0.6 },
  { amount: 20000, interest: 0.75 },
  { amount: 150000, interest: 1.0 },
];

export const NAME_SUGGESTIONS = ["Zbyszek", "Grażyna", "Mirek", "Halina", "Janusz", "Bożena", "Rysiek", "Jadzia", "Seba", "Karyna"];

export const fmt = (n: number) =>
  (n < 0 ? "-" : "") + Math.abs(Math.round(n)).toLocaleString("pl-PL") + " zł";
