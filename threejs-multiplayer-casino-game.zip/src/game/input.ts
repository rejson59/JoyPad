import { useEffect, useRef } from "react";
import { KEYMAPS, type PlayerId } from "./data";

export type Action = "up" | "down" | "left" | "right" | "action" | "cancel";

const held = new Set<string>();
type Listener = (pid: PlayerId, action: Action, e: KeyboardEvent) => void;
const listeners = new Set<Listener>();
let inited = false;

const codeToAction = new Map<string, { pid: PlayerId; action: Action }>();
(Object.keys(KEYMAPS) as unknown as PlayerId[]).forEach((k) => {
  const pid = Number(k) as PlayerId;
  const m = KEYMAPS[pid];
  (["up", "down", "left", "right", "action", "cancel"] as Action[]).forEach((a) => {
    codeToAction.set(m[a], { pid, action: a });
  });
});

export function initInput() {
  if (inited || typeof window === "undefined") return;
  inited = true;
  window.addEventListener("keydown", (e) => {
    if (e.target && (e.target as HTMLElement).tagName === "INPUT") return;
    const mapped = codeToAction.get(e.code);
    if (mapped || e.code.startsWith("Arrow") || e.code === "Space") e.preventDefault();
    if (held.has(e.code)) return; // ignore repeat
    held.add(e.code);
    if (mapped) listeners.forEach((l) => l(mapped.pid, mapped.action, e));
  });
  window.addEventListener("keyup", (e) => {
    held.delete(e.code);
  });
  window.addEventListener("blur", () => held.clear());
}

export function isHeld(code: string) {
  return held.has(code);
}

export function getAxis(pid: PlayerId): { x: number; z: number } {
  const m = KEYMAPS[pid];
  let x = 0,
    z = 0;
  if (held.has(m.left)) x -= 1;
  if (held.has(m.right)) x += 1;
  if (held.has(m.up)) z -= 1;
  if (held.has(m.down)) z += 1;
  return { x, z };
}

export function onPress(l: Listener) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

/** Subscribe to this player's discrete key presses. */
export function useInput(pid: PlayerId | null, handler: (action: Action) => void, enabled = true) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (pid === null || !enabled) return;
    return onPress((p, a) => {
      if (p === pid) ref.current(a);
    });
  }, [pid, enabled]);
}

/** Subscribe to any player's presses. */
export function useAnyInput(handler: (pid: PlayerId, action: Action) => void, enabled = true) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!enabled) return;
    return onPress((p, a) => ref.current(p, a));
  }, [enabled]);
}
