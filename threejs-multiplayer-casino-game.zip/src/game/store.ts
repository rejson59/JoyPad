import { create } from "zustand";
import {
  BODY_PARTS,
  CASINOS,
  DAY_LENGTH,
  DRINKS,
  LOANS,
  OUTFITS,
  SHOP_GLASSES,
  SHOP_HATS,
  type Avatar,
  type Limbs,
  type PlayerId,
  fmt,
  NAME_SUGGESTIONS,
} from "./data";
import { sfx, startMusic } from "./audio";

export interface Player {
  id: PlayerId;
  joined: boolean;
  name: string;
  avatar: Avatar;
  limbs: Limbs;
  drunk: number;
  luck: number;
  luckTimer: number;
  shoeless: boolean;
  activity: string | null;
  stats: { won: number; lost: number; biggestWin: number; spins: number };
  kickTo: [number, number] | null;
  kickSeq: number;
}

export interface Toast {
  id: number;
  text: string;
  kind: "info" | "good" | "bad" | "epic";
  pid?: PlayerId;
}

export type Screen = "menu" | "lobby" | "game" | "summary" | "gameover" | "victory";

export interface DayResult {
  success: boolean;
  earned: number;
  wallet: number;
  target: number;
  penalty: string | null;
  events: string[];
  mvp: PlayerId | null;
  loser: PlayerId | null;
}

interface GameState {
  screen: Screen;
  players: Player[];
  wallet: number;
  debt: number;
  day: number;
  tier: number;
  timeLeft: number;
  prestige: number;
  jackpotTimer: number;
  toasts: Toast[];
  dayStart: number;
  dayEvents: string[];
  eventTimer: number;
  lastResult: DayResult | null;
  gameOverReason: string;
  totalEarned: number;
  endless: boolean;
  paused: boolean;

  // actions
  setScreen: (s: Screen) => void;
  join: (pid: PlayerId) => void;
  leave: (pid: PlayerId) => void;
  setName: (pid: PlayerId, name: string) => void;
  setAvatar: (pid: PlayerId, patch: Partial<Avatar>) => void;
  startGame: () => void;
  tick: (dt: number) => void;
  changeMoney: (amount: number, pid?: PlayerId, reason?: string, silent?: boolean) => void;
  canAfford: (amount: number) => boolean;
  winMult: (pid: PlayerId) => number;
  setActivity: (pid: PlayerId, station: string | null) => void;
  toast: (text: string, kind?: Toast["kind"], pid?: PlayerId) => void;
  sellPart: (pid: PlayerId, key: keyof Limbs) => boolean;
  buyOutfit: (pid: PlayerId, idx: number) => boolean;
  buyHat: (pid: PlayerId, idx: number) => boolean;
  buyGlasses: (pid: PlayerId, idx: number) => boolean;
  buyChain: (pid: PlayerId) => boolean;
  buyProsthetic: (pid: PlayerId, key: keyof Limbs) => boolean;
  drink: (pid: PlayerId, idx: number) => boolean;
  takeLoan: (idx: number) => void;
  repayLoan: (amount: number) => void;
  endDay: () => void;
  nextDay: () => void;
  randomEvent: () => void;
  consumeKick: (pid: PlayerId) => void;
  restart: () => void;
}

let toastId = 0;

const defaultLimbs = (): Limbs => ({
  leftArm: true,
  rightArm: true,
  leftLeg: true,
  rightLeg: true,
  kidney: true,
  soul: true,
  teeth: 3,
  dignity: 100,
});

const mkPlayer = (id: PlayerId): Player => ({
  id,
  joined: false,
  name: NAME_SUGGESTIONS[(id * 3 + Math.floor(Math.random() * 3)) % NAME_SUGGESTIONS.length],
  avatar: {
    skin: id % 6,
    hair: (id + 1) % 6,
    hairColor: id % 8,
    outfit: 0,
    hat: id === 0 ? 2 : 0,
    glasses: 0,
    beard: id % 4,
    chain: false,
  },
  limbs: defaultLimbs(),
  drunk: 0,
  luck: 0,
  luckTimer: 0,
  shoeless: false,
  activity: null,
  stats: { won: 0, lost: 0, biggestWin: 0, spins: 0 },
  kickTo: null,
  kickSeq: 0,
});

const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

export const useGame = create<GameState>((set, get) => ({
  screen: "menu",
  players: [mkPlayer(0), mkPlayer(1), mkPlayer(2), mkPlayer(3)],
  wallet: 120,
  debt: 0,
  day: 1,
  tier: 0,
  timeLeft: DAY_LENGTH,
  prestige: 0,
  jackpotTimer: 0,
  toasts: [],
  dayStart: 120,
  dayEvents: [],
  eventTimer: 35,
  lastResult: null,
  gameOverReason: "",
  totalEarned: 0,
  endless: false,
  paused: false,

  setScreen: (s) => set({ screen: s }),

  join: (pid) =>
    set((s) => ({
      players: s.players.map((p) => (p.id === pid ? { ...p, joined: true } : p)),
    })),
  leave: (pid) =>
    set((s) => ({
      players: s.players.map((p) => (p.id === pid ? { ...p, joined: false } : p)),
    })),
  setName: (pid, name) =>
    set((s) => ({ players: s.players.map((p) => (p.id === pid ? { ...p, name } : p)) })),
  setAvatar: (pid, patch) =>
    set((s) => ({
      players: s.players.map((p) => (p.id === pid ? { ...p, avatar: { ...p.avatar, ...patch } } : p)),
    })),

  startGame: () => {
    startMusic(0);
    set({
      screen: "game",
      wallet: 120,
      dayStart: 120,
      debt: 0,
      day: 1,
      tier: 0,
      timeLeft: DAY_LENGTH,
      prestige: 0,
      toasts: [],
      dayEvents: [],
      eventTimer: 30,
      totalEarned: 0,
      endless: false,
    });
    setTimeout(() => get().toast("Znaleźliście 120 zł w starej skarpecie. Czas zostać milionerami!", "epic"), 800);
    setTimeout(() => get().toast(`Cel dnia: ${fmt(CASINOS[0].target)} przed północą!`, "info"), 3000);
  },

  tick: (dt) => {
    const s = get();
    if (s.screen !== "game" || s.paused) return;
    const timeLeft = s.timeLeft - dt;
    const players = s.players.map((p) => {
      if (!p.joined) return p;
      const np = { ...p };
      if (np.drunk > 0) np.drunk = Math.max(0, np.drunk - dt * 0.03);
      if (np.luckTimer > 0) {
        np.luckTimer -= dt;
        if (np.luckTimer <= 0) {
          np.luck = 0;
          np.luckTimer = 0;
        }
      }
      return np;
    });
    let eventTimer = s.eventTimer - dt;
    let jackpotTimer = Math.max(0, s.jackpotTimer - dt);
    set({ timeLeft, players, jackpotTimer });
    if (eventTimer <= 0) {
      eventTimer = 28 + Math.random() * 25;
      get().randomEvent();
    }
    set({ eventTimer });
    if (timeLeft <= 0) get().endDay();
  },

  canAfford: (amount) => get().wallet >= amount,

  winMult: (pid) => {
    const s = get();
    const p = s.players[pid];
    return 1 + s.prestige * 0.01 + (p?.luck ?? 0) + (s.jackpotTimer > 0 ? 1 : 0);
  },

  changeMoney: (amount, pid, reason, silent) => {
    const s = get();
    const wallet = Math.max(0, s.wallet + amount);
    const players = s.players.map((p) => {
      if (pid === undefined || p.id !== pid) return p;
      const st = { ...p.stats };
      if (amount > 0) {
        st.won += amount;
        st.biggestWin = Math.max(st.biggestWin, amount);
      } else st.lost += -amount;
      return { ...p, stats: st };
    });
    set({ wallet, players, totalEarned: s.totalEarned + Math.max(0, amount) });
    if (!silent && reason) get().toast(reason, amount >= 0 ? "good" : "bad", pid);
  },

  setActivity: (pid, station) =>
    set((s) => ({
      players: s.players.map((p) => (p.id === pid ? { ...p, activity: station } : p)),
    })),

  toast: (text, kind = "info", pid) => {
    const id = ++toastId;
    set((s) => ({
      toasts: [...s.toasts.slice(-5), { id, text, kind, pid }],
      dayEvents: kind === "info" || kind === "epic" ? [...s.dayEvents.slice(-20), text] : s.dayEvents,
    }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), 6000);
  },

  sellPart: (pid, key) => {
    const s = get();
    const p = s.players[pid];
    const part = BODY_PARTS.find((b) => b.key === key)!;
    const limbs = { ...p.limbs };
    if (key === "teeth") {
      if (limbs.teeth <= 0) return false;
      limbs.teeth--;
    } else if (key === "dignity") {
      limbs.dignity = Math.max(0, limbs.dignity - 1);
    } else {
      if (!limbs[key]) return false;
      (limbs as any)[key] = false;
    }
    sfx.saw();
    const funny: Record<string, string> = {
      teeth: `${p.name} sprzedał złoty ząb. Uśmiech jest teraz bardziej… przewiewny.`,
      kidney: `${p.name} sprzedał nerkę w lombardzie. Lekarz miał fartuch z Biedronki.`,
      leftArm: `${p.name} sprzedał lewą rękę. Oklaski będą teraz trudniejsze.`,
      rightArm: `${p.name} sprzedał prawą rękę. Podpisy stały się bardziej abstrakcyjne.`,
      leftLeg: `${p.name} sprzedał lewą nogę. Teraz chodzi w kółko.`,
      rightLeg: `${p.name} sprzedał prawą nogę. Przynajmniej buty są tańsze.`,
      soul: `${p.name} sprzedał DUSZĘ. Zenek wsadził ją do słoika po ogórkach.`,
      dignity: `${p.name} sprzedał godność za 1 zł. Nikt nie zauważył różnicy.`,
    };
    set({ players: s.players.map((pl) => (pl.id === pid ? { ...pl, limbs } : pl)) });
    get().changeMoney(part.price, pid, undefined, true);
    get().toast(funny[key], key === "dignity" ? "info" : "epic", pid);
    return true;
  },

  buyProsthetic: (pid, key) => {
    const s = get();
    const part = BODY_PARTS.find((b) => b.key === key)!;
    const price = Math.round(part.price * 1.6);
    if (s.wallet < price) return false;
    const p = s.players[pid];
    const limbs = { ...p.limbs };
    if (key === "teeth") limbs.teeth++;
    else (limbs as any)[key] = true;
    set({ players: s.players.map((pl) => (pl.id === pid ? { ...pl, limbs } : pl)) });
    get().changeMoney(-price, pid, `${p.name} odkupił: ${part.name} (używany, z gwarancją 2 dni)`);
    sfx.register();
    return true;
  },

  buyOutfit: (pid, idx) => {
    const s = get();
    const o = OUTFITS[idx];
    if (s.wallet < o.price) return false;
    get().changeMoney(-o.price, pid, undefined, true);
    const p = s.players[pid];
    set({
      prestige: s.prestige + o.prestige,
      players: get().players.map((pl) => (pl.id === pid ? { ...pl, avatar: { ...pl.avatar, outfit: idx } } : pl)),
    });
    get().toast(`${p.name} kupił: ${o.name}! Prestiż ekipy +${o.prestige}`, "good", pid);
    sfx.register();
    return true;
  },
  buyHat: (pid, idx) => {
    const s = get();
    const h = SHOP_HATS.find((x) => x.idx === idx)!;
    if (s.wallet < h.price) return false;
    get().changeMoney(-h.price, pid, undefined, true);
    set({
      prestige: s.prestige + h.prestige,
      players: get().players.map((pl) => (pl.id === pid ? { ...pl, avatar: { ...pl.avatar, hat: idx } } : pl)),
    });
    get().toast(`${s.players[pid].name} nosi teraz: ${h.name}. Prestiż +${h.prestige}`, "good", pid);
    sfx.register();
    return true;
  },
  buyGlasses: (pid, idx) => {
    const s = get();
    const g = SHOP_GLASSES.find((x) => x.idx === idx)!;
    if (s.wallet < g.price) return false;
    get().changeMoney(-g.price, pid, undefined, true);
    set({
      prestige: s.prestige + g.prestige,
      players: get().players.map((pl) => (pl.id === pid ? { ...pl, avatar: { ...pl.avatar, glasses: idx } } : pl)),
    });
    get().toast(`${s.players[pid].name} założył: ${g.name}. Prestiż +${g.prestige}`, "good", pid);
    sfx.register();
    return true;
  },
  buyChain: (pid) => {
    const s = get();
    if (s.wallet < 5000 || s.players[pid].avatar.chain) return false;
    get().changeMoney(-5000, pid, undefined, true);
    set({
      prestige: s.prestige + 5,
      players: get().players.map((pl) => (pl.id === pid ? { ...pl, avatar: { ...pl.avatar, chain: true } } : pl)),
    });
    get().toast(`${s.players[pid].name} ma złoty łańcuch. Bling bling! Prestiż +5`, "good", pid);
    sfx.register();
    return true;
  },

  drink: (pid, idx) => {
    const s = get();
    const d = DRINKS[idx];
    if (s.wallet < d.price) return false;
    get().changeMoney(-d.price, pid, undefined, true);
    const p = s.players[pid];
    set({
      prestige: s.prestige + (idx === 2 ? 2 : 0),
      players: get().players.map((pl) =>
        pl.id === pid
          ? { ...pl, luck: Math.min(0.6, pl.luck + d.luck), luckTimer: 75, drunk: Math.min(3, pl.drunk + d.drunk) }
          : pl
      ),
    });
    sfx.drink();
    const lines = [
      `${p.name} pije ${d.name}. Świat robi się przyjemniejszy.`,
      `${p.name} wychylił ${d.name} jednym haustem. Grażyna bije brawo.`,
      `${p.name}: „Jeszcze jedno i idę na ruletkę!”`,
    ];
    get().toast(idx === 3 ? `${p.name} wypił tajemniczy płyn. Widzi teraz kolory, których nie ma.` : pick(lines), "info", pid);
    return true;
  },

  takeLoan: (idx) => {
    const l = LOANS[idx];
    const s = get();
    const total = Math.round(l.amount * (1 + l.interest));
    set({ debt: s.debt + total });
    get().changeMoney(l.amount, undefined, undefined, true);
    sfx.register();
    get().toast(
      `Zenek pożyczył ${fmt(l.amount)}. Oddajecie ${fmt(total)} do północy… albo coś wam urwie.`,
      "bad"
    );
  },
  repayLoan: (amount) => {
    const s = get();
    const pay = Math.min(amount, s.wallet, s.debt);
    if (pay <= 0) return;
    set({ debt: s.debt - pay });
    get().changeMoney(-pay, undefined, undefined, true);
    sfx.coins();
    get().toast(`Spłaciliście Zenkowi ${fmt(pay)}. ${s.debt - pay <= 0 ? "Zenek uśmiecha się złotym zębem." : "Zenek kiwa głową."}`, "good");
  },

  randomEvent: () => {
    const s = get();
    const joined = s.players.filter((p) => p.joined);
    if (!joined.length) return;
    const p = pick(joined);
    const w = s.wallet;
    const events: { w: number; run: () => void }[] = [
      {
        w: 3,
        run: () => {
          const amt = Math.round(Math.max(50, w * 0.08));
          get().changeMoney(amt, undefined, undefined, true);
          get().toast(`💸 Pijany milioner rzuca banknotami! Ekipa łapie ${fmt(amt)}.`, "epic");
          sfx.coins();
        },
      },
      {
        w: p.avatar.outfit === 0 ? 3 : 0.5,
        run: () => {
          const amt = Math.round(Math.max(20, w * 0.05));
          get().changeMoney(-amt, p.id, undefined, true);
          get().toast(`👮 Ochrona: „${p.name} wygląda zbyt bezdomnie”. Mandat ${fmt(amt)}.`, "bad", p.id);
          sfx.alarm();
        },
      },
      {
        w: 3,
        run: () => {
          const amt = Math.round(Math.max(30, w * 0.04));
          get().changeMoney(amt, p.id, undefined, true);
          get().toast(`🪙 ${p.name} znalazł żeton pod automatem! +${fmt(amt)}`, "good", p.id);
          sfx.coin();
        },
      },
      {
        w: 2,
        run: () => {
          const amt = Math.round(w * 0.06);
          get().changeMoney(-amt, p.id, undefined, true);
          get().toast(`🐀 Szczur ukradł ${p.name} ${fmt(amt)} i uciekł do wentylacji.`, "bad", p.id);
        },
      },
      {
        w: 2,
        run: () => {
          set({ jackpotTimer: 30 });
          get().toast(`🔥 GODZINA SZCZĘŚCIA! Wszystkie wygrane ×2 przez 30 sekund!`, "epic");
          sfx.fanfare();
        },
      },
      {
        w: 2,
        run: () => {
          set({
            players: get().players.map((pl) =>
              pl.joined ? { ...pl, luck: Math.min(0.6, pl.luck + 0.1), luckTimer: 60, drunk: Math.min(3, pl.drunk + 0.4) } : pl
            ),
          });
          get().toast(`🍸 Grażyna stawia kolejkę na koszt firmy! Wszyscy +10% szczęścia (i lekko kręci).`, "epic");
          sfx.drink();
        },
      },
      {
        w: w > 5000 ? 2 : 0,
        run: () => {
          const amt = Math.round(w * 0.1);
          get().changeMoney(-amt, undefined, undefined, true);
          get().toast(`🧾 Kontrola skarbowa! Urząd zabiera 10% (${fmt(amt)}). „Na drogi” – mówią.`, "bad");
          sfx.alarm();
        },
      },
      {
        w: s.prestige >= 10 ? 3 : 0,
        run: () => {
          const amt = Math.round(Math.max(200, w * 0.1));
          get().changeMoney(amt, p.id, undefined, true);
          get().toast(`📸 Ktoś wziął ${p.name} za celebrytę! Fani rzucają pieniędzmi: +${fmt(amt)}`, "epic", p.id);
          sfx.coins();
        },
      },
      {
        w: 2,
        run: () => {
          const amt = Math.round(Math.max(40, w * 0.05));
          get().changeMoney(amt, undefined, undefined, true);
          get().toast(`⚙️ Awaria automatu! Wypluł ${fmt(amt)} na podłogę. Nikt nie widział. Prawie.`, "good");
          sfx.coins();
        },
      },
      {
        w: s.debt > 0 ? 3 : 0,
        run: () => {
          const add = Math.round(s.debt * 0.1);
          set({ debt: s.debt + add });
          get().toast(`😈 Zenek przypomina o długu i „z sympatii” dolicza ${fmt(add)}.`, "bad");
        },
      },
      {
        w: p.shoeless ? 0 : 1.5,
        run: () => {
          set({ players: get().players.map((pl) => (pl.id === p.id ? { ...pl, shoeless: true } : pl)) });
          get().toast(`👟 Ktoś ukradł ${p.name} buta. Porusza się wolniej do końca dnia.`, "bad", p.id);
        },
      },
      {
        w: 1.5,
        run: () => get().toast(`🕊️ Gołąb wleciał do kasyna. Wszyscy przez chwilę gapią się na gołębia.`, "info"),
      },
      {
        w: 2,
        run: () => {
          const amt = 150 + Math.round(w * 0.03);
          get().changeMoney(amt, p.id, undefined, true);
          get().toast(`🏆 ${p.name} wygrał konkurs na najintensywniejszy zapach w kasynie! +${fmt(amt)}`, "good", p.id);
          sfx.coin();
        },
      },
      {
        w: 1.5,
        run: () => {
          set({
            players: get().players.map((pl) =>
              pl.id === p.id ? { ...pl, kickTo: [0, 12], kickSeq: pl.kickSeq + 1, activity: null } : pl
            ),
          });
          get().toast(`🚪 Bramkarz wyrzucił ${p.name} za drzwi „dla zasady”. Wraca od wejścia.`, "bad", p.id);
          sfx.alarm();
        },
      },
      {
        w: 1,
        run: () => {
          const amt = Math.round(Math.max(100, w * 0.15));
          get().changeMoney(amt, undefined, undefined, true);
          get().toast(`👵 Babcia Jadzia pomyliła was z wnukami i dała ${fmt(amt)} „na cukierki”.`, "epic");
          sfx.coins();
        },
      },
    ];
    const total = events.reduce((a, e) => a + e.w, 0);
    let r = Math.random() * total;
    for (const e of events) {
      r -= e.w;
      if (r <= 0) {
        e.run();
        break;
      }
    }
  },

  consumeKick: (pid) =>
    set((s) => ({ players: s.players.map((p) => (p.id === pid ? { ...p, kickTo: null } : p)) })),

  endDay: () => {
    const s = get();
    const casino = CASINOS[s.tier];
    const target = s.endless ? casino.target * Math.pow(2, s.day - 5) : casino.target;
    const events: string[] = [];
    let wallet = s.wallet;
    let debt = s.debt;
    let players = s.players.map((p) => ({ ...p, activity: null, shoeless: false, drunk: 0, luck: 0, luckTimer: 0 }));

    // Debt enforcement
    if (debt > 0) {
      const pay = Math.min(wallet, debt);
      wallet -= pay;
      debt -= pay;
      if (pay > 0) events.push(`Zenek ściągnął ${fmt(pay)} długu z portfela.`);
      let guard = 0;
      while (debt > 0 && guard++ < 40) {
        const joined = players.filter((p) => p.joined);
        const candidates: { pid: PlayerId; key: keyof Limbs; price: number; name: string }[] = [];
        for (const p of joined) {
          for (const b of BODY_PARTS) {
            if (b.key === "dignity") continue;
            if (b.key === "teeth" ? p.limbs.teeth > 0 : p.limbs[b.key]) candidates.push({ pid: p.id, key: b.key, price: b.price, name: b.name });
          }
        }
        if (!candidates.length) {
          set({
            screen: "gameover",
            gameOverReason:
              "Zenek nie miał już czego zabrać. Ekipa została wywieziona do pracy na budowie w Norwegii. Podobno płacą nieźle.",
          });
          sfx.sad();
          return;
        }
        const c = pick(candidates);
        players = players.map((p) => {
          if (p.id !== c.pid) return p;
          const limbs = { ...p.limbs };
          if (c.key === "teeth") limbs.teeth--;
          else (limbs as any)[c.key] = false;
          return { ...p, limbs };
        });
        debt -= c.price;
        events.push(`😈 Zenek zabrał ${players[c.pid].name}: ${c.name} (wycenione na ${fmt(c.price)}).`);
      }
      debt = Math.max(0, debt);
    }

    const success = wallet >= target;
    let penalty: string | null = null;
    if (!success) {
      const joined = players.filter((p) => p.joined);
      const p = pick(joined);
      const r = Math.random();
      if (r < 0.3) {
        const loss = Math.round(wallet * 0.15);
        wallet -= loss;
        penalty = `Spaliście na ławce w parku. Szczury zjadły ${fmt(loss)}.`;
      } else if (r < 0.55) {
        const loss = Math.round(wallet * 0.25);
        wallet -= loss;
        penalty = `Ochroniarz „skonfiskował” ${fmt(loss)} żetonów przy wyjściu. Na pewno je odda.`;
      } else if (r < 0.8 && p.avatar.outfit > 0) {
        players = players.map((pl) => (pl.id === p.id ? { ...pl, avatar: { ...pl.avatar, outfit: 0 } } : pl));
        penalty = `${p.name} przegrał swoje ubranie w grę w kapsle z dzieciakami. Z powrotem w łachmanach.`;
      } else {
        players = players.map((pl) => (pl.id === p.id ? { ...pl, limbs: { ...pl.limbs, teeth: Math.max(0, pl.limbs.teeth - 1) } } : pl));
        penalty = `${p.name} w nocy zgubił złoty ząb. Nikt nie wie jak. Nikt nie pyta.`;
      }
    }

    const joined = players.filter((p) => p.joined);
    const byNet = [...joined].sort((a, b) => b.stats.won - b.stats.lost - (a.stats.won - a.stats.lost));
    const result: DayResult = {
      success,
      earned: wallet - s.dayStart,
      wallet,
      target,
      penalty,
      events,
      mvp: byNet[0]?.id ?? null,
      loser: byNet.length > 1 ? byNet[byNet.length - 1].id : null,
    };
    set({ wallet, debt, players, lastResult: result, screen: "summary" });
    if (success) sfx.fanfare();
    else sfx.sad();
  },

  nextDay: () => {
    const s = get();
    const res = s.lastResult!;
    let tier = s.tier;
    let endless = s.endless;
    if (res.success && tier < CASINOS.length - 1) tier++;
    else if (res.success && tier === CASINOS.length - 1) endless = true;
    const day = s.day + 1;
    if (s.tier === CASINOS.length - 1 && res.success && !s.endless) {
      set({ screen: "victory", endless: true, day, tier });
      return;
    }
    startMusic(tier);
    set({
      screen: "game",
      tier,
      day,
      endless,
      timeLeft: DAY_LENGTH,
      dayStart: s.wallet,
      dayEvents: [],
      eventTimer: 25,
      jackpotTimer: 0,
      toasts: [],
      players: s.players.map((p) => ({ ...p, stats: { won: 0, lost: 0, biggestWin: 0, spins: 0 } })),
    });
    const c = CASINOS[tier];
    setTimeout(() => get().toast(`Dzień ${day}: ${c.name}. ${c.subtitle}`, "epic"), 600);
    setTimeout(
      () =>
        get().toast(
          `Cel: ${fmt(endless ? c.target * Math.pow(2, day - 5) : c.target)} przed północą!`,
          "info"
        ),
      3000
    );
  },

  restart: () =>
    set({
      screen: "lobby",
      players: get().players.map((p) => ({ ...mkPlayer(p.id), joined: p.joined, name: p.name, avatar: { ...p.avatar, outfit: 0, chain: false } })),
      wallet: 120,
      debt: 0,
      day: 1,
      tier: 0,
      prestige: 0,
      lastResult: null,
      endless: false,
    }),
}));

export const canUseHands = (p: Player) => p.limbs.leftArm || p.limbs.rightArm;
export const moveSpeed = (p: Player) => {
  let s = 1;
  if (!p.limbs.leftLeg && !p.limbs.rightLeg) s = 0.55; // skateboard!
  else if (!p.limbs.leftLeg || !p.limbs.rightLeg) s = 0.65;
  if (p.shoeless) s *= 0.8;
  if (!p.limbs.kidney) s *= 0.92;
  return s;
};
