import * as THREE from "three";

const cache = new Map<string, THREE.Texture>();

function canvasTex(key: string, w: number, h: number, draw: (ctx: CanvasRenderingContext2D) => void) {
  if (cache.has(key)) return cache.get(key)!;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  draw(ctx);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  cache.set(key, t);
  return t;
}

export function textTexture(text: string, opts: { color?: string; bg?: string; font?: string; w?: number; h?: number; glow?: string } = {}) {
  const { color = "#ffd84d", bg = "rgba(0,0,0,0)", font = "bold 90px Georgia, serif", w = 1024, h = 256, glow } = opts;
  return canvasTex(`txt:${text}:${color}:${bg}:${font}:${glow}`, w, h, (ctx) => {
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);
    ctx.font = font;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    if (glow) {
      ctx.shadowColor = glow;
      ctx.shadowBlur = 40;
    }
    ctx.fillStyle = color;
    ctx.fillText(text, w / 2, h / 2);
    ctx.fillText(text, w / 2, h / 2);
  });
}

export function feltTexture(color = "#0d5c2e", text = "BLACKJACK PAYS 3 TO 2") {
  return canvasTex(`felt:${color}:${text}`, 1024, 1024, (ctx) => {
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, 1024, 1024);
    // fabric noise
    for (let i = 0; i < 40000; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
      ctx.fillRect(Math.random() * 1024, Math.random() * 1024, 2, 2);
    }
    ctx.strokeStyle = "rgba(255,220,120,0.8)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(512, 900, 420, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(512, 900, 300, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();
    ctx.fillStyle = "rgba(255,230,150,0.9)";
    ctx.font = "bold 44px Georgia";
    ctx.textAlign = "center";
    ctx.fillText(text, 512, 560);
    ctx.font = "28px Georgia";
    ctx.fillText("Dealer must stand on 17", 512, 610);
    for (let i = 0; i < 5; i++) {
      const a = Math.PI * 1.25 + i * Math.PI * 0.125;
      const x = 512 + Math.cos(a) * 360,
        y = 900 + Math.sin(a) * 360;
      ctx.beginPath();
      ctx.arc(x, y, 40, 0, Math.PI * 2);
      ctx.stroke();
    }
  });
}

export function rouletteLayoutTexture() {
  return canvasTex("roulette-layout", 1024, 512, (ctx) => {
    ctx.fillStyle = "#0b5a2c";
    ctx.fillRect(0, 0, 1024, 512);
    for (let i = 0; i < 20000; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
      ctx.fillRect(Math.random() * 1024, Math.random() * 512, 2, 2);
    }
    const reds = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
    const cw = 64,
      ch = 90;
    ctx.font = "bold 30px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (let n = 1; n <= 36; n++) {
      const col = Math.floor((n - 1) / 3),
        row = 2 - ((n - 1) % 3);
      const x = 140 + col * cw,
        y = 60 + row * ch;
      ctx.fillStyle = reds.has(n) ? "#c8202a" : "#111";
      ctx.fillRect(x + 3, y + 3, cw - 6, ch - 6);
      ctx.fillStyle = "#fff";
      ctx.fillText(String(n), x + cw / 2, y + ch / 2);
    }
    ctx.fillStyle = "#1a9b3a";
    ctx.fillRect(70, 63, 64, ch * 3 - 6);
    ctx.fillStyle = "#fff";
    ctx.fillText("0", 102, 195);
    ctx.strokeStyle = "#f5e6a8";
    ctx.lineWidth = 3;
    ctx.strokeRect(70, 60, 840, 270);
    ["1-18", "PARZ.", "◆", "◆", "NIEP.", "19-36"].forEach((t, i) => {
      ctx.fillStyle = i === 2 ? "#c8202a" : i === 3 ? "#111" : "#0b5a2c";
      ctx.fillRect(140 + i * 128, 340, 124, 70);
      ctx.strokeRect(140 + i * 128, 340, 124, 70);
      ctx.fillStyle = "#f5e6a8";
      ctx.fillText(t, 140 + i * 128 + 62, 375);
    });
  });
}

export function rouletteWheelTexture() {
  const order = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
  const reds = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
  return canvasTex("roulette-wheel", 1024, 1024, (ctx) => {
    const cx = 512,
      cy = 512;
    ctx.fillStyle = "#5a3a1a";
    ctx.beginPath();
    ctx.arc(cx, cy, 512, 0, Math.PI * 2);
    ctx.fill();
    const seg = (Math.PI * 2) / 37;
    order.forEach((n, i) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, 440, i * seg, (i + 1) * seg);
      ctx.closePath();
      ctx.fillStyle = n === 0 ? "#1a9b3a" : reds.has(n) ? "#c8202a" : "#141414";
      ctx.fill();
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(i * seg + seg / 2);
      ctx.fillStyle = "#fff";
      ctx.font = "bold 34px Arial";
      ctx.textAlign = "center";
      ctx.fillText(String(n), 400, 12);
      ctx.restore();
    });
    ctx.fillStyle = "#c9a227";
    ctx.beginPath();
    ctx.arc(cx, cy, 300, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#7a5a1a";
    ctx.beginPath();
    ctx.arc(cx, cy, 240, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#e8c860";
    for (let i = 0; i < 8; i++) {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate((i * Math.PI) / 4);
      ctx.fillRect(-14, -240, 28, 240);
      ctx.restore();
    }
    ctx.beginPath();
    ctx.arc(cx, cy, 60, 0, Math.PI * 2);
    ctx.fill();
  });
}

export function slotScreenTexture(seed: number) {
  const syms = ["🍒", "🍋", "🔔", "🧦", "💎", "7️⃣", "👑"];
  return canvasTex(`slot:${seed}`, 512, 512, (ctx) => {
    const g = ctx.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, "#15052a");
    g.addColorStop(1, "#2a0a3a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 512);
    ctx.fillStyle = "#fff8e0";
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(40 + i * 150, 120, 130, 260);
    }
    ctx.font = "100px serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = "#000";
      ctx.fillText(syms[(seed * 3 + i * 2) % syms.length], 105 + i * 150, 250);
    }
    ctx.fillStyle = "#ffd84d";
    ctx.font = "bold 46px Impact, Arial Black, sans-serif";
    ctx.shadowColor = "#ff2bd6";
    ctx.shadowBlur = 20;
    ctx.fillText(["SKARPETA", "WIŚNIOWY", "SIÓDEMKA", "DIAMENT"][seed % 4] + " JACKPOT", 256, 60);
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#ff5a5a";
    ctx.font = "bold 36px Arial";
    ctx.fillText("GRAJ • WYGRYWAJ • POWTARZAJ", 256, 440);
  });
}

export function wheelTexture() {
  const segs = ["×0", "×2", "BUT", "×3", "DRINK", "×0.5", "×5", "ZŁODZIEJ", "×10", "WYRZUT", "×1", "JACKPOT"];
  const cols = ["#333", "#2ecc71", "#8e5a2b", "#3498db", "#e67e22", "#7f8c8d", "#9b59b6", "#c0392b", "#f1c40f", "#1a1a1a", "#95a5a6", "#ffd700"];
  return canvasTex("wheel", 1024, 1024, (ctx) => {
    const cx = 512,
      cy = 512;
    const seg = (Math.PI * 2) / segs.length;
    segs.forEach((s, i) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, 500, i * seg, (i + 1) * seg);
      ctx.closePath();
      ctx.fillStyle = cols[i];
      ctx.fill();
      ctx.strokeStyle = "#f8e6a0";
      ctx.lineWidth = 6;
      ctx.stroke();
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(i * seg + seg / 2);
      ctx.fillStyle = "#fff";
      ctx.font = "bold 56px Impact, Arial Black";
      ctx.textAlign = "right";
      ctx.textBaseline = "middle";
      ctx.shadowColor = "#000";
      ctx.shadowBlur = 8;
      ctx.fillText(s, 470, 0);
      ctx.restore();
    });
    ctx.fillStyle = "#c9a227";
    ctx.beginPath();
    ctx.arc(cx, cy, 90, 0, Math.PI * 2);
    ctx.fill();
  });
}

export function ragsTexture(base: string) {
  return canvasTex(`rags:${base}`, 256, 256, (ctx) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 800; i++) {
      ctx.fillStyle = `rgba(0,0,0,${Math.random() * 0.25})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 3 + Math.random() * 6, 3 + Math.random() * 6);
    }
    const patches = ["#7a5a3a", "#3a4a6a", "#6a3a3a", "#4a5a3a"];
    for (let i = 0; i < 7; i++) {
      ctx.fillStyle = patches[i % patches.length];
      ctx.fillRect(Math.random() * 200, Math.random() * 200, 30 + Math.random() * 40, 30 + Math.random() * 40);
    }
  });
}

export function stripesTexture(base: string, stripe: string) {
  return canvasTex(`stripes:${base}:${stripe}`, 256, 256, (ctx) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = stripe;
    ctx.fillRect(40, 0, 18, 256);
    ctx.fillRect(70, 0, 18, 256);
  });
}

export function hawaiiTexture() {
  return canvasTex("hawaii", 256, 256, (ctx) => {
    ctx.fillStyle = "#ff6b3d";
    ctx.fillRect(0, 0, 256, 256);
    const cols = ["#ffe066", "#2ecc71", "#ff3b7a", "#3fb6ff"];
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = cols[i % 4];
      ctx.beginPath();
      ctx.arc(Math.random() * 256, Math.random() * 256, 8 + Math.random() * 14, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

export function suitTexture(base: string, gold = false) {
  return canvasTex(`suit:${base}:${gold}`, 256, 256, (ctx) => {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);
    // shirt + tie in front
    ctx.fillStyle = "#f5f5f5";
    ctx.beginPath();
    ctx.moveTo(100, 0);
    ctx.lineTo(156, 0);
    ctx.lineTo(128, 120);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = gold ? "#8b0000" : "#b8202a";
    ctx.fillRect(122, 10, 12, 100);
    if (gold) {
      for (let i = 0; i < 300; i++) {
        ctx.fillStyle = `rgba(255,255,200,${Math.random() * 0.5})`;
        ctx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
      }
    }
  });
}

export function posterTexture(i: number) {
  const titles = ["WIELKI JACKPOT", "NOC KRÓLÓW", "RULETKA ŻYCIA", "WYGRAJ ALBO ZGIŃ", "BEZDOMNI VIP"];
  const cols = ["#8a1030", "#1a2a6a", "#0b5e3a", "#5a1a6a", "#7a4a0a"];
  return canvasTex(`poster:${i}`, 512, 768, (ctx) => {
    const g = ctx.createLinearGradient(0, 0, 0, 768);
    g.addColorStop(0, cols[i % cols.length]);
    g.addColorStop(1, "#050505");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 768);
    ctx.strokeStyle = "#e8c860";
    ctx.lineWidth = 14;
    ctx.strokeRect(20, 20, 472, 728);
    ctx.fillStyle = "#ffd84d";
    ctx.font = "bold 64px Impact, Arial Black";
    ctx.textAlign = "center";
    ctx.shadowColor = "#000";
    ctx.shadowBlur = 20;
    const words = titles[i % titles.length].split(" ");
    words.forEach((w, k) => ctx.fillText(w, 256, 180 + k * 80));
    ctx.font = "140px serif";
    ctx.fillText(["🎰", "👑", "🎡", "💀", "🧦"][i % 5], 256, 540);
    ctx.font = "28px Georgia";
    ctx.fillStyle = "#fff";
    ctx.fillText("Codziennie od zmierzchu do świtu", 256, 680);
  });
}

export function emojiTexture(e: string, size = 128) {
  return canvasTex(`emoji:${e}`, size, size, (ctx) => {
    ctx.font = `${size * 0.8}px serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(e, size / 2, size / 2 + 4);
  });
}
