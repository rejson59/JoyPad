// Mutable per-frame world state (kept outside React for performance)
export interface Body {
  x: number;
  z: number;
  rot: number;
  moving: boolean;
  near: string | null;
}

export const bodies: Body[] = [
  { x: -2, z: 11, rot: Math.PI, moving: false, near: null },
  { x: 0, z: 11, rot: Math.PI, moving: false, near: null },
  { x: 2, z: 11, rot: Math.PI, moving: false, near: null },
  { x: 4, z: 11, rot: Math.PI, moving: false, near: null },
];

export function resetBodies() {
  bodies.forEach((b, i) => {
    b.x = -3 + i * 2;
    b.z = 11.5;
    b.rot = Math.PI;
    b.moving = false;
    b.near = null;
  });
}
