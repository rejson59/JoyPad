import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { HAIR_COLORS, OUTFITS, SKIN_COLORS, type Avatar as AvatarData, type Limbs } from "../game/data";
import { hawaiiTexture, ragsTexture, stripesTexture, suitTexture } from "../game/textures";

interface Props {
  avatar: AvatarData;
  limbs?: Limbs;
  walkRef?: React.MutableRefObject<{ moving: boolean; drunk: number }>;
  scale?: number;
  idleOffset?: number;
  outlineColor?: string;
}

const FULL: Limbs = { leftArm: true, rightArm: true, leftLeg: true, rightLeg: true, kidney: true, soul: true, teeth: 3, dignity: 100 };

export function outfitMaterial(outfit: number) {
  const o = OUTFITS[outfit] ?? OUTFITS[0];
  const mat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.8, metalness: 0 });
  if (outfit === 0) mat.map = ragsTexture(o.color);
  else if (outfit === 1) mat.map = stripesTexture(o.color, "#ffffff");
  else if (outfit === 2) mat.map = hawaiiTexture();
  else if (outfit === 5) {
    mat.map = suitTexture(o.color, true);
    mat.metalness = 0.7;
    mat.roughness = 0.3;
  } else mat.map = suitTexture(o.color);
  return mat;
}

export function Avatar({ avatar, limbs = FULL, walkRef, scale = 1, idleOffset = 0, outlineColor }: Props) {
  const group = useRef<THREE.Group>(null);
  const lArm = useRef<THREE.Group>(null);
  const rArm = useRef<THREE.Group>(null);
  const lLeg = useRef<THREE.Group>(null);
  const rLeg = useRef<THREE.Group>(null);
  const torso = useRef<THREE.Group>(null);
  const head = useRef<THREE.Group>(null);
  const t = useRef(Math.random() * 10 + idleOffset);

  const skin = SKIN_COLORS[avatar.skin] ?? SKIN_COLORS[0];
  const hairCol = HAIR_COLORS[avatar.hairColor] ?? HAIR_COLORS[0];
  const outfitMat = useMemo(() => outfitMaterial(avatar.outfit), [avatar.outfit]);
  const pantsColor = avatar.outfit === 0 ? "#3a3026" : avatar.outfit === 1 ? "#1d3fb8" : avatar.outfit === 2 ? "#e8d9b0" : avatar.outfit === 5 ? "#d4a017" : "#15151c";
  const skateboard = !limbs.leftLeg && !limbs.rightLeg;

  useFrame((_, dt) => {
    const moving = walkRef?.current.moving ?? false;
    const drunk = walkRef?.current.drunk ?? 0;
    t.current += dt * (moving ? 10 : 2);
    const s = Math.sin(t.current);
    const amp = moving ? 0.8 : 0.08;
    if (lArm.current) lArm.current.rotation.x = s * amp;
    if (rArm.current) rArm.current.rotation.x = -s * amp;
    if (lLeg.current) lLeg.current.rotation.x = -s * amp * 0.9;
    if (rLeg.current) rLeg.current.rotation.x = s * amp * 0.9;
    if (torso.current) {
      torso.current.position.y = (skateboard ? 0.35 : 0.95) + (moving ? Math.abs(Math.cos(t.current)) * 0.06 : Math.sin(t.current) * 0.01);
      torso.current.rotation.z = drunk > 0 ? Math.sin(t.current * 0.4) * 0.15 * Math.min(1, drunk) : 0;
    }
    if (head.current) {
      head.current.rotation.y = Math.sin(t.current * 0.25) * 0.25;
      head.current.rotation.z = drunk > 0 ? Math.cos(t.current * 0.3) * 0.2 * Math.min(1, drunk) : 0;
    }
    if (group.current && skateboard && moving) group.current.rotation.z = Math.sin(t.current * 0.5) * 0.05;
  });

  const hair = avatar.hair;
  const hat = avatar.hat;

  return (
    <group ref={group} scale={scale}>
      {/* Legs */}
      {!skateboard && (
        <>
          {limbs.leftLeg && (
            <group ref={lLeg} position={[-0.14, 0.62, 0]}>
              <mesh position={[0, -0.3, 0]} castShadow>
                <capsuleGeometry args={[0.1, 0.45, 4, 8]} />
                <meshStandardMaterial color={pantsColor} roughness={0.9} />
              </mesh>
              <mesh position={[0, -0.6, 0.06]} castShadow>
                <boxGeometry args={[0.18, 0.1, 0.32]} />
                <meshStandardMaterial color={avatar.outfit >= 3 ? "#111" : "#2a1a0a"} roughness={0.6} />
              </mesh>
            </group>
          )}
          {limbs.rightLeg && (
            <group ref={rLeg} position={[0.14, 0.62, 0]}>
              <mesh position={[0, -0.3, 0]} castShadow>
                <capsuleGeometry args={[0.1, 0.45, 4, 8]} />
                <meshStandardMaterial color={pantsColor} roughness={0.9} />
              </mesh>
              <mesh position={[0, -0.6, 0.06]} castShadow>
                <boxGeometry args={[0.18, 0.1, 0.32]} />
                <meshStandardMaterial color={avatar.outfit >= 3 ? "#111" : "#2a1a0a"} roughness={0.6} />
              </mesh>
            </group>
          )}
          {!limbs.leftLeg && (
            <mesh position={[-0.14, 0.5, 0]} castShadow>
              <cylinderGeometry args={[0.06, 0.04, 0.5, 8]} />
              <meshStandardMaterial color="#8a6a3a" roughness={1} />
            </mesh>
          )}
          {!limbs.rightLeg && (
            <mesh position={[0.14, 0.5, 0]} castShadow>
              <cylinderGeometry args={[0.06, 0.04, 0.5, 8]} />
              <meshStandardMaterial color="#8a6a3a" roughness={1} />
            </mesh>
          )}
        </>
      )}
      {skateboard && (
        <group position={[0, 0.08, 0]}>
          <mesh castShadow>
            <boxGeometry args={[0.5, 0.05, 0.9]} />
            <meshStandardMaterial color="#c0392b" roughness={0.5} />
          </mesh>
          {[-0.3, 0.3].map((z) =>
            [-0.2, 0.2].map((x) => (
              <mesh key={`${x}${z}`} position={[x, -0.05, z]} rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.06, 0.06, 0.05, 12]} />
                <meshStandardMaterial color="#eee" />
              </mesh>
            ))
          )}
          <mesh position={[0, 0.15, 0]} castShadow>
            <sphereGeometry args={[0.22, 12, 12]} />
            <meshStandardMaterial color={pantsColor} />
          </mesh>
        </group>
      )}

      {/* Torso */}
      <group ref={torso} position={[0, skateboard ? 0.35 : 0.95, 0]}>
        <mesh castShadow material={outfitMat}>
          <capsuleGeometry args={[0.26, 0.42, 6, 12]} />
        </mesh>
        {avatar.chain && (
          <mesh position={[0, 0.2, 0.2]} rotation={[Math.PI / 2.4, 0, 0]}>
            <torusGeometry args={[0.18, 0.025, 8, 24]} />
            <meshStandardMaterial color="#ffd700" metalness={1} roughness={0.2} />
          </mesh>
        )}
        {/* Arms */}
        {limbs.leftArm ? (
          <group ref={lArm} position={[-0.34, 0.25, 0]}>
            <mesh position={[0, -0.25, 0]} castShadow material={outfitMat}>
              <capsuleGeometry args={[0.08, 0.4, 4, 8]} />
            </mesh>
            <mesh position={[0, -0.52, 0]}>
              <sphereGeometry args={[0.09, 10, 10]} />
              <meshStandardMaterial color={skin} />
            </mesh>
          </group>
        ) : (
          <mesh position={[-0.34, 0.15, 0]} castShadow material={outfitMat}>
            <capsuleGeometry args={[0.08, 0.1, 4, 8]} />
          </mesh>
        )}
        {limbs.rightArm ? (
          <group ref={rArm} position={[0.34, 0.25, 0]}>
            <mesh position={[0, -0.25, 0]} castShadow material={outfitMat}>
              <capsuleGeometry args={[0.08, 0.4, 4, 8]} />
            </mesh>
            <mesh position={[0, -0.52, 0]}>
              <sphereGeometry args={[0.09, 10, 10]} />
              <meshStandardMaterial color={skin} />
            </mesh>
          </group>
        ) : (
          <mesh position={[0.34, 0.15, 0]} castShadow material={outfitMat}>
            <capsuleGeometry args={[0.08, 0.1, 4, 8]} />
          </mesh>
        )}

        {/* Head */}
        <group ref={head} position={[0, 0.62, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.24, 20, 20]} />
            <meshStandardMaterial color={skin} roughness={0.7} />
          </mesh>
          {/* eyes */}
          <mesh position={[-0.08, 0.04, 0.21]}>
            <sphereGeometry args={[0.035, 8, 8]} />
            <meshStandardMaterial color="#111" />
          </mesh>
          <mesh position={[0.08, 0.04, 0.21]}>
            <sphereGeometry args={[0.035, 8, 8]} />
            <meshStandardMaterial color="#111" />
          </mesh>
          {/* nose */}
          <mesh position={[0, -0.03, 0.24]}>
            <sphereGeometry args={[0.04, 8, 8]} />
            <meshStandardMaterial color={skin} />
          </mesh>
          {/* teeth / grin */}
          <mesh position={[0, -0.12, 0.2]}>
            <boxGeometry args={[0.12, 0.03, 0.02]} />
            <meshStandardMaterial color={limbs.teeth > 0 ? "#ffd700" : "#331111"} metalness={limbs.teeth > 0 ? 0.9 : 0} />
          </mesh>
          {/* beard */}
          {avatar.beard === 1 && (
            <mesh position={[0, -0.12, 0.12]}>
              <sphereGeometry args={[0.2, 12, 12, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2]} />
              <meshStandardMaterial color={hairCol} transparent opacity={0.55} roughness={1} />
            </mesh>
          )}
          {avatar.beard === 2 && (
            <mesh position={[0, -0.22, 0.1]}>
              <capsuleGeometry args={[0.14, 0.15, 4, 10]} />
              <meshStandardMaterial color={hairCol} roughness={1} />
            </mesh>
          )}
          {avatar.beard === 3 && (
            <mesh position={[0, -0.08, 0.23]} rotation={[0, 0, 0]}>
              <torusGeometry args={[0.09, 0.02, 6, 12, Math.PI]} />
              <meshStandardMaterial color={hairCol} roughness={1} />
            </mesh>
          )}
          {/* hair */}
          {hair === 1 && (
            <mesh position={[0, 0.08, -0.02]}>
              <sphereGeometry args={[0.245, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2.2]} />
              <meshStandardMaterial color={hairCol} roughness={1} />
            </mesh>
          )}
          {hair === 2 && (
            <mesh position={[0, 0.3, 0]}>
              <boxGeometry args={[0.06, 0.25, 0.4]} />
              <meshStandardMaterial color={hairCol} roughness={1} />
            </mesh>
          )}
          {hair === 3 && (
            <>
              <mesh position={[0, 0.08, -0.02]}>
                <sphereGeometry args={[0.25, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2.1]} />
                <meshStandardMaterial color={hairCol} roughness={1} />
              </mesh>
              <mesh position={[0, -0.15, -0.14]}>
                <cylinderGeometry args={[0.2, 0.22, 0.45, 12]} />
                <meshStandardMaterial color={hairCol} roughness={1} />
              </mesh>
            </>
          )}
          {hair === 4 && (
            <mesh position={[0, 0.12, 0]}>
              <sphereGeometry args={[0.34, 16, 16]} />
              <meshStandardMaterial color={hairCol} roughness={1} />
            </mesh>
          )}
          {hair === 5 && (
            <>
              <mesh position={[0, 0.08, -0.02]}>
                <sphereGeometry args={[0.245, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2.2]} />
                <meshStandardMaterial color={hairCol} roughness={1} />
              </mesh>
              <mesh position={[0, 0.3, -0.08]}>
                <sphereGeometry args={[0.11, 10, 10]} />
                <meshStandardMaterial color={hairCol} roughness={1} />
              </mesh>
            </>
          )}
          {/* glasses */}
          {avatar.glasses === 1 && (
            <group position={[0, 0.04, 0.22]}>
              <mesh position={[-0.08, 0, 0]}>
                <torusGeometry args={[0.055, 0.01, 6, 16]} />
                <meshStandardMaterial color="#222" />
              </mesh>
              <mesh position={[0.08, 0, 0]}>
                <torusGeometry args={[0.055, 0.01, 6, 16]} />
                <meshStandardMaterial color="#222" />
              </mesh>
            </group>
          )}
          {avatar.glasses === 2 && (
            <mesh position={[0, 0.04, 0.22]}>
              <boxGeometry args={[0.3, 0.09, 0.03]} />
              <meshStandardMaterial color="#111" metalness={0.6} roughness={0.2} />
            </mesh>
          )}
          {avatar.glasses === 3 && (
            <mesh position={[0.08, 0.04, 0.22]}>
              <torusGeometry args={[0.06, 0.012, 6, 16]} />
              <meshStandardMaterial color="#ffd700" metalness={1} roughness={0.2} />
            </mesh>
          )}
          {/* hats */}
          {hat === 1 && (
            <group position={[0, 0.17, 0]}>
              <mesh>
                <sphereGeometry args={[0.235, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2.4]} />
                <meshStandardMaterial color="#c0392b" />
              </mesh>
              <mesh position={[0, 0.02, 0.22]}>
                <boxGeometry args={[0.3, 0.02, 0.22]} />
                <meshStandardMaterial color="#c0392b" />
              </mesh>
            </group>
          )}
          {hat === 2 && (
            <mesh position={[0, 0.2, 0]}>
              <sphereGeometry args={[0.26, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2.1]} />
              <meshStandardMaterial color="#4a5a3a" roughness={1} />
            </mesh>
          )}
          {hat === 3 && (
            <group position={[0, 0.2, 0]}>
              <mesh>
                <cylinderGeometry args={[0.2, 0.22, 0.22, 16]} />
                <meshStandardMaterial color="#3a2a1a" />
              </mesh>
              <mesh position={[0, -0.1, 0]}>
                <cylinderGeometry args={[0.4, 0.4, 0.03, 20]} />
                <meshStandardMaterial color="#3a2a1a" />
              </mesh>
              <mesh position={[0, -0.05, 0]}>
                <cylinderGeometry args={[0.21, 0.23, 0.05, 16]} />
                <meshStandardMaterial color="#8a1030" />
              </mesh>
            </group>
          )}
          {hat === 4 && (
            <group position={[0, 0.3, 0]}>
              <mesh>
                <cylinderGeometry args={[0.2, 0.2, 0.42, 16]} />
                <meshStandardMaterial color="#111" roughness={0.3} />
              </mesh>
              <mesh position={[0, -0.2, 0]}>
                <cylinderGeometry args={[0.34, 0.34, 0.03, 20]} />
                <meshStandardMaterial color="#111" roughness={0.3} />
              </mesh>
              <mesh position={[0, -0.14, 0]}>
                <cylinderGeometry args={[0.21, 0.21, 0.05, 16]} />
                <meshStandardMaterial color="#ffd700" metalness={1} roughness={0.2} />
              </mesh>
            </group>
          )}
          {hat === 5 && (
            <group position={[0, 0.24, 0]}>
              <mesh>
                <cylinderGeometry args={[0.2, 0.17, 0.14, 8]} />
                <meshStandardMaterial color="#ffd700" metalness={1} roughness={0.15} />
              </mesh>
              {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
                <mesh key={i} position={[Math.cos((i * Math.PI) / 4) * 0.19, 0.13, Math.sin((i * Math.PI) / 4) * 0.19]}>
                  <coneGeometry args={[0.04, 0.12, 4]} />
                  <meshStandardMaterial color="#ffd700" metalness={1} roughness={0.15} />
                </mesh>
              ))}
              <mesh position={[0, 0.05, 0.19]}>
                <sphereGeometry args={[0.04, 8, 8]} />
                <meshStandardMaterial color="#ff1a4d" emissive="#ff1a4d" emissiveIntensity={0.6} />
              </mesh>
            </group>
          )}
          {hat === 6 && (
            <group position={[0, 0.15, 0]}>
              <mesh>
                <sphereGeometry args={[0.26, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2.1]} />
                <meshStandardMaterial color="#8a8a8a" metalness={0.8} roughness={0.4} />
              </mesh>
              {[-1, 1].map((s) => (
                <mesh key={s} position={[s * 0.28, 0.12, 0]} rotation={[0, 0, (s * -Math.PI) / 5]}>
                  <coneGeometry args={[0.06, 0.35, 8]} />
                  <meshStandardMaterial color="#f0e6c8" />
                </mesh>
              ))}
            </group>
          )}
        </group>
      </group>
      {outlineColor && (
        <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.4, 0.5, 32]} />
          <meshBasicMaterial color={outlineColor} transparent opacity={0.8} />
        </mesh>
      )}
    </group>
  );
}
