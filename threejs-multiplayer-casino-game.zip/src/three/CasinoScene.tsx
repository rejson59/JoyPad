import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Html, Sparkles, useTexture } from "@react-three/drei";
import * as THREE from "three";
import { CASINOS, PLAYER_COLORS, ROOM, STATIONS, type PlayerId } from "../game/data";
import { moveSpeed, useGame } from "../game/store";
import { bodies } from "../game/world";
import { getAxis } from "../game/input";
import { posterTexture, textTexture } from "../game/textures";
import { Avatar } from "./Avatar";
import { STATION_RADIUS, StationMesh } from "./Stations";

import carpetRed from "../assets/carpet_red.jpg";
import carpetLux from "../assets/carpet_lux.jpg";
import marble from "../assets/marble.jpg";
import damask from "../assets/wall_damask.jpg";

const FLOORS = { carpet_red: carpetRed, carpet_lux: carpetLux, marble };

function Room({ tier }: { tier: number }) {
  const casino = CASINOS[tier];
  const [floorTex, wallTex] = useTexture([FLOORS[casino.floor], damask]);
  useMemo(() => {
    floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
    floorTex.repeat.set(casino.floor === "marble" ? 6 : 5, casino.floor === "marble" ? 5 : 4);
    floorTex.colorSpace = THREE.SRGBColorSpace;
    floorTex.anisotropy = 8;
    wallTex.wrapS = wallTex.wrapT = THREE.RepeatWrapping;
    wallTex.repeat.set(8, 2);
    wallTex.colorSpace = THREE.SRGBColorSpace;
  }, [floorTex, wallTex, casino.floor]);

  const nameTex = useMemo(() => textTexture(casino.name.toUpperCase(), { color: casino.accent, glow: casino.accent, font: "bold 100px Impact, Arial Black, sans-serif", w: 2048, h: 256 }), [casino]);
  const exitTex = useMemo(() => textTexture("WYJŚCIE", { color: "#7cff4d", glow: "#7cff4d", font: "bold 120px Arial Black, sans-serif" }), []);
  const H = 7;
  const posters = useMemo(() => [0, 1, 2, 3, 4].map((i) => posterTexture(i)), []);
  const isMarble = casino.floor === "marble";

  return (
    <group>
      {/* floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[ROOM.w, ROOM.d]} />
        <meshStandardMaterial map={floorTex} roughness={isMarble ? 0.15 : 0.95} metalness={isMarble ? 0.3 : 0} />
      </mesh>
      {/* red carpet strip to entrance */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 10]} receiveShadow>
        <planeGeometry args={[3, 8]} />
        <meshStandardMaterial color="#8a0f26" roughness={1} />
      </mesh>
      {/* ceiling */}
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, H, 0]}>
        <planeGeometry args={[ROOM.w, ROOM.d]} />
        <meshStandardMaterial color="#120a08" roughness={1} />
      </mesh>
      {/* walls */}
      {[
        { p: [0, H / 2, -ROOM.d / 2], r: [0, 0, 0], w: ROOM.w },
        { p: [0, H / 2, ROOM.d / 2], r: [0, Math.PI, 0], w: ROOM.w },
        { p: [-ROOM.w / 2, H / 2, 0], r: [0, Math.PI / 2, 0], w: ROOM.d },
        { p: [ROOM.w / 2, H / 2, 0], r: [0, -Math.PI / 2, 0], w: ROOM.d },
      ].map((wall, i) => (
        <group key={i} position={wall.p as [number, number, number]} rotation={wall.r as [number, number, number]}>
          <mesh receiveShadow>
            <planeGeometry args={[wall.w, H]} />
            <meshStandardMaterial map={wallTex} color={casino.wallColor} roughness={0.9} />
          </mesh>
          {/* wainscot */}
          <mesh position={[0, -H / 2 + 0.6, 0.05]}>
            <boxGeometry args={[wall.w, 1.2, 0.1]} />
            <meshStandardMaterial color="#2a160a" roughness={0.5} />
          </mesh>
          <mesh position={[0, -H / 2 + 1.22, 0.08]}>
            <boxGeometry args={[wall.w, 0.08, 0.14]} />
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
          </mesh>
          <mesh position={[0, H / 2 - 0.3, 0.08]}>
            <boxGeometry args={[wall.w, 0.3, 0.16]} />
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
          </mesh>
        </group>
      ))}
      {/* big neon casino name on back wall */}
      <group position={[0, 5.3, -ROOM.d / 2 + 0.2]}>
        <mesh>
          <planeGeometry args={[16, 2]} />
          <meshBasicMaterial map={nameTex} transparent toneMapped={false} />
        </mesh>
        <pointLight color={casino.accent} intensity={8} distance={14} decay={2} position={[0, 0, 2]} />
      </group>
      {/* entrance door */}
      <group position={[0, 0, ROOM.d / 2 - 0.15]}>
        <mesh position={[0, 1.8, 0]}>
          <boxGeometry args={[3.2, 3.6, 0.2]} />
          <meshStandardMaterial color="#1a0d05" roughness={0.4} />
        </mesh>
        {[-0.8, 0.8].map((x) => (
          <mesh key={x} position={[x, 1.8, -0.12]}>
            <boxGeometry args={[1.4, 3.3, 0.06]} />
            <meshStandardMaterial color="#5a2c14" roughness={0.4} />
          </mesh>
        ))}
        <mesh position={[0, 4.1, -0.1]}>
          <planeGeometry args={[3, 0.75]} />
          <meshBasicMaterial map={exitTex} transparent toneMapped={false} />
        </mesh>
        <pointLight color="#7cff4d" intensity={3} distance={6} decay={2} position={[0, 4, -1]} />
        {/* velvet ropes */}
        {[-2.2, 2.2].map((x) =>
          [-1, -3.5].map((z) => (
            <group key={`${x}${z}`} position={[x, 0, z]}>
              <mesh position={[0, 0.5, 0]}>
                <cylinderGeometry args={[0.03, 0.03, 1, 8]} />
                <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
              </mesh>
              <mesh position={[0, 1.0, 0]}>
                <sphereGeometry args={[0.07, 10, 10]} />
                <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
              </mesh>
              <mesh position={[0, 0.02, 0]}>
                <cylinderGeometry args={[0.2, 0.2, 0.04, 12]} />
                <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
              </mesh>
            </group>
          ))
        )}
        {[-2.2, 2.2].map((x) => (
          <mesh key={x} position={[x, 0.85, -2.25]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[1.25, 0.03, 8, 24, Math.PI]} />
            <meshStandardMaterial color="#8a0f26" roughness={0.8} />
          </mesh>
        ))}
      </group>
      {/* columns */}
      {[
        [-9, -5],
        [9, -5],
        [-9, 5],
        [9, 5],
      ].map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <mesh position={[0, H / 2, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.45, 0.5, H, 20]} />
            <meshStandardMaterial color={isMarble ? "#e8e4dc" : "#3a2a1a"} roughness={0.3} metalness={0.1} />
          </mesh>
          <mesh position={[0, 0.3, 0]}>
            <cylinderGeometry args={[0.7, 0.75, 0.6, 20]} />
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
          </mesh>
          <mesh position={[0, H - 0.3, 0]}>
            <cylinderGeometry args={[0.75, 0.55, 0.6, 20]} />
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
          </mesh>
        </group>
      ))}
      {/* posters */}
      {[
        { p: [-10, 3, -ROOM.d / 2 + 0.12], r: 0, i: 0 },
        { p: [10, 3, -ROOM.d / 2 + 0.12], r: 0, i: 1 },
        { p: [-ROOM.w / 2 + 0.12, 3, 12], r: Math.PI / 2, i: 2 },
        { p: [ROOM.w / 2 - 0.12, 3, -12], r: -Math.PI / 2, i: 3 },
        { p: [-8, 3, ROOM.d / 2 - 0.12], r: Math.PI, i: 4 },
        { p: [8, 3, ROOM.d / 2 - 0.12], r: Math.PI, i: 0 },
      ].map((po, k) => (
        <group key={k} position={po.p as [number, number, number]} rotation={[0, po.r, 0]}>
          <mesh>
            <planeGeometry args={[2, 3]} />
            <meshStandardMaterial map={posters[po.i]} />
          </mesh>
          <mesh position={[0, 0, -0.03]}>
            <boxGeometry args={[2.2, 3.2, 0.05]} />
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
          </mesh>
          <pointLight position={[0, 1.8, 1.2]} intensity={3} distance={5} decay={2} color="#fff2c2" />
        </group>
      ))}
      {/* chandeliers */}
      {[
        [0, -6],
        [0, 4],
        [-10, 0],
        [10, 0],
      ].map(([x, z], i) => (
        <Chandelier key={i} position={[x, H - 1.2, z]} color={casino.light} big={i < 2} />
      ))}
      {/* plants */}
      {[
        [-16, -12],
        [16, -12],
        [-16, 12],
        [16, 12],
      ].map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <mesh position={[0, 0.4, 0]} castShadow>
            <cylinderGeometry args={[0.4, 0.3, 0.8, 12]} />
            <meshStandardMaterial color="#8a6a3a" roughness={0.8} />
          </mesh>
          {[0, 1, 2, 3, 4].map((k) => (
            <mesh key={k} position={[Math.cos(k * 1.25) * 0.3, 1.3 + k * 0.1, Math.sin(k * 1.25) * 0.3]} rotation={[Math.cos(k) * 0.6, k, Math.sin(k) * 0.6]} castShadow>
              <coneGeometry args={[0.25, 1.4, 6]} />
              <meshStandardMaterial color="#1f6b2a" roughness={0.9} />
            </mesh>
          ))}
        </group>
      ))}
      <Sparkles count={isMarble ? 160 : 80} scale={[ROOM.w, 5, ROOM.d]} position={[0, 3, 0]} size={3} speed={0.3} color={casino.accent} opacity={0.5} />
    </group>
  );
}

function Chandelier({ position, color, big }: { position: [number, number, number]; color: string; big: boolean }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (ref.current) ref.current.rotation.y = clock.elapsedTime * 0.1;
  });
  const r = big ? 1.4 : 0.9;
  return (
    <group position={position}>
      <mesh position={[0, 0.8, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 1.6, 6]} />
        <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.3} />
      </mesh>
      <group ref={ref}>
        {[r, r * 0.6].map((rad, i) => (
          <mesh key={i} position={[0, -i * 0.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[rad, 0.05, 8, 40]} />
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.2} />
          </mesh>
        ))}
        {Array.from({ length: big ? 14 : 8 }).map((_, i) => {
          const a = (i / (big ? 14 : 8)) * Math.PI * 2;
          return (
            <group key={i} position={[Math.cos(a) * r, 0, Math.sin(a) * r]}>
              <mesh position={[0, 0.15, 0]}>
                <cylinderGeometry args={[0.03, 0.05, 0.3, 8]} />
                <meshStandardMaterial color="#fff8e0" emissive={color} emissiveIntensity={2} />
              </mesh>
              <mesh position={[0, -0.35, 0]}>
                <octahedronGeometry args={[0.09]} />
                <meshPhysicalMaterial color="#ffffff" transmission={0.9} roughness={0} thickness={0.5} ior={2.4} />
              </mesh>
            </group>
          );
        })}
        <mesh>
          <sphereGeometry args={[0.25, 16, 16]} />
          <meshStandardMaterial color="#fff" emissive={color} emissiveIntensity={3} />
        </mesh>
      </group>
      <pointLight color={color} intensity={big ? 40 : 18} distance={big ? 22 : 14} decay={2} position={[0, -0.5, 0]} castShadow={big} shadow-mapSize={[1024, 1024]} shadow-bias={-0.002} />
    </group>
  );
}

function Stations() {
  return (
    <>
      {STATIONS.map((s) => (
        <group key={s.id} position={[s.pos[0], 0, s.pos[1]]} rotation={[0, s.rot, 0]}>
          <StationMesh station={s} />
        </group>
      ))}
    </>
  );
}

function resolveCollisions(x: number, z: number, radius: number) {
  const half = { x: ROOM.w / 2 - 0.9, z: ROOM.d / 2 - 0.9 };
  x = THREE.MathUtils.clamp(x, -half.x, half.x);
  z = THREE.MathUtils.clamp(z, -half.z, half.z);
  for (const s of STATIONS) {
    const r = STATION_RADIUS[s.type].coll + radius;
    const dx = x - s.pos[0];
    const dz = z - s.pos[1];
    const d = Math.hypot(dx, dz);
    if (d < r && d > 0.0001) {
      x = s.pos[0] + (dx / d) * r;
      z = s.pos[1] + (dz / d) * r;
    }
  }
  // columns
  for (const [cx, cz] of [
    [-9, -5],
    [9, -5],
    [-9, 5],
    [9, 5],
  ]) {
    const r = 0.6 + radius;
    const dx = x - cx,
      dz = z - cz;
    const d = Math.hypot(dx, dz);
    if (d < r && d > 0.0001) {
      x = cx + (dx / d) * r;
      z = cz + (dz / d) * r;
    }
  }
  return { x, z };
}

function PlayerEntity({ pid, setNear }: { pid: PlayerId; setNear: (pid: PlayerId, id: string | null) => void }) {
  const player = useGame((s) => s.players[pid]);
  const consumeKick = useGame((s) => s.consumeKick);
  const group = useRef<THREE.Group>(null);
  const walkRef = useRef({ moving: false, drunk: 0 });
  const nearRef = useRef<string | null>(null);
  const kickSeq = useRef(player.kickSeq);

  useEffect(() => {
    if (player.kickTo && player.kickSeq !== kickSeq.current) {
      kickSeq.current = player.kickSeq;
      bodies[pid].x = player.kickTo[0] + (pid - 1.5) * 1.2;
      bodies[pid].z = player.kickTo[1];
      consumeKick(pid);
    }
  }, [player.kickTo, player.kickSeq, pid, consumeKick]);

  useFrame(({ clock }, dt) => {
    const b = bodies[pid];
    const busy = player.activity !== null;
    let { x: ax, z: az } = busy ? { x: 0, z: 0 } : getAxis(pid);
    // drunk sway: rotate input
    if (player.drunk > 0 && (ax || az)) {
      const a = Math.sin(clock.elapsedTime * 1.5) * Math.min(1.2, player.drunk) * 0.9;
      const c = Math.cos(a),
        s = Math.sin(a);
      const nx = ax * c - az * s;
      const nz = ax * s + az * c;
      ax = nx;
      az = nz;
    }
    const len = Math.hypot(ax, az);
    b.moving = len > 0.01;
    if (b.moving) {
      const sp = 4.8 * moveSpeed(player) * Math.min(dt, 0.05);
      const nx = b.x + (ax / len) * sp;
      const nz = b.z + (az / len) * sp;
      const res = resolveCollisions(nx, nz, 0.35);
      b.x = res.x;
      b.z = res.z;
      const target = Math.atan2(ax, az);
      let diff = target - b.rot;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      b.rot += diff * Math.min(1, dt * 14);
    }
    // player-player push
    for (let j = 0; j < 4; j++) {
      if (j === pid) continue;
      const o = bodies[j];
      const dx = b.x - o.x,
        dz = b.z - o.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.7 && d > 0.001) {
        b.x += (dx / d) * (0.7 - d) * 0.5;
        b.z += (dz / d) * (0.7 - d) * 0.5;
      }
    }
    // nearest station
    let near: string | null = null;
    let best = 1e9;
    for (const s of STATIONS) {
      const d = Math.hypot(b.x - s.pos[0], b.z - s.pos[1]);
      if (d < STATION_RADIUS[s.type].interact && d < best) {
        best = d;
        near = s.id;
      }
    }
    b.near = near;
    if (near !== nearRef.current) {
      nearRef.current = near;
      setNear(pid, near);
    }
    walkRef.current.moving = b.moving;
    walkRef.current.drunk = player.drunk;
    if (group.current) {
      group.current.position.set(b.x, 0, b.z);
      group.current.rotation.y = b.rot;
    }
  });

  const color = PLAYER_COLORS[pid];
  return (
    <group ref={group}>
      <Avatar avatar={player.avatar} limbs={player.limbs} walkRef={walkRef} outlineColor={color} />
      <pointLight color={color} intensity={1.2} distance={3} decay={2} position={[0, 1.5, 0]} />
    </group>
  );
}

function PlayerLabels({ near }: { near: (string | null)[] }) {
  const players = useGame((s) => s.players);
  const refs = useRef<(THREE.Group | null)[]>([]);
  useFrame(() => {
    refs.current.forEach((g, i) => {
      if (g) g.position.set(bodies[i].x, 2.5, bodies[i].z);
    });
  });
  return (
    <>
      {players.map(
        (p) =>
          p.joined && (
            <group key={p.id} ref={(el) => (refs.current[p.id] = el)}>
              <Html center distanceFactor={14} zIndexRange={[5, 0]} style={{ pointerEvents: "none" }}>
                <div className="flex flex-col items-center gap-1 select-none" style={{ transform: "translateY(-10px)" }}>
                  {near[p.id] && !p.activity && (
                    <div className="px-3 py-1 rounded-full text-sm font-bold text-black bg-white/95 shadow-lg animate-bounce whitespace-nowrap">
                      {STATIONS.find((s) => s.id === near[p.id])?.label} — naciśnij{" "}
                      <span className="px-1.5 rounded bg-black text-white">{["E", "Enter", "O", "Y"][p.id]}</span>
                    </div>
                  )}
                  <div className="px-3 py-0.5 rounded-full text-base font-black text-white shadow-lg whitespace-nowrap border-2" style={{ background: PLAYER_COLORS[p.id] + "cc", borderColor: "#fff5" }}>
                    {p.name}
                    {p.drunk > 0.5 && " 🍺"}
                    {p.luck > 0 && " 🍀"}
                  </div>
                </div>
              </Html>
            </group>
          )
      )}
    </>
  );
}

function NPCs({ count }: { count: number }) {
  const npcs = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        avatar: { skin: i % 6, hair: (i * 2) % 6, hairColor: (i * 3) % 8, outfit: 1 + ((i * 2) % 4), hat: i % 3 === 0 ? 3 : 0, glasses: i % 4 === 0 ? 2 : 0, beard: i % 4, chain: i % 5 === 0 },
        x: (Math.random() - 0.5) * 20,
        z: (Math.random() - 0.5) * 14,
        tx: 0,
        tz: 0,
        rot: 0,
        wait: Math.random() * 3,
        ref: { current: null as THREE.Group | null },
        walk: { current: { moving: false, drunk: 0 } },
      })),
    [count]
  );
  useFrame((_, dt) => {
    for (const n of npcs) {
      if (n.wait > 0) {
        n.wait -= dt;
        n.walk.current.moving = false;
        if (n.wait <= 0) {
          n.tx = (Math.random() - 0.5) * 24;
          n.tz = (Math.random() - 0.5) * 18;
        }
      } else {
        const dx = n.tx - n.x,
          dz = n.tz - n.z;
        const d = Math.hypot(dx, dz);
        if (d < 0.3) {
          n.wait = 2 + Math.random() * 5;
        } else {
          const sp = 1.6 * dt;
          const res = resolveCollisions(n.x + (dx / d) * sp, n.z + (dz / d) * sp, 0.3);
          if (Math.hypot(res.x - n.x, res.z - n.z) < sp * 0.3) n.wait = 1;
          n.x = res.x;
          n.z = res.z;
          n.rot = Math.atan2(dx, dz);
          n.walk.current.moving = true;
        }
      }
      if (n.ref.current) {
        n.ref.current.position.set(n.x, 0, n.z);
        n.ref.current.rotation.y = n.rot;
      }
    }
  });
  return (
    <>
      {npcs.map((n, i) => (
        <group key={i} ref={(el) => (n.ref.current = el)}>
          <Avatar avatar={n.avatar} walkRef={n.walk} idleOffset={i} />
        </group>
      ))}
    </>
  );
}

function CameraRig() {
  const { camera } = useThree();
  const players = useGame((s) => s.players);
  const target = useRef(new THREE.Vector3(0, 0, 8));
  const pos = useRef(new THREE.Vector3(0, 12, 20));
  useFrame((_, dt) => {
    const joined = players.filter((p) => p.joined);
    let cx = 0,
      cz = 0,
      minX = 1e9,
      maxX = -1e9,
      minZ = 1e9,
      maxZ = -1e9;
    for (const p of joined) {
      const b = bodies[p.id];
      cx += b.x;
      cz += b.z;
      minX = Math.min(minX, b.x);
      maxX = Math.max(maxX, b.x);
      minZ = Math.min(minZ, b.z);
      maxZ = Math.max(maxZ, b.z);
    }
    const n = Math.max(1, joined.length);
    cx /= n;
    cz /= n;
    const spread = joined.length ? Math.max(maxX - minX, (maxZ - minZ) * 1.4) : 0;
    const dist = THREE.MathUtils.clamp(9 + spread * 0.75, 9, 26);
    const camZ = Math.min(cz + dist * 0.8, ROOM.d / 2 - 1.2);
    const camY = dist * 0.95 + Math.max(0, cz + dist * 0.8 - camZ) * 0.6;
    target.current.lerp(new THREE.Vector3(cx, 1, cz), Math.min(1, dt * 3));
    pos.current.lerp(new THREE.Vector3(cx, camY, camZ), Math.min(1, dt * 3));
    camera.position.copy(pos.current);
    camera.lookAt(target.current);
  });
  return null;
}

export function CasinoScene() {
  const tier = useGame((s) => s.tier);
  const players = useGame((s) => s.players);
  const [near, setNearState] = useState<(string | null)[]>([null, null, null, null]);
  const setNear = (pid: PlayerId, id: string | null) =>
    setNearState((prev) => {
      if (prev[pid] === id) return prev;
      const n = [...prev];
      n[pid] = id;
      return n;
    });
  const casino = CASINOS[tier];

  return (
    <Canvas
      shadows
      dpr={[1, 1.5]}
      camera={{ fov: 45, near: 0.1, far: 100, position: [0, 12, 20] }}
      gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.1 }}
      style={{ position: "absolute", inset: 0 }}
    >
      <color attach="background" args={[casino.fog]} />
      <fog attach="fog" args={[casino.fog, 22, 70]} />
      <ambientLight intensity={casino.ambient} color={casino.light} />
      <hemisphereLight intensity={0.4} color={casino.light} groundColor="#2a1a10" />
      <Suspense fallback={null}>
        <Room tier={tier} />
      </Suspense>
      <Stations />
      <NPCs count={6 + tier * 2} />
      {players.map((p) => p.joined && <PlayerEntity key={p.id} pid={p.id} setNear={setNear} />)}
      <PlayerLabels near={near} />
      <CameraRig />
    </Canvas>
  );
}
