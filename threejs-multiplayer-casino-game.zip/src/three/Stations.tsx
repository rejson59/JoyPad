import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { Station } from "../game/data";
import {
  feltTexture,
  rouletteLayoutTexture,
  rouletteWheelTexture,
  slotScreenTexture,
  textTexture,
  wheelTexture,
} from "../game/textures";
import { Avatar } from "./Avatar";

const gold = <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.25} />;
const wood = <meshStandardMaterial color="#4a2c14" roughness={0.6} />;
const chrome = <meshStandardMaterial color="#cfd6dd" metalness={1} roughness={0.2} />;

function Sign({ text, color = "#ffd84d", glow, w = 3, y = 3.2, z = -0.6 }: { text: string; color?: string; glow?: string; w?: number; y?: number; z?: number }) {
  const tex = useMemo(() => textTexture(text, { color, glow: glow ?? color, font: "bold 110px Impact, Arial Black, sans-serif" }), [text, color, glow]);
  return (
    <group position={[0, y, z]}>
      <mesh>
        <planeGeometry args={[w, w / 4]} />
        <meshBasicMaterial map={tex} transparent side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
    </group>
  );
}

function Stool({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 0.25, 0]} castShadow>
        <cylinderGeometry args={[0.04, 0.04, 0.5, 8]} />
        {chrome}
      </mesh>
      <mesh position={[0, 0.52, 0]} castShadow>
        <cylinderGeometry args={[0.22, 0.2, 0.08, 16]} />
        <meshStandardMaterial color="#8a1030" roughness={0.5} />
      </mesh>
      <mesh position={[0, 0.02, 0]}>
        <cylinderGeometry args={[0.25, 0.25, 0.04, 16]} />
        {chrome}
      </mesh>
    </group>
  );
}

function Chips({ position }: { position: [number, number, number] }) {
  const cols = ["#c0392b", "#2980b9", "#27ae60", "#111", "#f1c40f"];
  return (
    <group position={position}>
      {cols.map((c, i) => (
        <mesh key={i} position={[(i - 2) * 0.14, 0.03 + (i % 2) * 0.01, 0]} castShadow>
          <cylinderGeometry args={[0.06, 0.06, 0.06 + (i % 3) * 0.02, 12]} />
          <meshStandardMaterial color={c} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

function Dealer({ position, rot = 0, outfit = 3, seed = 0 }: { position: [number, number, number]; rot?: number; outfit?: number; seed?: number }) {
  return (
    <group position={position} rotation={[0, rot, 0]}>
      <Avatar avatar={{ skin: seed % 6, hair: 1, hairColor: (seed + 1) % 8, outfit, hat: 0, glasses: 0, beard: 0, chain: false }} idleOffset={seed} />
    </group>
  );
}

export function SlotMachine({ seed }: { seed: number }) {
  const screen = useMemo(() => slotScreenTexture(seed), [seed]);
  const light = useRef<THREE.MeshStandardMaterial>(null);
  const colors = ["#ff2bd6", "#ffd84d", "#4dd2ff", "#7cff4d"];
  const c = colors[seed % 4];
  useFrame(({ clock }) => {
    if (light.current) light.current.emissiveIntensity = 1.5 + Math.sin(clock.elapsedTime * 4 + seed) * 1;
  });
  return (
    <group>
      {/* body */}
      <mesh position={[0, 0.9, 0]} castShadow receiveShadow>
        <boxGeometry args={[1, 1.8, 0.8]} />
        <meshStandardMaterial color="#2a1a3a" metalness={0.5} roughness={0.35} />
      </mesh>
      {/* screen */}
      <mesh position={[0, 1.25, 0.41]}>
        <planeGeometry args={[0.85, 0.85]} />
        <meshBasicMaterial map={screen} toneMapped={false} />
      </mesh>
      {/* trim */}
      <mesh position={[0, 1.25, 0.405]}>
        <boxGeometry args={[0.95, 0.95, 0.02]} />
        {gold}
      </mesh>
      {/* top light dome */}
      <mesh position={[0, 2.0, 0]}>
        <cylinderGeometry args={[0.15, 0.15, 0.4, 16]} />
        <meshStandardMaterial ref={light} color={c} emissive={c} emissiveIntensity={2} transparent opacity={0.9} />
      </mesh>
      <pointLight position={[0, 2.1, 0.3]} color={c} intensity={3} distance={5} decay={2} />
      {/* panel */}
      <mesh position={[0, 0.65, 0.5]} rotation={[-0.4, 0, 0]}>
        <boxGeometry args={[0.9, 0.3, 0.25]} />
        <meshStandardMaterial color="#111" roughness={0.4} />
      </mesh>
      {[-0.25, 0, 0.25].map((x, i) => (
        <mesh key={i} position={[x, 0.73, 0.6]} rotation={[-0.4, 0, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 0.04, 12]} />
          <meshStandardMaterial color={["#ff3b3b", "#ffd84d", "#2ecc71"][i]} emissive={["#ff3b3b", "#ffd84d", "#2ecc71"][i]} emissiveIntensity={0.8} />
        </mesh>
      ))}
      {/* lever */}
      <group position={[0.58, 1.1, 0.1]}>
        <mesh rotation={[0.4, 0, 0]} position={[0, 0.2, 0]}>
          <cylinderGeometry args={[0.025, 0.025, 0.6, 8]} />
          {chrome}
        </mesh>
        <mesh position={[0, 0.5, -0.11]}>
          <sphereGeometry args={[0.08, 12, 12]} />
          <meshStandardMaterial color="#e21b3c" roughness={0.3} />
        </mesh>
      </group>
      {/* coin tray */}
      <mesh position={[0, 0.25, 0.45]}>
        <boxGeometry args={[0.7, 0.15, 0.2]} />
        {chrome}
      </mesh>
      <Stool position={[0, 0, 1.1]} />
    </group>
  );
}

export function BlackjackTable() {
  const felt = useMemo(() => feltTexture("#0d5c2e"), []);
  return (
    <group>
      <mesh position={[0, 0.78, 0]} rotation={[0, Math.PI, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[2, 2, 0.12, 32, 1, false, 0, Math.PI]} />
        <meshStandardMaterial map={felt} roughness={0.9} />
      </mesh>
      <mesh position={[0, 0.78, 0]} rotation={[0, Math.PI, 0]}>
        <torusGeometry args={[2, 0.12, 12, 48, Math.PI]} />
        <meshStandardMaterial color="#3a1a0a" roughness={0.5} />
      </mesh>
      <mesh position={[0, 0.78, 0]}>
        <boxGeometry args={[4.1, 0.2, 0.25]} />
        {wood}
      </mesh>
      <mesh position={[0, 0.38, 0.6]} castShadow>
        <cylinderGeometry args={[0.5, 0.7, 0.75, 16]} />
        {wood}
      </mesh>
      <Chips position={[-0.6, 0.85, -0.3]} />
      <Chips position={[0.7, 0.85, -0.4]} />
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[-0.3 + i * 0.3, 0.86, 0.6]} rotation={[-Math.PI / 2, 0, 0.1 * i]}>
          <planeGeometry args={[0.25, 0.36]} />
          <meshStandardMaterial color="#fff" />
        </mesh>
      ))}
      <Dealer position={[0, 0, -0.7]} rot={0} seed={2} />
      <Stool position={[-1.2, 0, 1.6]} />
      <Stool position={[0, 0, 1.9]} />
      <Stool position={[1.2, 0, 1.6]} />
      <Sign text="BLACKJACK" color="#ffd84d" y={3} z={-1.2} />
    </group>
  );
}

export function RouletteTable() {
  const layout = useMemo(() => rouletteLayoutTexture(), []);
  const wheel = useMemo(() => rouletteWheelTexture(), []);
  const wheelRef = useRef<THREE.Mesh>(null);
  const ball = useRef<THREE.Mesh>(null);
  useFrame(({ clock }, dt) => {
    if (wheelRef.current) wheelRef.current.rotation.y += dt * 0.8;
    if (ball.current) {
      const a = -clock.elapsedTime * 2.2;
      ball.current.position.set(Math.cos(a) * 0.62, 0.98, Math.sin(a) * 0.62);
    }
  });
  return (
    <group>
      <mesh position={[0.7, 0.78, 0]} castShadow receiveShadow>
        <boxGeometry args={[3.2, 0.16, 1.7]} />
        <meshStandardMaterial map={layout} roughness={0.9} />
      </mesh>
      <mesh position={[0.7, 0.72, 0]}>
        <boxGeometry args={[3.4, 0.2, 1.9]} />
        {wood}
      </mesh>
      <mesh position={[-1.7, 0.75, 0]} castShadow>
        <cylinderGeometry args={[1.0, 1.1, 0.25, 32]} />
        {wood}
      </mesh>
      <mesh ref={wheelRef} position={[-1.7, 0.9, 0]}>
        <cylinderGeometry args={[0.9, 0.9, 0.08, 48]} />
        <meshStandardMaterial map={wheel} roughness={0.4} metalness={0.3} />
      </mesh>
      <mesh ref={ball} position={[-1.1, 0.98, 0]}>
        <sphereGeometry args={[0.05, 10, 10]} />
        <meshStandardMaterial color="#fff" roughness={0.1} />
      </mesh>
      <Chips position={[0.2, 0.9, 0.3]} />
      <Chips position={[1.6, 0.9, -0.3]} />
      {[-0.8, 0.9].map((x) => (
        <mesh key={x} position={[x + 0.7, 0.35, 0]} castShadow>
          <boxGeometry args={[0.5, 0.7, 1.2]} />
          {wood}
        </mesh>
      ))}
      <Dealer position={[0.7, 0, -1.4]} seed={5} />
      <Sign text="RULETKA" color="#ff4d6d" y={3} z={-1.5} />
    </group>
  );
}

export function DiceTable() {
  const felt = useMemo(() => feltTexture("#5c0d1e", "KOŚCI • CRAPS"), []);
  const d1 = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (d1.current) d1.current.rotation.y = clock.elapsedTime * 0.5;
  });
  return (
    <group>
      <mesh position={[0, 0.78, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 0.16, 1.8]} />
        <meshStandardMaterial map={felt} roughness={0.9} />
      </mesh>
      {[
        [0, 0.95, -0.95, 3.2, 0.3, 0.12],
        [0, 0.95, 0.95, 3.2, 0.3, 0.12],
        [-1.55, 0.95, 0, 0.12, 0.3, 1.9],
        [1.55, 0.95, 0, 0.12, 0.3, 1.9],
      ].map((b, i) => (
        <mesh key={i} position={[b[0], b[1], b[2]]} castShadow>
          <boxGeometry args={[b[3], b[4], b[5]]} />
          <meshStandardMaterial color="#3a1a0a" roughness={0.5} />
        </mesh>
      ))}
      <mesh position={[0, 0.38, 0]} castShadow>
        <boxGeometry args={[2.6, 0.75, 1.4]} />
        {wood}
      </mesh>
      <mesh ref={d1} position={[-0.3, 0.98, 0.1]} castShadow>
        <boxGeometry args={[0.22, 0.22, 0.22]} />
        <meshStandardMaterial color="#fff" roughness={0.2} />
      </mesh>
      <mesh position={[0.2, 0.98, -0.2]} rotation={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[0.22, 0.22, 0.22]} />
        <meshStandardMaterial color="#e21b3c" roughness={0.2} />
      </mesh>
      <Chips position={[0.9, 0.9, 0.4]} />
      <Dealer position={[0, 0, -1.4]} seed={1} />
      <Sign text="KOŚCI" color="#ff9d4d" y={3} z={-1.4} />
    </group>
  );
}

export function PokerMachine() {
  const screen = useMemo(() => textTexture("VIDEO POKER", { color: "#4dd2ff", glow: "#4dd2ff", bg: "#061024", w: 512, h: 512, font: "bold 70px Impact, Arial Black" }), []);
  return (
    <group>
      <mesh position={[0, 0.6, 0]} castShadow receiveShadow>
        <boxGeometry args={[1.4, 1.2, 1]} />
        <meshStandardMaterial color="#0d1a33" metalness={0.5} roughness={0.35} />
      </mesh>
      <mesh position={[0, 1.4, -0.1]} rotation={[-0.3, 0, 0]} castShadow>
        <boxGeometry args={[1.3, 0.9, 0.3]} />
        <meshStandardMaterial color="#0d1a33" metalness={0.5} roughness={0.35} />
      </mesh>
      <mesh position={[0, 1.42, 0.07]} rotation={[-0.3, 0, 0]}>
        <planeGeometry args={[1.1, 0.7]} />
        <meshBasicMaterial map={screen} toneMapped={false} />
      </mesh>
      <pointLight position={[0, 1.6, 0.8]} color="#4dd2ff" intensity={2.5} distance={5} decay={2} />
      {[-0.4, -0.2, 0, 0.2, 0.4].map((x) => (
        <mesh key={x} position={[x, 1.22, 0.4]}>
          <cylinderGeometry args={[0.06, 0.06, 0.04, 12]} />
          <meshStandardMaterial color="#ffd84d" emissive="#ffd84d" emissiveIntensity={0.7} />
        </mesh>
      ))}
      <Stool position={[0, 0, 1.1]} />
      <Sign text="VIDEO POKER" color="#4dd2ff" y={3} z={-0.6} />
    </group>
  );
}

export function WheelOfFortune() {
  const tex = useMemo(() => wheelTexture(), []);
  const ref = useRef<THREE.Mesh>(null);
  const bulbs = useRef<THREE.Group>(null);
  useFrame(({ clock }, dt) => {
    if (ref.current) ref.current.rotation.z -= dt * 0.4;
    if (bulbs.current) bulbs.current.children.forEach((c, i) => {
      const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = (Math.floor(clock.elapsedTime * 6) + i) % 3 === 0 ? 3 : 0.3;
    });
  });
  return (
    <group>
      <mesh position={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[0.8, 1.2, 0.5]} />
        {wood}
      </mesh>
      <mesh ref={ref} position={[0, 2.5, 0.15]} rotation={[0, 0, 0]} castShadow>
        <cylinderGeometry args={[1.7, 1.7, 0.15, 48]} />
        <meshStandardMaterial map={tex} roughness={0.5} />
      </mesh>
      <mesh position={[0, 2.5, 0.15]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[1.7, 1.7, 0.15, 48]} />
        <meshStandardMaterial map={tex} roughness={0.5} />
      </mesh>
      <mesh position={[0, 2.5, 0.3]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.75, 0.08, 10, 60]} />
        {gold}
      </mesh>
      <group ref={bulbs}>
        {Array.from({ length: 16 }).map((_, i) => (
          <mesh key={i} position={[Math.cos((i / 16) * Math.PI * 2) * 1.75, 2.5 + Math.sin((i / 16) * Math.PI * 2) * 1.75, 0.38]}>
            <sphereGeometry args={[0.06, 8, 8]} />
            <meshStandardMaterial color="#fff2b0" emissive="#ffd84d" emissiveIntensity={1} />
          </mesh>
        ))}
      </group>
      <mesh position={[0, 4.35, 0.35]} rotation={[0, 0, Math.PI]}>
        <coneGeometry args={[0.15, 0.4, 4]} />
        <meshStandardMaterial color="#ff2b2b" emissive="#ff2b2b" emissiveIntensity={0.6} />
      </mesh>
      <pointLight position={[0, 2.5, 1.5]} color="#ffd84d" intensity={4} distance={7} decay={2} />
      <Sign text="KOŁO FORTUNY" color="#ffd84d" y={4.9} z={0.2} w={4} />
    </group>
  );
}

export function Bar() {
  const bottles = useMemo(() => Array.from({ length: 14 }, (_, i) => ({ x: -2.8 + i * 0.43, c: ["#4dd2ff", "#ffd84d", "#ff4d6d", "#7cff4d", "#c13fff", "#ffffff"][i % 6], h: 0.35 + (i % 3) * 0.1 })), []);
  return (
    <group>
      <mesh position={[0, 0.55, 0]} castShadow receiveShadow>
        <boxGeometry args={[6.5, 1.1, 0.9]} />
        <meshStandardMaterial color="#3a1c0a" roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.12, 0]}>
        <boxGeometry args={[6.7, 0.06, 1.1]} />
        <meshStandardMaterial color="#1a0d05" roughness={0.2} metalness={0.3} />
      </mesh>
      <mesh position={[0, 0.5, 0.46]}>
        <boxGeometry args={[6.5, 0.9, 0.02]} />
        <meshStandardMaterial color="#8a1030" roughness={0.7} />
      </mesh>
      {/* back shelf */}
      <group position={[0, 0, -2]}>
        <mesh position={[0, 1.4, 0]} castShadow>
          <boxGeometry args={[6.5, 2.8, 0.4]} />
          <meshStandardMaterial color="#2a1408" roughness={0.6} />
        </mesh>
        <mesh position={[0, 1.6, 0.21]}>
          <planeGeometry args={[6, 1.6]} />
          <meshStandardMaterial color="#8899aa" metalness={1} roughness={0.05} />
        </mesh>
        {[1.0, 1.7, 2.4].map((y) => (
          <mesh key={y} position={[0, y, 0.35]}>
            <boxGeometry args={[6.2, 0.04, 0.3]} />
            {gold}
          </mesh>
        ))}
        {bottles.map((b, i) => (
          <mesh key={i} position={[b.x, 1.02 + b.h / 2 + (i % 2) * 0.7, 0.35]} castShadow>
            <cylinderGeometry args={[0.06, 0.08, b.h, 10]} />
            <meshPhysicalMaterial color={b.c} transmission={0.6} roughness={0.1} thickness={0.3} />
          </mesh>
        ))}
        <pointLight position={[0, 2.2, 0.8]} color="#ff9ddb" intensity={5} distance={7} decay={2} />
      </group>
      <Dealer position={[0, 0, -1.1]} rot={0} outfit={2} seed={7} />
      {[-2, -0.7, 0.7, 2].map((x) => (
        <Stool key={x} position={[x, 0, 1]} />
      ))}
      <Sign text="BAR „U GRAŻYNY”" color="#ff2bd6" y={3.4} z={-1.8} w={5} />
    </group>
  );
}

export function Shop() {
  return (
    <group>
      <mesh position={[0, 0.45, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 0.9, 0.8]} />
        <meshStandardMaterial color="#f0e6d2" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.92, 0]}>
        <boxGeometry args={[3.1, 0.05, 0.9]} />
        {gold}
      </mesh>
      {/* rack */}
      <group position={[-2.3, 0, -1]}>
        <mesh position={[0, 1.7, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.02, 0.02, 2.2, 8]} />
          {chrome}
        </mesh>
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 1.05, 0.85, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 1.7, 8]} />
            {chrome}
          </mesh>
        ))}
        {["#1d3fb8", "#ff6b3d", "#1a1a22", "#2a0f3a", "#d4a017", "#c0392b"].map((c, i) => (
          <mesh key={i} position={[-0.8 + i * 0.32, 1.25, 0]} castShadow>
            <boxGeometry args={[0.25, 0.8, 0.12]} />
            <meshStandardMaterial color={c} roughness={0.8} metalness={c === "#d4a017" ? 0.7 : 0} />
          </mesh>
        ))}
      </group>
      {/* mannequin */}
      <group position={[2.2, 0, -1]}>
        <mesh position={[0, 0.1, 0]}>
          <cylinderGeometry args={[0.4, 0.4, 0.2, 20]} />
          {gold}
        </mesh>
        <group position={[0, 0.2, 0]}>
          <Avatar avatar={{ skin: 5, hair: 0, hairColor: 0, outfit: 5, hat: 4, glasses: 3, beard: 0, chain: true }} />
        </group>
        <pointLight position={[0, 2.5, 1]} color="#fff" intensity={3} distance={5} decay={2} />
      </group>
      <Dealer position={[0, 0, -0.9]} outfit={4} seed={3} />
      <Sign text="BUTIK „ELEGANCKI MENEL”" color="#ffffff" glow="#ffd84d" y={3.2} z={-1.3} w={5.5} />
    </group>
  );
}

export function PawnShop() {
  return (
    <group>
      <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[3, 1, 0.9]} />
        <meshStandardMaterial color="#4a4a4a" roughness={0.8} />
      </mesh>
      <mesh position={[0, 1.5, 0.05]}>
        <boxGeometry args={[3, 1, 0.05]} />
        <meshPhysicalMaterial color="#aaccee" transmission={0.8} roughness={0.05} thickness={0.1} transparent opacity={0.4} />
      </mesh>
      {/* back wall display */}
      <group position={[0, 0, -1.6]}>
        <mesh position={[0, 1.5, 0]} castShadow>
          <boxGeometry args={[3.4, 3, 0.3]} />
          <meshStandardMaterial color="#2b2b2b" roughness={0.9} />
        </mesh>
        {/* prosthetic leg */}
        <mesh position={[-1.1, 1.6, 0.25]} rotation={[0, 0, 0.1]} castShadow>
          <cylinderGeometry args={[0.07, 0.1, 0.9, 10]} />
          <meshStandardMaterial color="#c9a27a" roughness={0.6} />
        </mesh>
        <mesh position={[-1.05, 1.1, 0.33]}>
          <boxGeometry args={[0.16, 0.1, 0.3]} />
          <meshStandardMaterial color="#2a1a0a" />
        </mesh>
        {/* kidney jar */}
        <mesh position={[0, 1.7, 0.3]}>
          <cylinderGeometry args={[0.18, 0.18, 0.45, 16]} />
          <meshPhysicalMaterial color="#bfe8d2" transmission={0.7} roughness={0.05} thickness={0.2} transparent opacity={0.6} />
        </mesh>
        <mesh position={[0, 1.65, 0.3]}>
          <capsuleGeometry args={[0.08, 0.1, 4, 10]} />
          <meshStandardMaterial color="#a33a4a" roughness={0.3} />
        </mesh>
        {/* gold teeth */}
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[0.8 + i * 0.2, 1.9, 0.3]}>
            <boxGeometry args={[0.1, 0.12, 0.1]} />
            {gold}
          </mesh>
        ))}
        {/* arm */}
        <mesh position={[1.1, 1.3, 0.3]} rotation={[0, 0, -0.4]}>
          <capsuleGeometry args={[0.07, 0.5, 4, 10]} />
          <meshStandardMaterial color="#d9a677" roughness={0.6} />
        </mesh>
        <pointLight position={[0, 2.5, 1]} color="#9dff9d" intensity={3} distance={6} decay={2} />
      </group>
      <Dealer position={[0, 0, -0.9]} outfit={1} seed={4} />
      <Sign text="LOMBARD „CZĘŚCI ZAMIENNE”" color="#7cff4d" y={3.2} z={-1.5} w={5.5} />
    </group>
  );
}

export function LoanShark() {
  const sign = useMemo(() => textTexture("POŻYCZKI 0%*", { color: "#111", bg: "#c9a46a", font: "bold 80px Comic Sans MS, cursive", glow: "transparent" }), []);
  const lamp = useRef<THREE.PointLight>(null);
  useFrame(({ clock }) => {
    if (lamp.current) lamp.current.intensity = 3 + Math.sin(clock.elapsedTime * 9) * (Math.random() > 0.9 ? 2 : 0.5);
  });
  return (
    <group>
      <Avatar avatar={{ skin: 1, hair: 1, hairColor: 0, outfit: 3, hat: 3, glasses: 2, beard: 3, chain: true }} limbs={{ leftArm: true, rightArm: true, leftLeg: true, rightLeg: true, kidney: true, soul: false, teeth: 3, dignity: 0 }} />
      {/* bodyguard */}
      <group position={[1.3, 0, -0.4]} scale={1.2}>
        <Avatar avatar={{ skin: 3, hair: 0, hairColor: 0, outfit: 3, hat: 0, glasses: 2, beard: 0, chain: false }} />
      </group>
      <mesh position={[-1.2, 0.8, 0]} rotation={[0, 0.3, 0]}>
        <planeGeometry args={[1.4, 0.4]} />
        <meshStandardMaterial map={sign} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[-1.2, 0.3, 0]}>
        <boxGeometry args={[0.05, 0.6, 0.05]} />
        {wood}
      </mesh>
      {/* briefcase */}
      <mesh position={[0.6, 0.2, 0.5]} castShadow>
        <boxGeometry args={[0.5, 0.4, 0.15]} />
        <meshStandardMaterial color="#111" roughness={0.3} />
      </mesh>
      {/* lamp */}
      <mesh position={[0, 3.2, 0]}>
        <coneGeometry args={[0.35, 0.3, 16, 1, true]} />
        <meshStandardMaterial color="#222" side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, 3.1, 0]}>
        <sphereGeometry args={[0.08, 8, 8]} />
        <meshStandardMaterial color="#ff2b2b" emissive="#ff2b2b" emissiveIntensity={3} />
      </mesh>
      <pointLight ref={lamp} position={[0, 3, 0]} color="#ff2b2b" intensity={3} distance={7} decay={2} />
    </group>
  );
}

export function StationMesh({ station }: { station: Station }) {
  const seed = parseInt(station.id.replace(/\D/g, "") || "0");
  switch (station.type) {
    case "slots":
      return <SlotMachine seed={seed} />;
    case "blackjack":
      return <BlackjackTable />;
    case "roulette":
      return <RouletteTable />;
    case "dice":
      return <DiceTable />;
    case "poker":
      return <PokerMachine />;
    case "wheel":
      return <WheelOfFortune />;
    case "bar":
      return <Bar />;
    case "shop":
      return <Shop />;
    case "pawn":
      return <PawnShop />;
    case "loan":
      return <LoanShark />;
  }
}

/** Collision radius + interaction radius per station type */
export const STATION_RADIUS: Record<Station["type"], { coll: number; interact: number }> = {
  slots: { coll: 0.8, interact: 2.0 },
  blackjack: { coll: 2.0, interact: 3.2 },
  roulette: { coll: 2.0, interact: 3.4 },
  dice: { coll: 1.7, interact: 3.0 },
  poker: { coll: 0.9, interact: 2.2 },
  wheel: { coll: 1.0, interact: 2.8 },
  bar: { coll: 1.4, interact: 3.6 },
  shop: { coll: 1.4, interact: 3.0 },
  pawn: { coll: 1.4, interact: 3.0 },
  loan: { coll: 0.8, interact: 2.4 },
};
