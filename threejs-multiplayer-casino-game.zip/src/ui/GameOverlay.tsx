import { useEffect } from "react";
import { STATIONS, type PlayerId } from "../game/data";
import { useGame } from "../game/store";
import { useAnyInput } from "../game/input";
import { bodies } from "../game/world";
import { sfx } from "../game/audio";
import { Slots } from "./games/Slots";
import { Blackjack } from "./games/Blackjack";
import { Roulette } from "./games/Roulette";
import { Dice } from "./games/Dice";
import { Wheel } from "./games/Wheel";
import { Poker } from "./games/Poker";
import { BarGame, LoanGame, PawnGame, ShopGame } from "./games/Services";

function MiniGame({ pid, stationId }: { pid: PlayerId; stationId: string }) {
  const setActivity = useGame((s) => s.setActivity);
  const station = STATIONS.find((s) => s.id === stationId)!;
  const close = () => setActivity(pid, null);
  const props = { pid, onClose: close };
  switch (station.type) {
    case "slots":
      return <Slots {...props} />;
    case "blackjack":
      return <Blackjack {...props} />;
    case "roulette":
      return <Roulette {...props} />;
    case "dice":
      return <Dice {...props} />;
    case "wheel":
      return <Wheel {...props} />;
    case "poker":
      return <Poker {...props} />;
    case "bar":
      return <BarGame {...props} />;
    case "shop":
      return <ShopGame {...props} />;
    case "pawn":
      return <PawnGame {...props} />;
    case "loan":
      return <LoanGame {...props} />;
  }
}

export function GameOverlay() {
  const players = useGame((s) => s.players);
  const setActivity = useGame((s) => s.setActivity);
  const tick = useGame((s) => s.tick);

  // interaction: press action near a station
  useAnyInput((pid, action) => {
    const p = useGame.getState().players[pid];
    if (!p.joined || p.activity !== null) return;
    if (action === "action" && bodies[pid].near) {
      sfx.click();
      setActivity(pid, bodies[pid].near);
    }
  });

  useEffect(() => {
    const iv = setInterval(() => tick(0.1), 100);
    return () => clearInterval(iv);
  }, [tick]);

  const active = players.filter((p) => p.joined && p.activity);
  if (!active.length) return null;
  const n = active.length;
  const layout = n === 1 ? "grid-cols-1 max-w-3xl" : n === 2 ? "grid-cols-2 max-w-6xl" : "grid-cols-2 grid-rows-2 max-w-7xl";
  const h = n <= 2 ? "h-[62vh]" : "h-[84vh]";
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none" style={{ paddingTop: 110, paddingBottom: 120 }}>
      <div className={`grid gap-3 w-full ${layout} ${h} px-4`}>
        {active.map((p) => (
          <div key={p.id} className="min-h-0 panel-in">
            <MiniGame pid={p.id} stationId={p.activity!} />
          </div>
        ))}
      </div>
    </div>
  );
}
