import { CASINOS, DAY_LENGTH, KEYMAPS, OUTFITS, PLAYER_COLORS, STATIONS, fmt } from "../game/data";
import { useGame } from "../game/store";
import { Key, keyName } from "./common";

function clock(timeLeft: number) {
  const elapsed = DAY_LENGTH - timeLeft;
  const mins = 12 * 60 * (elapsed / DAY_LENGTH); // 12:00 -> 00:00
  const h = (12 + Math.floor(mins / 60)) % 24;
  const m = Math.floor(mins % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function HUD() {
  const s = useGame();
  const casino = CASINOS[s.tier];
  const target = s.endless ? casino.target * Math.pow(2, s.day - 5) : casino.target;
  const progress = Math.min(1, s.wallet / target);
  const urgent = s.timeLeft < 45;

  return (
    <div className="absolute inset-0 pointer-events-none select-none">
      {/* TOP BAR */}
      <div className="absolute top-0 left-0 right-0 flex items-start justify-between p-3 gap-3">
        <div className="rounded-2xl px-4 py-2 bg-black/60 backdrop-blur border border-white/10 shadow-xl">
          <div className="text-[10px] uppercase tracking-[0.3em] text-white/50">Dzień {s.day}{s.endless && " · TRYB BOGÓW"}</div>
          <div className="font-black text-lg leading-tight" style={{ color: casino.accent, fontFamily: "Impact, 'Arial Black', sans-serif", textShadow: `0 0 12px ${casino.accent}` }}>
            {casino.name}
          </div>
          <div className="text-[11px] text-white/50 italic">{casino.subtitle}</div>
        </div>

        <div className="flex flex-col items-center gap-1">
          <div className="rounded-2xl px-6 py-2 bg-black/70 backdrop-blur border-2 shadow-xl text-center" style={{ borderColor: progress >= 1 ? "#7cff4d" : "#d4a017" }}>
            <div className="text-[10px] uppercase tracking-[0.3em] text-white/50">Wspólny portfel</div>
            <div className={`font-black text-3xl ${progress >= 1 ? "text-green-300" : "text-yellow-300"}`} style={{ fontFamily: "Impact, 'Arial Black', sans-serif", textShadow: "0 0 16px #ffd84d88" }}>
              {fmt(s.wallet)}
            </div>
            <div className="w-64 h-2 rounded-full bg-white/10 overflow-hidden mt-1">
              <div className="h-full rounded-full transition-all duration-500" style={{ width: `${progress * 100}%`, background: progress >= 1 ? "linear-gradient(90deg,#7cff4d,#2ecc71)" : "linear-gradient(90deg,#d4a017,#ffd84d)" }} />
            </div>
            <div className="text-[11px] text-white/60 mt-0.5">
              Cel: <span className="text-white font-bold">{fmt(target)}</span> {progress >= 1 ? "✅ OSIĄGNIĘTY — zarabiajcie dalej!" : `(brakuje ${fmt(target - s.wallet)})`}
            </div>
          </div>
          <div className="flex gap-2">
            {s.debt > 0 && <div className="rounded-full px-3 py-0.5 bg-red-700/90 text-white text-xs font-black animate-pulse">😈 DŁUG U ZENKA: {fmt(s.debt)}</div>}
            {s.prestige > 0 && <div className="rounded-full px-3 py-0.5 bg-purple-700/80 text-white text-xs font-bold">✨ Prestiż {s.prestige} (+{s.prestige}% wygranych)</div>}
            {s.jackpotTimer > 0 && <div className="rounded-full px-3 py-0.5 bg-yellow-400 text-black text-xs font-black animate-bounce">🔥 GODZINA SZCZĘŚCIA ×2 ({Math.ceil(s.jackpotTimer)}s)</div>}
          </div>
        </div>

        <div className={`rounded-2xl px-4 py-2 bg-black/60 backdrop-blur border shadow-xl text-right ${urgent ? "border-red-500 animate-pulse" : "border-white/10"}`}>
          <div className="text-[10px] uppercase tracking-[0.3em] text-white/50">Do zamknięcia</div>
          <div className={`font-black text-3xl tabular-nums ${urgent ? "text-red-400" : "text-white"}`} style={{ fontFamily: "Impact, 'Arial Black', sans-serif" }}>
            {clock(Math.max(0, s.timeLeft))}
          </div>
          <div className="text-[11px] text-white/50">{Math.ceil(Math.max(0, s.timeLeft))}s · północ = koniec dnia</div>
        </div>
      </div>

      {/* TOASTS */}
      <div className="absolute right-3 top-32 w-80 flex flex-col gap-2">
        {s.toasts.map((t) => (
          <div
            key={t.id}
            className={`toast-in rounded-xl px-3 py-2 text-sm font-semibold shadow-xl border backdrop-blur ${
              t.kind === "good" ? "bg-green-900/80 border-green-400/40 text-green-100" : t.kind === "bad" ? "bg-red-900/80 border-red-400/40 text-red-100" : t.kind === "epic" ? "bg-gradient-to-r from-yellow-600/90 to-pink-600/90 border-yellow-300/60 text-white" : "bg-slate-900/80 border-white/20 text-white"
            }`}
            style={t.pid !== undefined ? { borderLeft: `5px solid ${PLAYER_COLORS[t.pid]}` } : undefined}
          >
            {t.text}
          </div>
        ))}
      </div>

      {/* PLAYER CARDS */}
      <div className="absolute bottom-0 left-0 right-0 p-3 flex justify-center gap-3">
        {s.players.filter((p) => p.joined).map((p) => {
          const km = KEYMAPS[p.id];
          const net = p.stats.won - p.stats.lost;
          const missing = [!p.limbs.leftArm && "🦾", !p.limbs.rightArm && "🦾", !p.limbs.leftLeg && "🦿", !p.limbs.rightLeg && "🦿", !p.limbs.kidney && "🫘", !p.limbs.soul && "👻"].filter(Boolean);
          const station = p.activity ? STATIONS.find((st) => st.id === p.activity) : null;
          return (
            <div key={p.id} className="w-64 rounded-2xl bg-black/65 backdrop-blur border shadow-xl overflow-hidden" style={{ borderColor: PLAYER_COLORS[p.id] + "99" }}>
              <div className="flex items-center justify-between px-3 py-1" style={{ background: `linear-gradient(90deg, ${PLAYER_COLORS[p.id]}55, transparent)` }}>
                <div className="font-black text-white truncate">
                  <span className="text-[10px] mr-1 opacity-60">P{p.id + 1}</span>
                  {p.name}
                </div>
                <div className={`text-xs font-black ${net >= 0 ? "text-green-300" : "text-red-300"}`}>{net >= 0 ? "+" : ""}{fmt(net)}</div>
              </div>
              <div className="px-3 py-1.5 text-[11px] text-white/70 flex flex-col gap-0.5">
                <div className="flex justify-between">
                  <span>{OUTFITS[p.avatar.outfit].name}</span>
                  <span>
                    {p.luck > 0 && <span className="text-green-300">🍀+{Math.round(p.luck * 100)}% </span>}
                    {p.drunk > 0.3 && <span>{"🍺".repeat(Math.min(3, Math.ceil(p.drunk)))} </span>}
                    {p.shoeless && "🦶"}
                    {missing.join("")}
                    {p.limbs.teeth > 0 && <span className="text-yellow-300"> 🦷{p.limbs.teeth}</span>}
                  </span>
                </div>
                <div className="truncate" style={{ color: station ? PLAYER_COLORS[p.id] : undefined }}>
                  {station ? `▶ ${station.label}` : "🚶 Chodzi po kasynie"}
                </div>
                <div className="text-white/40">
                  <Key>{keyName(km.up)}</Key>
                  <Key>{keyName(km.left)}</Key>
                  <Key>{keyName(km.down)}</Key>
                  <Key>{keyName(km.right)}</Key> ruch · <Key>{keyName(km.action)}</Key> akcja · <Key>{keyName(km.cancel)}</Key> wyjdź
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
