import { Suspense, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { BEARDS, HAIR_COLORS, HAIR_STYLES, HATS, KEYMAPS, NAME_SUGGESTIONS, PLAYER_COLORS, SKIN_COLORS, type PlayerId } from "../game/data";
import { useGame } from "../game/store";
import { useAnyInput } from "../game/input";
import { sfx } from "../game/audio";
import { Avatar } from "../three/Avatar";
import { Key, keyName } from "./common";
import { resetBodies } from "../game/world";

function Spin({ children }: { children: React.ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (ref.current) ref.current.rotation.y = Math.sin(clock.elapsedTime * 0.8) * 0.6;
  });
  return <group ref={ref}>{children}</group>;
}

const ROWS = ["Imię", "Skóra", "Fryzura", "Kolor włosów", "Zarost", "Czapka", "GOTOWY"];
const FREE_HATS = [0, 2];

export function Lobby() {
  const players = useGame((s) => s.players);
  const { join, leave, setAvatar, setName, startGame } = useGame();
  const [cursor, setCursor] = useState([0, 0, 0, 0]);
  const [ready, setReady] = useState([false, false, false, false]);
  const joined = players.filter((p) => p.joined);
  const allReady = joined.length > 0 && joined.every((p) => ready[p.id]);

  const cycle = (pid: PlayerId, row: number, dir: number) => {
    const p = players[pid];
    const a = p.avatar;
    const wrap = (v: number, n: number) => (v + dir + n) % n;
    sfx.move();
    switch (row) {
      case 0: {
        const i = NAME_SUGGESTIONS.indexOf(p.name);
        setName(pid, NAME_SUGGESTIONS[wrap(i < 0 ? 0 : i, NAME_SUGGESTIONS.length)]);
        break;
      }
      case 1:
        setAvatar(pid, { skin: wrap(a.skin, SKIN_COLORS.length) });
        break;
      case 2:
        setAvatar(pid, { hair: wrap(a.hair, HAIR_STYLES.length) });
        break;
      case 3:
        setAvatar(pid, { hairColor: wrap(a.hairColor, HAIR_COLORS.length) });
        break;
      case 4:
        setAvatar(pid, { beard: wrap(a.beard, BEARDS.length) });
        break;
      case 5: {
        const i = FREE_HATS.indexOf(a.hat);
        setAvatar(pid, { hat: FREE_HATS[wrap(i < 0 ? 0 : i, FREE_HATS.length)] });
        break;
      }
    }
  };

  useAnyInput((pid, action) => {
    const p = players[pid];
    if (!p.joined) {
      if (action === "action") {
        join(pid);
        sfx.coin();
      }
      return;
    }
    if (action === "cancel") {
      if (ready[pid]) setReady((r) => r.map((v, i) => (i === pid ? false : v)));
      else leave(pid);
      sfx.back();
      return;
    }
    if (ready[pid]) {
      if (action === "action" && allReady) {
        resetBodies();
        startGame();
      }
      return;
    }
    const row = cursor[pid];
    if (action === "up") setCursor((c) => c.map((v, i) => (i === pid ? (v + ROWS.length - 1) % ROWS.length : v)));
    else if (action === "down") setCursor((c) => c.map((v, i) => (i === pid ? (v + 1) % ROWS.length : v)));
    else if (action === "left") cycle(pid, row, -1);
    else if (action === "right") cycle(pid, row, 1);
    else if (action === "action") {
      if (row === ROWS.length - 1) {
        setReady((r) => r.map((v, i) => (i === pid ? true : v)));
        sfx.register();
      } else cycle(pid, row, 1);
    }
    if (action === "up" || action === "down") sfx.move();
  });

  return (
    <div className="absolute inset-0 bg-[#0a0608] text-white select-none overflow-hidden">
      <div className="absolute inset-0 opacity-30" style={{ background: "radial-gradient(ellipse at 50% 0%, #8a1030 0%, transparent 60%), radial-gradient(ellipse at 50% 100%, #1a2a6a 0%, transparent 60%)" }} />
      <div className="relative h-full flex flex-col p-4 gap-3">
        <div className="text-center">
          <h1 className="text-4xl font-black text-yellow-300" style={{ fontFamily: "Impact, 'Arial Black', sans-serif", letterSpacing: 2 }}>
            PRZED WEJŚCIEM — KIM JESTEŚCIE?
          </h1>
          <p className="text-white/60 text-sm">Każdy gracz dołącza swoim klawiszem akcji. Dostosuj łachmany i oznacz gotowość. Lepsze ciuchy kupicie później (jeśli przeżyjecie).</p>
        </div>
        <div className="flex-1 grid grid-cols-4 gap-3 min-h-0">
          {players.map((p) => {
            const km = KEYMAPS[p.id];
            const color = PLAYER_COLORS[p.id];
            const vals = [p.name, SKIN_COLORS[p.avatar.skin], HAIR_STYLES[p.avatar.hair], HAIR_COLORS[p.avatar.hairColor], BEARDS[p.avatar.beard], HATS[p.avatar.hat], ready[p.id] ? "✅ GOTOWY" : "Zatwierdź"];
            return (
              <div key={p.id} className="rounded-2xl border-2 flex flex-col overflow-hidden bg-black/50 backdrop-blur" style={{ borderColor: p.joined ? color : "#333", boxShadow: p.joined ? `0 0 30px ${color}44` : undefined }}>
                <div className="px-3 py-2 font-black flex justify-between items-center" style={{ background: `linear-gradient(90deg, ${color}44, transparent)` }}>
                  <span style={{ color }}>GRACZ {p.id + 1}</span>
                  <span className="text-[10px] text-white/50">{km.label}</span>
                </div>
                {!p.joined ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-4 gap-3">
                    <div className="text-5xl opacity-40">🧍</div>
                    <div className="text-white/70">
                      Naciśnij <Key>{keyName(km.action)}</Key>
                      <br />
                      aby dołączyć
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="h-[44%] relative">
                      <Canvas camera={{ position: [0, 1.4, 3.2], fov: 35 }} dpr={[1, 1.5]} gl={{ toneMapping: THREE.ACESFilmicToneMapping }}>
                        <ambientLight intensity={0.6} />
                        <directionalLight position={[2, 4, 3]} intensity={2} />
                        <pointLight position={[-2, 2, 2]} intensity={6} color={color} />
                        <Suspense fallback={null}>
                          <Spin>
                            <group position={[0, -0.95, 0]}>
                              <Avatar avatar={p.avatar} />
                            </group>
                          </Spin>
                        </Suspense>
                        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.95, 0]}>
                          <circleGeometry args={[0.9, 32]} />
                          <meshStandardMaterial color="#222" />
                        </mesh>
                      </Canvas>
                    </div>
                    <div className="flex-1 p-2 flex flex-col gap-1 text-sm">
                      {ROWS.map((r, i) => {
                        const sel = cursor[p.id] === i && !ready[p.id];
                        const isSwatch = i === 1 || i === 3;
                        return (
                          <div key={r} className={`flex justify-between items-center rounded-lg px-2 py-1 ${sel ? "bg-yellow-400 text-black" : i === ROWS.length - 1 ? (ready[p.id] ? "bg-green-600 text-white font-black" : "bg-white/10") : "bg-white/5"}`}>
                            <span className="font-bold text-xs">{r}</span>
                            <span className="flex items-center gap-1 font-bold">
                              {sel && i < ROWS.length - 1 && "◀ "}
                              {isSwatch ? <span className="inline-block w-5 h-5 rounded-full border border-white/40" style={{ background: vals[i] }} /> : vals[i]}
                              {sel && i < ROWS.length - 1 && " ▶"}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
        <div className="text-center h-12 flex items-center justify-center">
          {allReady ? (
            <div className="text-2xl font-black text-green-300 animate-pulse">Wszyscy gotowi! Dowolny gracz: naciśnij akcję, by WEJŚĆ DO KASYNA 🎰</div>
          ) : joined.length ? (
            <div className="text-white/50">Czekamy na gotowość… ({joined.filter((p) => ready[p.id]).length}/{joined.length}) · klawisz „wyjdź” cofa gotowość / opuszcza lobby</div>
          ) : (
            <div className="text-white/50">Potrzebny co najmniej 1 gracz. Najlepiej 4 — nędza lubi towarzystwo.</div>
          )}
        </div>
      </div>
    </div>
  );
}
