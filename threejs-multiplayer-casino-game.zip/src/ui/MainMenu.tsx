import { useEffect, useState } from "react";
import menuBg from "../assets/menu_bg.jpg";
import { useGame } from "../game/store";
import { useAnyInput } from "../game/input";
import { sfx, startMusic } from "../game/audio";
import { Key } from "./common";

export function MainMenu() {
  const setScreen = useGame((s) => s.setScreen);
  const [blink, setBlink] = useState(true);
  useEffect(() => {
    const iv = setInterval(() => setBlink((b) => !b), 600);
    return () => clearInterval(iv);
  }, []);
  useAnyInput((_pid, action) => {
    if (action === "action") {
      sfx.fanfare();
      startMusic(0);
      setScreen("lobby");
    }
  });
  return (
    <div className="absolute inset-0 overflow-hidden bg-black select-none" onClick={() => { sfx.fanfare(); startMusic(0); setScreen("lobby"); }}>
      <img src={menuBg} alt="" className="absolute inset-0 w-full h-full object-cover opacity-80 menu-zoom" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/60" />
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
        <div className="text-sm md:text-base tracking-[0.6em] text-yellow-200/80 uppercase mb-2">Rodzinna tragikomedia hazardowa</div>
        <h1 className="title-glow text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-yellow-400 to-amber-700 leading-none" style={{ fontFamily: "Impact, 'Arial Black', sans-serif", letterSpacing: 2 }}>
          BEZDOMNI
        </h1>
        <h2 className="text-4xl md:text-6xl font-black text-white mt-1 drop-shadow-[0_0_25px_#ff2bd6]" style={{ fontFamily: "Impact, 'Arial Black', sans-serif" }}>
          W KASYNIE
        </h2>
        <p className="mt-6 max-w-2xl text-white/80 text-base md:text-lg">
          Czterech przyjaciół. Jedna skarpeta ze 120 zł. Pięć dni, żeby z dziury pod mostem dostać się na Olimp hazardu. Wspólny portfel, wspólne długi… i lombard, który skupuje <span className="text-red-300 font-bold">dosłownie wszystko</span>.
        </p>
        <div className={`mt-10 text-2xl font-black text-yellow-300 transition-opacity ${blink ? "opacity-100" : "opacity-30"}`}>
          Naciśnij <Key>E</Key> <Key>Enter</Key> <Key>O</Key> lub <Key>Y</Key> aby wejść
        </div>
        <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs text-white/70">
          {[
            ["GRACZ 1", "WASD · E · Q", "#ff4d6d"],
            ["GRACZ 2", "Strzałki · Enter · Shift", "#4dd2ff"],
            ["GRACZ 3", "IJKL · O · U", "#7cff4d"],
            ["GRACZ 4", "TFGH · Y · R", "#ffd84d"],
          ].map(([n, k, c]) => (
            <div key={n} className="rounded-xl px-4 py-2 bg-black/60 border" style={{ borderColor: c }}>
              <div className="font-black" style={{ color: c }}>
                {n}
              </div>
              <div>{k}</div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-[11px] text-white/40">Lokalny multiplayer do 4 osób na jednej klawiaturze · Three.js · Dźwięk włącza się po pierwszym naciśnięciu klawisza</div>
      </div>
    </div>
  );
}
