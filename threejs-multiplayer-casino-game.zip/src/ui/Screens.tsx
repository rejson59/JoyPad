import { CASINOS, PLAYER_COLORS, fmt } from "../game/data";
import { useGame } from "../game/store";
import { useAnyInput } from "../game/input";
import { sfx, stopMusic } from "../game/audio";
import { Key } from "./common";
import { resetBodies } from "../game/world";

const ROASTS = [
  "przegrał więcej niż zarobił. Klasyka.",
  "powinien zostać przy zbieraniu puszek.",
  "ma „system”. System nie działa.",
  "twierdzi, że to była rozgrzewka.",
];
const PRAISES = ["— legenda tej nocy!", "— maszynka do pieniędzy!", "— kasyno chce go zbanować.", "— Grażyna jest pod wrażeniem."];

export function DaySummary() {
  const s = useGame();
  const r = s.lastResult!;
  const casino = CASINOS[s.tier];
  const next = r.success && s.tier < CASINOS.length - 1 ? CASINOS[s.tier + 1] : null;
  useAnyInput((_p, a) => {
    if (a === "action") {
      sfx.click();
      resetBodies();
      s.nextDay();
    }
  });
  const joined = s.players.filter((p) => p.joined);
  return (
    <div className="absolute inset-0 bg-black/90 text-white flex items-center justify-center select-none overflow-auto">
      <div className="absolute inset-0 opacity-40" style={{ background: r.success ? "radial-gradient(ellipse at center, #2a6a1a, transparent 70%)" : "radial-gradient(ellipse at center, #6a1a1a, transparent 70%)" }} />
      <div className="relative max-w-4xl w-full p-6 flex flex-col gap-4">
        <div className="text-center">
          <div className="text-xs tracking-[0.5em] text-white/50 uppercase">Koniec dnia {s.day} · {casino.name}</div>
          <h1 className={`text-5xl md:text-6xl font-black mt-1 ${r.success ? "text-green-300" : "text-red-400"}`} style={{ fontFamily: "Impact, 'Arial Black', sans-serif" }}>
            {r.success ? "CEL OSIĄGNIĘTY!" : "ZA MAŁO KASY…"}
          </h1>
          <div className="text-xl mt-2">
            Portfel: <span className="font-black text-yellow-300">{fmt(r.wallet)}</span> / cel {fmt(r.target)} · bilans dnia{" "}
            <span className={r.earned >= 0 ? "text-green-300 font-bold" : "text-red-300 font-bold"}>
              {r.earned >= 0 ? "+" : ""}
              {fmt(r.earned)}
            </span>
          </div>
        </div>

        {next && (
          <div className="rounded-2xl p-4 border-2 text-center" style={{ borderColor: next.accent, background: next.accent + "15" }}>
            <div className="text-xs uppercase tracking-widest text-white/50">Awansujecie do</div>
            <div className="text-3xl font-black" style={{ color: next.accent, fontFamily: "Impact, sans-serif" }}>
              {next.name}
            </div>
            <div className="text-white/60 italic">{next.subtitle}</div>
            <div className="mt-1 text-sm">
              Nowy cel: <b>{fmt(next.target)}</b> · zakłady {fmt(next.minBet)} – {fmt(next.maxBet)}
            </div>
          </div>
        )}
        {!r.success && (
          <div className="rounded-2xl p-4 border-2 border-red-500/50 bg-red-900/30 text-center">
            <div className="text-xs uppercase tracking-widest text-red-200/70">Kara za porażkę</div>
            <div className="text-lg font-bold">{r.penalty}</div>
            <div className="text-sm text-white/60 mt-1">Zostajecie w {casino.name} na kolejny dzień. Spróbujcie jeszcze raz!</div>
          </div>
        )}
        {r.events.length > 0 && (
          <div className="rounded-2xl p-3 border border-red-400/40 bg-black/50">
            <div className="text-xs uppercase tracking-widest text-red-300 mb-1">Wizyta Zenka o północy</div>
            {r.events.map((e, i) => (
              <div key={i} className="text-sm">
                {e}
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {joined.map((p) => {
            const net = p.stats.won - p.stats.lost;
            const isMvp = r.mvp === p.id && joined.length > 1;
            const isLoser = r.loser === p.id;
            return (
              <div key={p.id} className="rounded-xl p-3 bg-black/60 border" style={{ borderColor: PLAYER_COLORS[p.id] }}>
                <div className="font-black" style={{ color: PLAYER_COLORS[p.id] }}>
                  {p.name} {isMvp && "👑"} {isLoser && "🤡"}
                </div>
                <div className={`text-lg font-black ${net >= 0 ? "text-green-300" : "text-red-300"}`}>
                  {net >= 0 ? "+" : ""}
                  {fmt(net)}
                </div>
                <div className="text-[11px] text-white/60">
                  Wygrane {fmt(p.stats.won)} · Przegrane {fmt(p.stats.lost)}
                  <br />
                  Największa wygrana: {fmt(p.stats.biggestWin)}
                </div>
                {isMvp && <div className="text-[11px] text-yellow-300 mt-1">MVP {PRAISES[p.id % PRAISES.length]}</div>}
                {isLoser && <div className="text-[11px] text-red-300 mt-1">{p.name} {ROASTS[p.id % ROASTS.length]}</div>}
              </div>
            );
          })}
        </div>
        <div className="text-center text-xl font-black text-yellow-300 animate-pulse">
          Naciśnij <Key>akcję</Key> aby {r.success && s.tier === CASINOS.length - 1 ? "zobaczyć finał" : "iść spać (na ławce)"}
        </div>
      </div>
    </div>
  );
}

export function GameOver() {
  const s = useGame();
  useAnyInput((_p, a) => {
    if (a === "action") {
      stopMusic();
      s.restart();
    }
  });
  return (
    <div className="absolute inset-0 bg-black text-white flex items-center justify-center text-center select-none">
      <div className="max-w-2xl p-8">
        <div className="text-8xl mb-4">⚰️</div>
        <h1 className="text-6xl font-black text-red-500" style={{ fontFamily: "Impact, sans-serif" }}>
          KONIEC GRY
        </h1>
        <p className="text-xl mt-4 text-white/80">{s.gameOverReason}</p>
        <p className="mt-2 text-white/50">Dotarliście do dnia {s.day} · łącznie zarobione: {fmt(s.totalEarned)}</p>
        <div className="mt-8 text-yellow-300 font-black text-xl animate-pulse">
          Naciśnij <Key>akcję</Key>, by spróbować jeszcze raz
        </div>
      </div>
    </div>
  );
}

export function Victory() {
  const s = useGame();
  useAnyInput((_p, a) => {
    if (a === "action") {
      sfx.fanfare();
      useGame.setState({ screen: "game", timeLeft: 300, dayStart: s.wallet, dayEvents: [], toasts: [] });
      setTimeout(() => s.toast("TRYB BOGÓW: cel podwaja się każdego dnia. Jak długo przetrwacie?", "epic"), 500);
    } else if (a === "cancel") {
      stopMusic();
      s.restart();
    }
  });
  return (
    <div className="absolute inset-0 text-white flex items-center justify-center text-center select-none" style={{ background: "radial-gradient(ellipse at center, #5a4a0a, #0a0806 70%)" }}>
      <div className="max-w-3xl p-8">
        <div className="text-8xl mb-2">👑🏆👑</div>
        <h1 className="title-glow text-6xl md:text-7xl font-black text-yellow-300" style={{ fontFamily: "Impact, sans-serif" }}>
          BOGOWIE HAZARDU
        </h1>
        <p className="text-xl mt-4 text-white/90">
          Od skarpety ze 120 zł do <span className="font-black text-yellow-300">{fmt(s.wallet)}</span> na Olimpie. Pięć dni temu spaliście pod mostem. Dziś most należy do was.
        </p>
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
          {s.players.filter((p) => p.joined).map((p) => {
            const lost = [!p.limbs.leftArm && "lewa ręka", !p.limbs.rightArm && "prawa ręka", !p.limbs.leftLeg && "lewa noga", !p.limbs.rightLeg && "prawa noga", !p.limbs.kidney && "nerka", !p.limbs.soul && "dusza"].filter(Boolean);
            return (
              <div key={p.id} className="rounded-xl p-2 bg-black/50 border" style={{ borderColor: PLAYER_COLORS[p.id] }}>
                <div className="font-black" style={{ color: PLAYER_COLORS[p.id] }}>
                  {p.name}
                </div>
                <div className="text-[11px] text-white/60">{lost.length ? `Stracone po drodze: ${lost.join(", ")}` : "W jednym kawałku. Nudziarz."}</div>
              </div>
            );
          })}
        </div>
        <div className="mt-8 text-yellow-300 font-black text-xl animate-pulse">
          <Key>akcja</Key> — graj dalej w TRYBIE BOGÓW · <Key>wyjdź</Key> — nowa gra
        </div>
      </div>
    </div>
  );
}
