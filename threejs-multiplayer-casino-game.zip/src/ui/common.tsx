import { useCallback, useMemo, useState, type ReactNode } from "react";
import { CASINOS, KEYMAPS, PLAYER_COLORS, type PlayerId, fmt } from "../game/data";
import { useGame } from "../game/store";
import { sfx } from "../game/audio";

export interface GameProps {
  pid: PlayerId;
  onClose: () => void;
}

export function keyName(code: string) {
  return code.replace("Key", "").replace("Arrow", "").replace("ShiftRight", "Shift").replace("Right", "→").replace("Left", "←").replace("Up", "↑").replace("Down", "↓");
}

export function Panel({ pid, title, icon, children, footer }: { pid: PlayerId; title: string; icon: string; children: ReactNode; footer?: ReactNode }) {
  const player = useGame((s) => s.players[pid]);
  const color = PLAYER_COLORS[pid];
  const km = KEYMAPS[pid];
  return (
    <div
      className="relative flex flex-col w-full h-full rounded-2xl overflow-hidden shadow-2xl pointer-events-auto"
      style={{
        background: "linear-gradient(160deg, rgba(20,12,24,0.96), rgba(8,6,12,0.97))",
        border: `2px solid ${color}`,
        boxShadow: `0 0 40px ${color}55, inset 0 0 60px rgba(0,0,0,0.6)`,
      }}
    >
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10" style={{ background: `linear-gradient(90deg, ${color}33, transparent)` }}>
        <div className="flex items-center gap-2">
          <span className="text-2xl">{icon}</span>
          <div>
            <div className="font-black tracking-wider text-lg text-white uppercase" style={{ fontFamily: "Impact, 'Arial Black', sans-serif" }}>
              {title}
            </div>
            <div className="text-xs font-bold" style={{ color }}>
              {player.name}
            </div>
          </div>
        </div>
        <div className="text-[11px] text-white/60 text-right leading-tight">
          <div>
            <Key>{keyName(km.left)}</Key>
            <Key>{keyName(km.right)}</Key> zakład · <Key>{keyName(km.up)}</Key>
            <Key>{keyName(km.down)}</Key> wybór
          </div>
          <div className="mt-0.5">
            <Key>{keyName(km.action)}</Key> OK · <Key>{keyName(km.cancel)}</Key> wyjdź
          </div>
        </div>
      </div>
      <div className="flex-1 min-h-0 p-3 overflow-hidden">{children}</div>
      {footer && <div className="px-4 py-2 border-t border-white/10 text-xs text-white/70">{footer}</div>}
    </div>
  );
}

export function Key({ children }: { children: ReactNode }) {
  return <span className="inline-block px-1.5 py-0.5 mx-0.5 rounded bg-white/15 border border-white/30 text-white font-bold text-[10px] leading-none">{children}</span>;
}

export interface Option {
  label: string;
  desc?: string;
  right?: string;
  disabled?: boolean;
  danger?: boolean;
}

export function OptionList({ options, cursor, compact }: { options: Option[]; cursor: number; compact?: boolean }) {
  return (
    <div className={`flex flex-col ${compact ? "gap-0.5" : "gap-1"}`}>
      {options.map((o, i) => {
        const sel = i === cursor;
        return (
          <div
            key={i}
            className={`flex items-center justify-between rounded-lg ${compact ? "px-2 py-1" : "px-3 py-1.5"} transition-all ${
              sel ? "bg-yellow-400 text-black scale-[1.02] shadow-lg shadow-yellow-400/30" : "bg-white/5 text-white/90"
            } ${o.disabled ? "opacity-40" : ""}`}
          >
            <div className="min-w-0">
              <div className={`font-bold ${compact ? "text-sm" : ""} truncate ${o.danger && !sel ? "text-red-400" : ""}`}>
                {sel ? "▶ " : ""}
                {o.label}
              </div>
              {o.desc && <div className={`text-xs ${sel ? "text-black/70" : "text-white/50"} truncate`}>{o.desc}</div>}
            </div>
            {o.right && <div className={`font-black whitespace-nowrap ml-2 ${sel ? "text-black" : "text-yellow-300"} ${compact ? "text-sm" : ""}`}>{o.right}</div>}
          </div>
        );
      })}
    </div>
  );
}

export function BetBar({ bet, max }: { bet: number; max: number }) {
  const wallet = useGame((s) => s.wallet);
  const ok = bet <= wallet;
  return (
    <div className="flex items-center justify-between rounded-xl px-3 py-2 bg-black/40 border border-yellow-500/30">
      <div className="text-xs text-white/60">
        ZAKŁAD <span className="text-white/40">(max {fmt(max)})</span>
      </div>
      <div className={`font-black text-xl ${ok ? "text-yellow-300" : "text-red-400 line-through"}`}>{fmt(bet)}</div>
      <div className="text-xs text-white/60">
        PORTFEL <span className="text-green-300 font-bold">{fmt(wallet)}</span>
      </div>
    </div>
  );
}

/** Returns bet value + adjust function based on casino min/max */
export function useBet(mult = 1) {
  const tier = useGame((s) => s.tier);
  const c = CASINOS[tier];
  const steps = useMemo(() => {
    const base = c.minBet * mult;
    const arr = [1, 2, 4, 10, 20, 50, 100, 250, 500, 1000, 2500, 5000].map((m) => base * m).filter((v) => v <= c.maxBet);
    if (!arr.includes(c.maxBet)) arr.push(c.maxBet);
    return arr;
  }, [c, mult]);
  const [idx, setIdx] = useState(0);
  const adjust = useCallback(
    (d: number) => {
      setIdx((i) => {
        const n = Math.max(0, Math.min(steps.length - 1, i + d));
        if (n !== i) sfx.chip();
        return n;
      });
    },
    [steps.length]
  );
  return { bet: steps[idx], adjust, max: c.maxBet, min: c.minBet };
}

export function ResultBanner({ text, kind }: { text: string; kind: "win" | "lose" | "neutral" | "big" }) {
  const cls =
    kind === "big"
      ? "from-yellow-300 via-amber-400 to-yellow-300 text-black animate-pulse"
      : kind === "win"
      ? "from-green-500 to-emerald-600 text-white"
      : kind === "lose"
      ? "from-red-700 to-rose-800 text-white"
      : "from-slate-600 to-slate-700 text-white";
  return (
    <div className={`rounded-xl px-3 py-2 text-center font-black text-lg bg-gradient-to-r ${cls} shadow-lg`} style={{ fontFamily: "Impact, 'Arial Black', sans-serif", letterSpacing: 1 }}>
      {text}
    </div>
  );
}

export function PlayingCard({ card, hidden, small }: { card: { r: string; s: string }; hidden?: boolean; small?: boolean }) {
  const red = card.s === "♥" || card.s === "♦";
  const w = small ? "w-10 h-14 text-sm" : "w-14 h-20 text-lg";
  if (hidden)
    return (
      <div className={`${w} rounded-md border-2 border-white/70 shadow-lg`} style={{ background: "repeating-linear-gradient(45deg,#8a1030,#8a1030 4px,#5a0a20 4px,#5a0a20 8px)" }} />
    );
  return (
    <div className={`${w} rounded-md bg-white shadow-lg flex flex-col justify-between p-1 font-bold ${red ? "text-red-600" : "text-slate-900"} card-pop`}>
      <div className="leading-none">
        {card.r}
        <span className="text-xs">{card.s}</span>
      </div>
      <div className={`text-center ${small ? "text-lg" : "text-2xl"} leading-none`}>{card.s}</div>
      <div className="leading-none text-right rotate-180">
        {card.r}
        <span className="text-xs">{card.s}</span>
      </div>
    </div>
  );
}

export const SUITS = ["♠", "♥", "♦", "♣"];
export const RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
export function newDeck(decks = 1) {
  const d: { r: string; s: string }[] = [];
  for (let k = 0; k < decks; k++) for (const s of SUITS) for (const r of RANKS) d.push({ r, s });
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}
