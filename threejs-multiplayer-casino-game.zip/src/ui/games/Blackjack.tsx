import { useRef, useState } from "react";
import { fmt } from "../../game/data";
import { canUseHands, useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { BetBar, OptionList, Panel, PlayingCard, ResultBanner, newDeck, useBet, type GameProps } from "../common";

type Card = { r: string; s: string };
const val = (hand: Card[]) => {
  let t = 0,
    aces = 0;
  for (const c of hand) {
    if (c.r === "A") {
      aces++;
      t += 11;
    } else if (["J", "Q", "K"].includes(c.r)) t += 10;
    else t += parseInt(c.r);
  }
  while (t > 21 && aces > 0) {
    t -= 10;
    aces--;
  }
  return t;
};

export function Blackjack({ pid, onClose }: GameProps) {
  const { bet, adjust, max } = useBet();
  const changeMoney = useGame((s) => s.changeMoney);
  const winMult = useGame((s) => s.winMult);
  const wallet = useGame((s) => s.wallet);
  const player = useGame((s) => s.players[pid]);
  const hands = canUseHands(player);
  const deck = useRef<Card[]>(newDeck(4));
  const [phase, setPhase] = useState<"bet" | "play" | "result">("bet");
  const [ph, setPh] = useState<Card[]>([]);
  const [dh, setDh] = useState<Card[]>([]);
  const [cursor, setCursor] = useState(0);
  const [result, setResult] = useState<{ text: string; kind: "win" | "lose" | "big" | "neutral" } | null>(null);
  const [stake, setStake] = useState(0);
  const busy = useRef(false);

  const draw = () => {
    if (deck.current.length < 20) deck.current = newDeck(4);
    return deck.current.pop()!;
  };

  const deal = () => {
    if (bet > wallet) {
      setResult({ text: "Brak kasy na zakład!", kind: "lose" });
      sfx.lose();
      return;
    }
    changeMoney(-bet, pid, undefined, true);
    setStake(bet);
    const p = [draw(), draw()];
    const d = [draw(), draw()];
    setPh(p);
    setDh(d);
    setResult(null);
    setCursor(0);
    sfx.card();
    if (val(p) === 21) {
      setTimeout(() => finish(p, d, bet, true), 500);
      setPhase("result");
    } else setPhase("play");
  };

  const finish = (p: Card[], d: Card[], st: number, natural = false) => {
    let dealer = [...d];
    const pv = val(p);
    if (pv <= 21 && !natural) while (val(dealer) < 17) dealer.push(draw());
    setDh(dealer);
    const dv = val(dealer);
    let win = 0;
    let text = "";
    let kind: "win" | "lose" | "big" | "neutral" = "lose";
    if (natural) {
      win = st * 2.5;
      text = "BLACKJACK! Płaci 3:2";
      kind = "big";
    } else if (pv > 21) text = "FURA! Przebiłeś 21. Dealer nawet nie mrugnął.";
    else if (dv > 21) {
      win = st * 2;
      text = `Dealer przebił (${dv})! Wygrana!`;
      kind = "win";
    } else if (pv > dv) {
      win = st * 2;
      text = `${pv} vs ${dv} — Wygrywasz!`;
      kind = "win";
    } else if (pv === dv) {
      win = st;
      text = `Remis ${pv}:${dv}. Zakład wraca.`;
      kind = "neutral";
    } else text = `${pv} vs ${dv} — Dealer wygrywa. Uśmiecha się złośliwie.`;
    if (win > 0) {
      const w = Math.round(win * (kind === "neutral" ? 1 : winMult(pid)));
      changeMoney(w, pid, undefined, true);
      text += `  +${fmt(w)}`;
      kind === "big" ? sfx.bigwin() : kind === "win" ? sfx.coins() : sfx.coin();
    } else sfx.lose();
    setResult({ text, kind });
    setPhase("result");
    busy.current = false;
  };

  const hit = () => {
    const p = [...ph, draw()];
    setPh(p);
    sfx.card();
    if (val(p) > 21) {
      setTimeout(() => finish(p, dh, stake), 400);
      setPhase("result");
    }
  };
  const stand = () => {
    setPhase("result");
    setTimeout(() => finish(ph, dh, stake), 400);
  };
  const dbl = () => {
    if (stake > wallet || ph.length !== 2) return;
    changeMoney(-stake, pid, undefined, true);
    const p = [...ph, draw()];
    setPh(p);
    sfx.card();
    setPhase("result");
    setTimeout(() => finish(p, dh, stake * 2), 500);
  };

  const options = [
    { label: "Dobierz (Hit)", desc: "Jeszcze jedną kartę" },
    { label: "Pas (Stand)", desc: "Zostań przy swoim" },
    { label: "Podwój (Double)", desc: `Podwój zakład, jedna karta`, disabled: ph.length !== 2 || stake > wallet },
  ];

  useInput(pid, (a) => {
    if (a === "cancel") {
      if (phase !== "play") {
        sfx.back();
        onClose();
      }
      return;
    }
    if (!hands) return;
    if (phase === "bet" || phase === "result") {
      if (a === "left") adjust(-1);
      else if (a === "right") adjust(1);
      else if (a === "action" && !busy.current) deal();
    } else if (phase === "play") {
      if (a === "up") {
        setCursor((c) => (c + 2) % 3);
        sfx.move();
      } else if (a === "down") {
        setCursor((c) => (c + 1) % 3);
        sfx.move();
      } else if (a === "action") {
        if (cursor === 0) hit();
        else if (cursor === 1) stand();
        else dbl();
      }
    }
  });

  if (!hands)
    return (
      <Panel pid={pid} title="Blackjack" icon="🃏">
        <div className="h-full flex flex-col items-center justify-center text-center gap-3">
          <div className="text-6xl">🙅</div>
          <div className="text-xl font-black text-red-400">Dealer: „Czym chcesz trzymać karty? Zębami?”</div>
          <div className="text-white/60">Bez rąk nie zagrasz w karty. Spróbuj ruletki, kości albo odkup rękę w lombardzie.</div>
        </div>
      </Panel>
    );

  return (
    <Panel pid={pid} title="Blackjack" icon="🃏" footer="Dealer dobiera do 17 · Blackjack płaci 3:2">
      <div className="flex flex-col h-full gap-2">
        <div className="flex-1 min-h-0 rounded-2xl p-3 flex flex-col justify-between" style={{ background: "radial-gradient(ellipse at center, #0f6b35, #063d1d)", border: "6px solid #3a1a0a", boxShadow: "inset 0 0 50px #0006" }}>
          <div>
            <div className="text-[10px] uppercase tracking-widest text-white/60 mb-1">Dealer {dh.length > 0 && phase !== "play" && `· ${val(dh)}`}</div>
            <div className="flex gap-1.5 min-h-[56px]">
              {dh.map((c, i) => (
                <PlayingCard key={i} card={c} hidden={i === 1 && phase === "play"} small />
              ))}
            </div>
          </div>
          <div className="text-center text-white/30 text-xs italic">BLACKJACK PAYS 3 TO 2</div>
          <div>
            <div className="flex gap-1.5 min-h-[56px] items-end">
              {ph.map((c, i) => (
                <PlayingCard key={i} card={c} small />
              ))}
            </div>
            <div className="text-[10px] uppercase tracking-widest text-white/60 mt-1">
              Ty {ph.length > 0 && `· ${val(ph)}`} {stake > 0 && <span className="text-yellow-300">· stawka {fmt(stake)}</span>}
            </div>
          </div>
        </div>
        {phase === "play" ? <OptionList options={options} cursor={cursor} compact /> : result ? <ResultBanner text={result.text} kind={result.kind} /> : <ResultBanner text="Ustaw zakład i naciśnij akcję, by rozdać" kind="neutral" />}
        {phase !== "play" && <BetBar bet={bet} max={max} />}
      </div>
    </Panel>
  );
}
