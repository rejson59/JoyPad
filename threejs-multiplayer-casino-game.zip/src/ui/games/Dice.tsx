import { useRef, useState } from "react";
import { fmt } from "../../game/data";
import { useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { BetBar, OptionList, Panel, ResultBanner, useBet, type GameProps } from "../common";

const BETS = [
  { label: "Poniżej 7", pay: 2.2, test: (a: number, b: number) => a + b < 7 },
  { label: "Dokładnie 7", pay: 5.5, test: (a: number, b: number) => a + b === 7 },
  { label: "Powyżej 7", pay: 2.2, test: (a: number, b: number) => a + b > 7 },
  { label: "Dublet", pay: 5.5, test: (a: number, b: number) => a === b },
  { label: "Dwie szóstki", pay: 32, test: (a: number, b: number) => a === 6 && b === 6 },
  { label: "Wężowe oczy (1+1)", pay: 32, test: (a: number, b: number) => a === 1 && b === 1 },
  { label: "Suma parzysta", pay: 1.9, test: (a: number, b: number) => (a + b) % 2 === 0 },
];

const PIPS: Record<number, [number, number][]> = {
  1: [[50, 50]],
  2: [[25, 25], [75, 75]],
  3: [[25, 25], [50, 50], [75, 75]],
  4: [[25, 25], [75, 25], [25, 75], [75, 75]],
  5: [[25, 25], [75, 25], [50, 50], [25, 75], [75, 75]],
  6: [[25, 25], [75, 25], [25, 50], [75, 50], [25, 75], [75, 75]],
};

function Die({ v, rolling, color }: { v: number; rolling: boolean; color: string }) {
  return (
    <div className={`relative w-20 h-20 rounded-2xl shadow-2xl ${rolling ? "dice-roll" : ""}`} style={{ background: color, boxShadow: "inset -6px -6px 12px #0004, inset 6px 6px 12px #fff6, 0 10px 20px #0008" }}>
      {PIPS[v].map(([x, y], i) => (
        <div key={i} className="absolute w-3.5 h-3.5 rounded-full bg-slate-900 -translate-x-1/2 -translate-y-1/2" style={{ left: `${x}%`, top: `${y}%` }} />
      ))}
    </div>
  );
}

export function Dice({ pid, onClose }: GameProps) {
  const { bet, adjust, max } = useBet();
  const changeMoney = useGame((s) => s.changeMoney);
  const winMult = useGame((s) => s.winMult);
  const wallet = useGame((s) => s.wallet);
  const player = useGame((s) => s.players[pid]);
  const [cursor, setCursor] = useState(0);
  const [d, setD] = useState([3, 4]);
  const [rolling, setRolling] = useState(false);
  const [result, setResult] = useState<{ text: string; kind: "win" | "lose" | "big" | "neutral" } | null>(null);
  const [streak, setStreak] = useState(0);
  const busy = useRef(false);

  const roll = () => {
    if (busy.current) return;
    if (bet > wallet) {
      setResult({ text: "Nie masz czym obstawić!", kind: "lose" });
      sfx.lose();
      return;
    }
    busy.current = true;
    changeMoney(-bet, pid, undefined, true);
    setRolling(true);
    setResult(null);
    sfx.dice();
    const iv = setInterval(() => setD([1 + Math.floor(Math.random() * 6), 1 + Math.floor(Math.random() * 6)]), 80);
    const a = 1 + Math.floor(Math.random() * 6);
    const b = 1 + Math.floor(Math.random() * 6);
    setTimeout(() => {
      clearInterval(iv);
      setD([a, b]);
      setRolling(false);
      const sel = BETS[cursor];
      if (sel.test(a, b)) {
        const w = Math.round(bet * sel.pay * winMult(pid));
        changeMoney(w, pid, undefined, true);
        setStreak((s) => s + 1);
        setResult({ text: `${a} + ${b} = ${a + b}! ${sel.label} — wygrana  +${fmt(w)}`, kind: sel.pay > 10 ? "big" : "win" });
        sel.pay > 10 ? sfx.bigwin() : sfx.coins();
      } else {
        setStreak(0);
        const noHands = !player.limbs.leftArm && !player.limbs.rightArm;
        const l = [`${a} + ${b} = ${a + b}. Pudło.`, `${a + b}. Kości nie kłamią. Niestety.`, noHands ? `Dmuchnąłeś w kości: ${a + b}. Za słabo.` : `${a + b}. Krupier chowa kości do kieszeni.`];
        setResult({ text: l[Math.floor(Math.random() * l.length)], kind: "lose" });
        sfx.lose();
      }
      busy.current = false;
    }, 1100);
  };

  useInput(pid, (a) => {
    if (a === "cancel") {
      if (!busy.current) {
        sfx.back();
        onClose();
      }
      return;
    }
    if (busy.current) return;
    if (a === "up") {
      setCursor((c) => (c + BETS.length - 1) % BETS.length);
      sfx.move();
    } else if (a === "down") {
      setCursor((c) => (c + 1) % BETS.length);
      sfx.move();
    } else if (a === "left") adjust(-1);
    else if (a === "right") adjust(1);
    else if (a === "action") roll();
  });

  return (
    <Panel pid={pid} title="Kości" icon="🎲" footer={streak >= 3 ? `🔥 Seria ${streak}! Krupier się poci.` : "Rzuć kośćmi i módl się do boga hazardu"}>
      <div className="flex h-full gap-3">
        <div className="w-[42%] rounded-2xl flex flex-col items-center justify-center gap-6" style={{ background: "radial-gradient(ellipse at center, #7a1230, #3a0818)", border: "6px solid #3a1a0a", boxShadow: "inset 0 0 40px #0008" }}>
          <div className="flex gap-4">
            <Die v={d[0]} rolling={rolling} color="#fdf6e3" />
            <Die v={d[1]} rolling={rolling} color="#e21b3c" />
          </div>
          <div className="text-5xl font-black text-white/90" style={{ fontFamily: "Impact, sans-serif" }}>
            {rolling ? "?" : d[0] + d[1]}
          </div>
        </div>
        <div className="flex-1 flex flex-col gap-2 min-w-0">
          <div className="flex-1 min-h-0 overflow-hidden">
            <OptionList options={BETS.map((b) => ({ label: b.label, right: `${b.pay}×` }))} cursor={cursor} compact />
          </div>
          {result ? <ResultBanner text={result.text} kind={result.kind} /> : <ResultBanner text={rolling ? "KOŚCI LECĄ…" : "Wybierz zakład i rzuć"} kind="neutral" />}
          <BetBar bet={bet} max={max} />
        </div>
      </div>
    </Panel>
  );
}
