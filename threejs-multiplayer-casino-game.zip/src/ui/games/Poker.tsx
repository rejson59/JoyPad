import { useRef, useState } from "react";
import { fmt } from "../../game/data";
import { canUseHands, useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { BetBar, Panel, PlayingCard, RANKS, ResultBanner, newDeck, useBet, type GameProps } from "../common";

type Card = { r: string; s: string };
const PAYTABLE = [
  ["Poker królewski", 250],
  ["Poker", 50],
  ["Kareta", 25],
  ["Full", 9],
  ["Kolor", 6],
  ["Strit", 4],
  ["Trójka", 3],
  ["Dwie pary", 2],
  ["Para waletów+", 1],
] as const;

function evaluate(h: Card[]): { name: string; mult: number } | null {
  const vals = h.map((c) => RANKS.indexOf(c.r)).sort((a, b) => a - b);
  const suits = h.map((c) => c.s);
  const flush = suits.every((s) => s === suits[0]);
  const uniq = [...new Set(vals)];
  const straight = uniq.length === 5 && (vals[4] - vals[0] === 4 || (vals.join() === "0,1,2,3,12"));
  const counts: Record<number, number> = {};
  vals.forEach((v) => (counts[v] = (counts[v] || 0) + 1));
  const groups = Object.entries(counts).map(([v, c]) => ({ v: +v, c })).sort((a, b) => b.c - a.c || b.v - a.v);
  if (straight && flush && vals[0] === 8) return { name: "Poker królewski", mult: 250 };
  if (straight && flush) return { name: "Poker", mult: 50 };
  if (groups[0].c === 4) return { name: "Kareta", mult: 25 };
  if (groups[0].c === 3 && groups[1].c === 2) return { name: "Full", mult: 9 };
  if (flush) return { name: "Kolor", mult: 6 };
  if (straight) return { name: "Strit", mult: 4 };
  if (groups[0].c === 3) return { name: "Trójka", mult: 3 };
  if (groups[0].c === 2 && groups[1].c === 2) return { name: "Dwie pary", mult: 2 };
  if (groups[0].c === 2 && groups[0].v >= 9) return { name: "Para waletów+", mult: 1 };
  return null;
}

export function Poker({ pid, onClose }: GameProps) {
  const { bet, adjust, max } = useBet();
  const changeMoney = useGame((s) => s.changeMoney);
  const winMult = useGame((s) => s.winMult);
  const wallet = useGame((s) => s.wallet);
  const player = useGame((s) => s.players[pid]);
  const hands = canUseHands(player);
  const deck = useRef<Card[]>(newDeck());
  const [hand, setHand] = useState<Card[]>([]);
  const [held, setHeld] = useState([false, false, false, false, false]);
  const [cursor, setCursor] = useState(0);
  const [phase, setPhase] = useState<"bet" | "hold" | "result">("bet");
  const [stake, setStake] = useState(0);
  const [result, setResult] = useState<{ text: string; kind: "win" | "lose" | "big" | "neutral" } | null>(null);

  const deal = () => {
    if (bet > wallet) {
      setResult({ text: "Brak kasy!", kind: "lose" });
      sfx.lose();
      return;
    }
    changeMoney(-bet, pid, undefined, true);
    setStake(bet);
    deck.current = newDeck();
    setHand(deck.current.splice(0, 5));
    setHeld([false, false, false, false, false]);
    setCursor(0);
    setResult(null);
    setPhase("hold");
    sfx.card();
  };
  const drawCards = () => {
    const nh = hand.map((c, i) => (held[i] ? c : deck.current.pop()!));
    setHand(nh);
    sfx.card();
    const ev = evaluate(nh);
    if (ev) {
      const w = Math.round(stake * (ev.mult + 1) * winMult(pid));
      changeMoney(w, pid, undefined, true);
      setResult({ text: `${ev.name.toUpperCase()}! ${ev.mult}:1  +${fmt(w)}`, kind: ev.mult >= 25 ? "big" : "win" });
      ev.mult >= 25 ? sfx.bigwin() : sfx.coins();
    } else {
      setResult({ text: "Nic. Automat wyświetla smutną buźkę :(", kind: "lose" });
      sfx.lose();
    }
    setPhase("result");
  };

  useInput(pid, (a) => {
    if (a === "cancel") {
      if (phase !== "hold") {
        sfx.back();
        onClose();
      }
      return;
    }
    if (!hands) return;
    if (phase !== "hold") {
      if (a === "left") adjust(-1);
      else if (a === "right") adjust(1);
      else if (a === "action") deal();
    } else {
      if (a === "left") {
        setCursor((c) => (c + 5) % 6);
        sfx.move();
      } else if (a === "right") {
        setCursor((c) => (c + 1) % 6);
        sfx.move();
      } else if (a === "action" || a === "up" || a === "down") {
        if (cursor === 5 || a === "down") drawCards();
        else {
          setHeld((h) => h.map((v, i) => (i === cursor ? !v : v)));
          sfx.chip();
        }
      }
    }
  });

  if (!hands)
    return (
      <Panel pid={pid} title="Video Poker" icon="🂡">
        <div className="h-full flex flex-col items-center justify-center text-center gap-3">
          <div className="text-6xl">🖐️❌</div>
          <div className="text-xl font-black text-red-400">Automat ma przyciski. Ty nie masz rąk.</div>
          <div className="text-white/60">Próbowałeś nosem. Ochrona poprosiła, żebyś przestał.</div>
        </div>
      </Panel>
    );

  return (
    <Panel pid={pid} title="Video Poker" icon="🂡" footer={phase === "hold" ? "←→ wybierz kartę · akcja = zatrzymaj · ↓ lub przycisk DOBIERZ" : "Jacks or Better · ustaw stawkę i rozdaj"}>
      <div className="flex h-full gap-3">
        <div className="flex-1 flex flex-col gap-2 min-w-0">
          <div className="flex-1 rounded-2xl p-3 flex flex-col items-center justify-center gap-3" style={{ background: "linear-gradient(180deg,#061a3a,#02091a)", border: "4px solid #4dd2ff", boxShadow: "inset 0 0 40px #000, 0 0 25px #4dd2ff44" }}>
            <div className="flex gap-2">
              {hand.length === 0
                ? [0, 1, 2, 3, 4].map((i) => <PlayingCard key={i} card={{ r: "", s: "" }} hidden small />)
                : hand.map((c, i) => (
                    <div key={i} className={`flex flex-col items-center gap-1 transition-transform ${phase === "hold" && cursor === i ? "-translate-y-2" : ""}`}>
                      <div className={`rounded-md ${phase === "hold" && cursor === i ? "ring-4 ring-yellow-300" : ""}`}>
                        <PlayingCard card={c} small />
                      </div>
                      <div className={`text-[9px] font-black px-1.5 rounded ${held[i] ? "bg-yellow-300 text-black" : "text-transparent"}`}>HOLD</div>
                    </div>
                  ))}
            </div>
            {phase === "hold" && <div className={`px-4 py-1 rounded-lg font-black text-sm ${cursor === 5 ? "bg-yellow-300 text-black ring-4 ring-yellow-200" : "bg-white/10 text-white"}`}>DOBIERZ ▶</div>}
          </div>
          {result ? <ResultBanner text={result.text} kind={result.kind} /> : <ResultBanner text={phase === "hold" ? "Zatrzymaj karty i dobierz" : "Naciśnij akcję, by rozdać"} kind="neutral" />}
          {phase !== "hold" && <BetBar bet={bet} max={max} />}
        </div>
        <div className="w-[34%] rounded-xl bg-black/40 border border-cyan-400/30 p-2 text-[11px] overflow-hidden">
          <div className="text-cyan-300 font-black mb-1 tracking-widest text-center">WYPŁATY</div>
          {PAYTABLE.map(([n, m]) => (
            <div key={n} className={`flex justify-between px-1 py-0.5 rounded ${result?.text.startsWith(n.toUpperCase()) ? "bg-yellow-300 text-black font-black" : "text-white/80"}`}>
              <span>{n}</span>
              <span className="font-bold">{m}:1</span>
            </div>
          ))}
        </div>
      </div>
    </Panel>
  );
}
