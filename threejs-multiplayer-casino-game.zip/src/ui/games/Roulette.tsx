import { useRef, useState } from "react";
import { fmt } from "../../game/data";
import { useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { BetBar, OptionList, Panel, ResultBanner, useBet, type GameProps } from "../common";

const ORDER = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
const REDS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
const colorOf = (n: number) => (n === 0 ? "#1a9b3a" : REDS.has(n) ? "#c8202a" : "#141414");
const gradient = `conic-gradient(${ORDER.map((n, i) => `${colorOf(n)} ${(i / 37) * 100}% ${((i + 1) / 37) * 100}%`).join(",")})`;

const BETS = [
  { label: "Czerwone", pay: 2, test: (n: number) => n !== 0 && REDS.has(n) },
  { label: "Czarne", pay: 2, test: (n: number) => n !== 0 && !REDS.has(n) },
  { label: "Parzyste", pay: 2, test: (n: number) => n !== 0 && n % 2 === 0 },
  { label: "Nieparzyste", pay: 2, test: (n: number) => n % 2 === 1 },
  { label: "1 – 18", pay: 2, test: (n: number) => n >= 1 && n <= 18 },
  { label: "19 – 36", pay: 2, test: (n: number) => n >= 19 },
  { label: "1. tuzin (1-12)", pay: 3, test: (n: number) => n >= 1 && n <= 12 },
  { label: "2. tuzin (13-24)", pay: 3, test: (n: number) => n >= 13 && n <= 24 },
  { label: "3. tuzin (25-36)", pay: 3, test: (n: number) => n >= 25 },
  { label: "Konkretny numer", pay: 36, test: (_n: number) => false },
];

export function Roulette({ pid, onClose }: GameProps) {
  const { bet, adjust, max } = useBet();
  const changeMoney = useGame((s) => s.changeMoney);
  const winMult = useGame((s) => s.winMult);
  const wallet = useGame((s) => s.wallet);
  const [cursor, setCursor] = useState(0);
  const [num, setNum] = useState(17);
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [last, setLast] = useState<number[]>([]);
  const [result, setResult] = useState<{ text: string; kind: "win" | "lose" | "big" | "neutral" } | null>(null);
  const angleRef = useRef(0);

  const spin = () => {
    if (spinning) return;
    if (bet > wallet) {
      setResult({ text: "Brak kasy! Krupier patrzy z politowaniem.", kind: "lose" });
      sfx.lose();
      return;
    }
    changeMoney(-bet, pid, undefined, true);
    const n = Math.floor(Math.random() * 37);
    const idx = ORDER.indexOf(n);
    const segAngle = 360 / 37;
    const target = 360 * 6 + (360 - (idx * segAngle + segAngle / 2));
    const base = Math.floor(angleRef.current / 360) * 360;
    angleRef.current = base + target;
    setAngle(angleRef.current);
    setSpinning(true);
    setResult(null);
    const ticks = window.setInterval(() => sfx.wheelTick(), 120);
    setTimeout(() => clearInterval(ticks), 3500);
    const sel = BETS[cursor];
    const chosen = num;
    setTimeout(() => {
      const hit = cursor === 9 ? n === chosen : sel.test(n);
      setLast((l) => [n, ...l].slice(0, 10));
      if (hit) {
        const w = Math.round(bet * sel.pay * winMult(pid));
        changeMoney(w, pid, undefined, true);
        setResult({ text: `${n} ${n === 0 ? "ZIELONE" : REDS.has(n) ? "CZERWONE" : "CZARNE"} — Wygrana ${sel.pay}×  +${fmt(w)}`, kind: sel.pay >= 36 ? "big" : "win" });
        sel.pay >= 36 ? sfx.bigwin() : sfx.coins();
      } else {
        const l = [`Wypadło ${n}. Krupier zgarnia żetony z gracją.`, `${n}. Nie tym razem. Kulka cię nie lubi.`, `${n}! Zenek w kącie zaciera ręce.`];
        setResult({ text: l[Math.floor(Math.random() * l.length)], kind: "lose" });
        sfx.lose();
      }
      setSpinning(false);
    }, 4200);
  };

  useInput(pid, (a) => {
    if (a === "cancel") {
      if (!spinning) {
        sfx.back();
        onClose();
      }
      return;
    }
    if (spinning) return;
    if (a === "up") {
      setCursor((c) => (c + BETS.length - 1) % BETS.length);
      sfx.move();
    } else if (a === "down") {
      setCursor((c) => (c + 1) % BETS.length);
      sfx.move();
    } else if (a === "left") {
      if (cursor === 9) setNum((n) => (n + 36) % 37);
      else adjust(-1);
    } else if (a === "right") {
      if (cursor === 9) setNum((n) => (n + 1) % 37);
      else adjust(1);
    } else if (a === "action") spin();
  });

  const options = BETS.map((b, i) => ({ label: i === 9 ? `Numer ${num} ${num === 0 ? "🟢" : REDS.has(num) ? "🔴" : "⚫"}` : b.label, right: `${b.pay}×`, desc: i === 9 ? "←→ zmienia numer" : undefined }));

  return (
    <Panel pid={pid} title="Ruletka" icon="🎡" footer="Europejska ruletka · jedno zero · ↑↓ typ zakładu, ←→ stawka">
      <div className="flex h-full gap-3">
        <div className="flex flex-col items-center justify-between w-[42%]">
          <div className="relative w-full aspect-square max-w-[220px]">
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 z-10 w-0 h-0 border-l-[10px] border-r-[10px] border-t-[18px] border-l-transparent border-r-transparent border-t-yellow-300 drop-shadow" />
            <div className="absolute inset-0 rounded-full border-[6px] border-amber-700 shadow-2xl" style={{ background: gradient, transform: `rotate(${angle}deg)`, transition: spinning ? "transform 4s cubic-bezier(0.15, 0.85, 0.2, 1)" : "none" }}>
              {ORDER.map((n, i) => (
                <div key={i} className="absolute left-1/2 top-1/2 text-[8px] font-bold text-white" style={{ transform: `rotate(${(i / 37) * 360 + 360 / 74}deg) translateY(-${44}%) translateX(-50%)`, transformOrigin: "0 0" }}>
                  {n}
                </div>
              ))}
            </div>
            <div className="absolute inset-[28%] rounded-full bg-gradient-to-br from-amber-300 to-amber-700 border-4 border-amber-900 shadow-inner flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-amber-900" />
            </div>
          </div>
          <div className="flex gap-1 flex-wrap justify-center">
            {last.map((n, i) => (
              <span key={i} className="w-6 h-6 rounded-full text-[10px] font-bold text-white flex items-center justify-center" style={{ background: colorOf(n) }}>
                {n}
              </span>
            ))}
          </div>
        </div>
        <div className="flex-1 flex flex-col gap-2 min-w-0">
          <div className="flex-1 min-h-0 overflow-hidden">
            <OptionList options={options} cursor={cursor} compact />
          </div>
          {result ? <ResultBanner text={result.text} kind={result.kind} /> : <ResultBanner text={spinning ? "KULKA SIĘ TOCZY…" : "Wybierz zakład i zakręć"} kind="neutral" />}
          <BetBar bet={bet} max={max} />
        </div>
      </div>
    </Panel>
  );
}
