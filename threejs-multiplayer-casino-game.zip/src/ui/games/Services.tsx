import { useState } from "react";
import { BODY_PARTS, DRINKS, LOANS, OUTFITS, SHOP_GLASSES, SHOP_HATS, fmt, type Limbs } from "../../game/data";
import { useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { OptionList, Panel, ResultBanner, type GameProps, type Option } from "../common";

function useMenu(len: number, onSelect: (i: number) => void, onClose: () => void, pid: GameProps["pid"]) {
  const [cursor, setCursor] = useState(0);
  useInput(pid, (a) => {
    if (a === "cancel") {
      sfx.back();
      onClose();
    } else if (a === "up" || a === "left") {
      setCursor((c) => (c + len - 1) % len);
      sfx.move();
    } else if (a === "down" || a === "right") {
      setCursor((c) => (c + 1) % len);
      sfx.move();
    } else if (a === "action") onSelect(cursor);
  });
  return cursor;
}

// ─── BAR ───
const GRAZYNA = [
  "Grażyna: „Kochany, ja też kiedyś miałam marzenia. Potem otworzyłam bar.”",
  "Grażyna: „Nie płacz do kieliszka, to rozcieńcza.”",
  "Grażyna: „Mój trzeci mąż też grał w ruletkę. Teraz jest ruletką.”",
  "Grażyna: „Pamiętaj: dom zawsze wygrywa. Ale ty nie masz domu, więc może to działa na odwrót?”",
  "Grażyna: „Masz tu orzeszki. Nie pytaj, skąd.”",
];
export function BarGame({ pid, onClose }: GameProps) {
  const drink = useGame((s) => s.drink);
  const wallet = useGame((s) => s.wallet);
  const player = useGame((s) => s.players[pid]);
  const toast = useGame((s) => s.toast);
  const [msg, setMsg] = useState<{ text: string; kind: "win" | "lose" | "neutral" } | null>(null);
  const options: Option[] = [
    ...DRINKS.map((d) => ({ label: d.name, desc: d.desc, right: fmt(d.price), disabled: wallet < d.price })),
    { label: "Opowiedz Grażynie o swoim życiu", desc: "Darmowa terapia. Mała szansa na litość.", right: "0 zł" },
  ];
  const cursor = useMenu(options.length, (i) => {
    if (i < DRINKS.length) {
      if (drink(pid, i)) setMsg({ text: `Wypiłeś: ${DRINKS[i].name}. Szczęście: +${Math.round(player.luck * 100 + DRINKS[i].luck * 100)}%`, kind: "win" });
      else {
        setMsg({ text: "Grażyna: „Nie ma kasy, nie ma picia.”", kind: "lose" });
        sfx.lose();
      }
    } else {
      const line = GRAZYNA[Math.floor(Math.random() * GRAZYNA.length)];
      setMsg({ text: line, kind: "neutral" });
      if (Math.random() < 0.2) {
        useGame.getState().changeMoney(50, pid, undefined, true);
        toast(`💞 Grażyna się wzruszyła historią ${player.name} i dała 50 zł.`, "good", pid);
        sfx.coin();
      } else sfx.click();
    }
  }, onClose, pid);
  return (
    <Panel pid={pid} title="Bar „U Grażyny”" icon="🍸" footer={`Twoje szczęście: +${Math.round(player.luck * 100)}% · Upojenie: ${"🍺".repeat(Math.ceil(player.drunk)) || "trzeźwy"}`}>
      <div className="flex flex-col h-full gap-2">
        <div className="flex-1 min-h-0 overflow-hidden">
          <OptionList options={options} cursor={cursor} />
        </div>
        {msg ? <ResultBanner text={msg.text} kind={msg.kind} /> : <ResultBanner text="Alkohol daje szczęście w grach, ale utrudnia chodzenie" kind="neutral" />}
      </div>
    </Panel>
  );
}

// ─── SHOP ───
export function ShopGame({ pid, onClose }: GameProps) {
  const s = useGame();
  const player = s.players[pid];
  const [msg, setMsg] = useState<{ text: string; kind: "win" | "lose" | "neutral" } | null>(null);
  const items: { opt: Option; run: () => boolean }[] = [];
  OUTFITS.forEach((o, i) => {
    if (i === 0) return;
    items.push({ opt: { label: `👔 ${o.name}`, desc: `Prestiż +${o.prestige}`, right: fmt(o.price), disabled: s.wallet < o.price || player.avatar.outfit === i }, run: () => s.buyOutfit(pid, i) });
  });
  SHOP_HATS.forEach((h) => items.push({ opt: { label: `🎩 ${h.name}`, desc: `Prestiż +${h.prestige}`, right: fmt(h.price), disabled: s.wallet < h.price || player.avatar.hat === h.idx }, run: () => s.buyHat(pid, h.idx) }));
  SHOP_GLASSES.forEach((g) => items.push({ opt: { label: `🕶️ ${g.name}`, desc: `Prestiż +${g.prestige}`, right: fmt(g.price), disabled: s.wallet < g.price || player.avatar.glasses === g.idx }, run: () => s.buyGlasses(pid, g.idx) }));
  items.push({ opt: { label: "⛓️ Złoty łańcuch", desc: "Prestiż +5", right: fmt(5000), disabled: s.wallet < 5000 || player.avatar.chain }, run: () => s.buyChain(pid) });
  const cursor = useMenu(items.length, (i) => {
    if (items[i].opt.disabled) {
      setMsg({ text: "Sprzedawca: „Proszę nie dotykać, jeśli pan nie kupuje.”", kind: "lose" });
      sfx.lose();
      return;
    }
    if (items[i].run()) setMsg({ text: "Kupione! Wyglądasz o 3% mniej bezdomnie.", kind: "win" });
  }, onClose, pid);
  return (
    <Panel pid={pid} title="Butik „Elegancki Menel”" icon="👔" footer={`Prestiż ekipy: ${s.prestige} → +${s.prestige}% do każdej wygranej. Lepszy wygląd = mniej mandatów od ochrony.`}>
      <div className="flex flex-col h-full gap-2">
        <div className="flex-1 min-h-0 overflow-y-auto pr-1">
          <OptionList options={items.map((i) => i.opt)} cursor={cursor} compact />
        </div>
        {msg ? <ResultBanner text={msg.text} kind={msg.kind} /> : <ResultBanner text={`Aktualnie: ${OUTFITS[player.avatar.outfit].name}`} kind="neutral" />}
      </div>
    </Panel>
  );
}

// ─── PAWN SHOP ───
export function PawnGame({ pid, onClose }: GameProps) {
  const s = useGame();
  const player = s.players[pid];
  const [msg, setMsg] = useState<{ text: string; kind: "win" | "lose" | "neutral" | "big" } | null>(null);
  const items: { opt: Option; run: () => void }[] = [];
  for (const b of BODY_PARTS) {
    const has = b.key === "teeth" ? player.limbs.teeth > 0 : b.key === "dignity" ? player.limbs.dignity > 0 : player.limbs[b.key];
    if (has) {
      items.push({
        opt: { label: `🔪 Sprzedaj: ${b.name}${b.key === "teeth" ? ` (masz ${player.limbs.teeth})` : ""}`, desc: b.desc, right: `+${fmt(b.price)}`, danger: true },
        run: () => {
          if (s.sellPart(pid, b.key)) setMsg({ text: b.key === "dignity" ? "Sprzedano godność. +1 zł. Warto było." : `Sprzedano: ${b.name}. +${fmt(b.price)}. Lombardzista nawet nie mrugnął.`, kind: b.key === "dignity" ? "neutral" : "big" });
        },
      });
    } else if (b.key !== "dignity" && b.key !== "soul") {
      const price = Math.round(b.price * 1.6);
      items.push({
        opt: { label: `🩹 Odkup: ${b.name}`, desc: "Używana, lekko inna. Gwarancja 2 dni.", right: `-${fmt(price)}`, disabled: s.wallet < price },
        run: () => {
          if (!s.buyProsthetic(pid, b.key as keyof Limbs)) {
            setMsg({ text: "Za mało kasy na odkupienie. Ironia losu.", kind: "lose" });
            sfx.lose();
          } else setMsg({ text: `Odzyskałeś: ${b.name}! Pachnie dziwnie, ale działa.`, kind: "win" });
        },
      });
    }
  }
  const cursor = useMenu(items.length, (i) => items[i].run(), onClose, pid);
  return (
    <Panel pid={pid} title="Lombard „Części Zamienne”" icon="🦴" footer="Lombardzista: „Wszystko kupię. Nie pytam. Nie oddaję. No chyba że drożej.”">
      <div className="flex flex-col h-full gap-2">
        <div className="flex-1 min-h-0 overflow-y-auto pr-1">
          <OptionList options={items.map((i) => i.opt)} cursor={cursor} compact />
        </div>
        {msg ? <ResultBanner text={msg.text} kind={msg.kind} /> : <ResultBanner text="Desperacja ma swoją cenę. I to całkiem konkretną." kind="neutral" />}
      </div>
    </Panel>
  );
}

// ─── LOAN SHARK ───
const ZENEK = [
  "Zenek: „Odsetki? Jakie odsetki? To opłata za przyjaźń.”",
  "Zenek: „Mój prawnik to młotek. Bardzo przekonujący.”",
  "Zenek: „Nie oddasz? Spokojnie. Mam katalog części. Twoich.”",
  "Zenek: „Pożyczam na procent. Procent to 100. Czasem więcej.”",
];
export function LoanGame({ pid, onClose }: GameProps) {
  const s = useGame();
  const [msg, setMsg] = useState<{ text: string; kind: "win" | "lose" | "neutral" } | null>(null);
  const options: Option[] = [
    ...LOANS.map((l) => ({ label: `💰 Pożycz ${fmt(l.amount)}`, desc: `Oddajesz ${fmt(Math.round(l.amount * (1 + l.interest)))} do północy`, right: `+${Math.round(l.interest * 100)}%`, danger: true })),
    { label: "Spłać wszystko", desc: `Dług: ${fmt(s.debt)}`, right: fmt(Math.min(s.debt, s.wallet)), disabled: s.debt <= 0 || s.wallet <= 0 },
    { label: "Spłać połowę", desc: "Zenek przyjmie, ale westchnie", right: fmt(Math.min(s.debt / 2, s.wallet)), disabled: s.debt <= 0 || s.wallet <= 0 },
    { label: "Zapytaj o warunki", desc: "Niezalecane", right: "?" },
  ];
  const cursor = useMenu(options.length, (i) => {
    if (i < LOANS.length) {
      if (s.debt > 0 && i >= 2) {
        setMsg({ text: "Zenek: „Najpierw oddaj stare, potem gadamy o nowym.”", kind: "lose" });
        sfx.lose();
        return;
      }
      s.takeLoan(i);
      setMsg({ text: `Pożyczka ${fmt(LOANS[i].amount)} w kieszeni. Zenek zapisał twoje imię w notesie. Krwią.`, kind: "neutral" });
    } else if (i === LOANS.length) {
      s.repayLoan(s.debt);
      setMsg({ text: "Spłacono! Zenek chowa młotek.", kind: "win" });
    } else if (i === LOANS.length + 1) {
      s.repayLoan(Math.ceil(s.debt / 2));
      setMsg({ text: "Połowa spłacona. Zenek: „Reszta do północy, kochany.”", kind: "neutral" });
    } else {
      setMsg({ text: ZENEK[Math.floor(Math.random() * ZENEK.length)], kind: "neutral" });
      sfx.click();
    }
  }, onClose, pid);
  return (
    <Panel pid={pid} title="Lichwiarz Zenek" icon="😈" footer={s.debt > 0 ? `⚠️ DŁUG: ${fmt(s.debt)} — niespłacony o północy = Zenek zabiera części ciała` : "Brak długu. Zenek patrzy na ciebie z nadzieją."}>
      <div className="flex flex-col h-full gap-2">
        <div className="flex-1 min-h-0 overflow-hidden">
          <OptionList options={options} cursor={cursor} compact />
        </div>
        {msg ? <ResultBanner text={msg.text} kind={msg.kind} /> : <ResultBanner text="„Pożyczki 0%*” — *gwiazdka oznacza kłamstwo" kind="neutral" />}
      </div>
    </Panel>
  );
}
