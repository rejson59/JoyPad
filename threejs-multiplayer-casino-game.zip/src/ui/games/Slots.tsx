import { useEffect, useRef, useState } from "react";
import { SLOT_PAYOUT, SLOT_SYMBOLS, SLOT_WEIGHTS, fmt } from "../../game/data";
import { canUseHands, useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { BetBar, Panel, ResultBanner, useBet, type GameProps } from "../common";

function rollSymbol() {
  const total = SLOT_WEIGHTS.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < SLOT_SYMBOLS.length; i++) {
    r -= SLOT_WEIGHTS[i];
    if (r <= 0) return SLOT_SYMBOLS[i];
  }
  return SLOT_SYMBOLS[0];
}

export function Slots({ pid, onClose }: GameProps) {
  const { bet, adjust, max } = useBet();
  const changeMoney = useGame((s) => s.changeMoney);
  const winMult = useGame((s) => s.winMult);
  const wallet = useGame((s) => s.wallet);
  const player = useGame((s) => s.players[pid]);
  const hands = canUseHands(player);
  const [reels, setReels] = useState(["🍒", "🔔", "7️⃣"]);
  const [spinning, setSpinning] = useState([false, false, false]);
  const [result, setResult] = useState<{ text: string; kind: "win" | "lose" | "big" | "neutral" } | null>(null);
  const [history, setHistory] = useState<number[]>([]);
  const busy = useRef(false);
  const timers = useRef<number[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const spin = () => {
    if (busy.current) return;
    if (bet > wallet) {
      setResult({ text: "Za mało kasy! Sprzedaj coś w lombardzie…", kind: "lose" });
      sfx.lose();
      return;
    }
    busy.current = true;
    changeMoney(-bet, pid, undefined, true);
    setResult(null);
    const final = [rollSymbol(), rollSymbol(), rollSymbol()];
    setSpinning([true, true, true]);
    const iv = window.setInterval(() => {
      setReels((r) => r.map((s, i) => (spinningRef.current[i] ? SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)] : s)));
      sfx.reel();
    }, 70);
    [900, 1500, 2100].forEach((t, i) => {
      timers.current.push(
        window.setTimeout(() => {
          spinningRef.current[i] = false;
          setSpinning([...spinningRef.current]);
          setReels((r) => {
            const n = [...r];
            n[i] = final[i];
            return n;
          });
          sfx.reelStop();
          if (i === 2) {
            clearInterval(iv);
            settle(final);
          }
        }, t)
      );
    });
    spinningRef.current = [true, true, true];
  };
  const spinningRef = useRef([false, false, false]);

  const settle = (f: string[]) => {
    let mult = 0;
    let text = "";
    let kind: "win" | "lose" | "big" | "neutral" = "lose";
    if (f[0] === f[1] && f[1] === f[2]) {
      mult = SLOT_PAYOUT[f[0]] * 1.5;
      text = f[0] === "👑" ? "👑 JACKPOT KRÓLEWSKI! 👑" : f[0] === "🧦" ? "TRZY SKARPETY! Znalazłeś w nich kasę!" : `TRÓJKA ${f[0]}!`;
      kind = mult >= 40 ? "big" : "win";
    } else if (f[0] === f[1] || f[1] === f[2] || f[0] === f[2]) {
      const sym = f[0] === f[1] ? f[0] : f[1] === f[2] ? f[1] : f[0];
      mult = sym === "🧦" ? 2 : sym === "💎" || sym === "7️⃣" || sym === "👑" ? 1.6 : 1.2;
      text = `Para ${sym} — ${mult}×`;
      kind = "neutral";
    } else {
      const lines = ["Pudło. Automat śmieje się z ciebie.", "Nic. Ale za to jaki klimat!", "Przegrana. Grażyna współczująco kiwa głową.", "Automat zjadł kasę i nawet nie beknął."];
      text = lines[Math.floor(Math.random() * lines.length)];
    }
    let win = Math.round(bet * mult * winMult(pid));
    if (!hands && win > 0) win = Math.round(win * 0.8);
    if (win > 0) {
      changeMoney(win, pid, undefined, true);
      if (kind === "big") sfx.bigwin();
      else if (kind === "win") sfx.coins();
      else sfx.coin();
      text += `  +${fmt(win)}`;
    } else sfx.lose();
    setResult({ text, kind });
    setHistory((h) => [win - bet, ...h].slice(0, 8));
    busy.current = false;
  };

  useInput(pid, (a) => {
    if (a === "cancel") {
      if (!busy.current) {
        sfx.back();
        onClose();
      }
    } else if (a === "left") adjust(-1);
    else if (a === "right") adjust(1);
    else if (a === "action") spin();
  });

  return (
    <Panel pid={pid} title="Automat" icon="🎰" footer={!hands ? "🦾 Bez rąk? Bramkarz ciągnie za dźwignię za ciebie. Prowizja 20%." : "3 jednakowe = wielka wygrana · 👑👑👑 = JACKPOT 300×"}>
      <div className="flex flex-col h-full gap-3">
        <div className="relative flex-1 min-h-0 rounded-2xl p-3 flex items-center justify-center gap-3" style={{ background: "radial-gradient(ellipse at top, #3a0f5a, #150525)", border: "4px solid #d4a017", boxShadow: "inset 0 0 40px #000, 0 0 30px #ff2bd655" }}>
          {reels.map((s, i) => (
            <div key={i} className={`flex-1 max-w-[110px] aspect-[3/4] rounded-xl bg-gradient-to-b from-white via-amber-50 to-amber-100 flex items-center justify-center text-5xl md:text-6xl shadow-inner border-4 ${spinning[i] ? "border-pink-400 reel-blur" : "border-amber-400"}`}>
              {s}
            </div>
          ))}
          <div className="absolute left-2 right-2 top-1/2 h-0.5 bg-red-500/70 pointer-events-none" />
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-yellow-400 text-black text-xs font-black tracking-widest">{["SKARPETA", "WIŚNIOWY", "SIÓDEMKA", "DIAMENT"][pid % 4]} JACKPOT</div>
        </div>
        {result ? <ResultBanner text={result.text} kind={result.kind} /> : <ResultBanner text={busy.current ? "KRĘCI SIĘ…" : "Naciśnij akcję, by zakręcić"} kind="neutral" />}
        <BetBar bet={bet} max={max} />
        <div className="flex gap-1 justify-center flex-wrap text-[10px]">
          {history.map((h, i) => (
            <span key={i} className={`px-1.5 py-0.5 rounded ${h >= 0 ? "bg-green-600/60" : "bg-red-700/60"} text-white`}>
              {h >= 0 ? "+" : ""}
              {Math.round(h)}
            </span>
          ))}
        </div>
      </div>
    </Panel>
  );
}
