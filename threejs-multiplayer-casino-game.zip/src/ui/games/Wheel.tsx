import { useRef, useState } from "react";
import { fmt } from "../../game/data";
import { useGame } from "../../game/store";
import { useInput } from "../../game/input";
import { sfx } from "../../game/audio";
import { BetBar, Panel, ResultBanner, useBet, type GameProps } from "../common";

const SEGS = [
  { label: "×0", color: "#333", mult: 0 },
  { label: "×2", color: "#2ecc71", mult: 2 },
  { label: "BUT", color: "#8e5a2b", mult: 0, effect: "shoe" },
  { label: "×3", color: "#3498db", mult: 3 },
  { label: "DRINK", color: "#e67e22", mult: 1, effect: "drink" },
  { label: "×0.5", color: "#7f8c8d", mult: 0.5 },
  { label: "×5", color: "#9b59b6", mult: 5 },
  { label: "ZŁODZIEJ", color: "#c0392b", mult: 0, effect: "thief" },
  { label: "×10", color: "#f1c40f", mult: 10 },
  { label: "WYRZUT", color: "#1a1a1a", mult: 0, effect: "kick" },
  { label: "×1", color: "#95a5a6", mult: 1 },
  { label: "JACKPOT", color: "#ffd700", mult: 25 },
];
const gradient = `conic-gradient(${SEGS.map((s, i) => `${s.color} ${(i / SEGS.length) * 100}% ${((i + 1) / SEGS.length) * 100}%`).join(",")})`;

export function Wheel({ pid, onClose }: GameProps) {
  const { bet, adjust, max } = useBet(4);
  const changeMoney = useGame((s) => s.changeMoney);
  const winMult = useGame((s) => s.winMult);
  const wallet = useGame((s) => s.wallet);
  const toast = useGame((s) => s.toast);
  const player = useGame((s) => s.players[pid]);
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<{ text: string; kind: "win" | "lose" | "big" | "neutral" } | null>(null);
  const angleRef = useRef(0);

  const spin = () => {
    if (spinning) return;
    if (bet > wallet) {
      setResult({ text: "Koło nie kręci się za darmo!", kind: "lose" });
      sfx.lose();
      return;
    }
    changeMoney(-bet, pid, undefined, true);
    const idx = Math.floor(Math.random() * SEGS.length);
    const seg = 360 / SEGS.length;
    const target = 360 * 5 + (360 - (idx * seg + seg / 2));
    angleRef.current = Math.floor(angleRef.current / 360) * 360 + target;
    setAngle(angleRef.current);
    setSpinning(true);
    setResult(null);
    const ticks = setInterval(() => sfx.wheelTick(), 100);
    setTimeout(() => clearInterval(ticks), 3800);
    setTimeout(() => {
      const s = SEGS[idx];
      const st = useGame.getState();
      if (s.effect === "shoe") {
        useGame.setState({ players: st.players.map((p) => (p.id === pid ? { ...p, shoeless: true } : p)) });
        setResult({ text: "Koło zabrało ci BUTA. Serio. Kuśtykasz.", kind: "lose" });
        toast(`👟 Koło Fortuny zabrało ${player.name} buta. Takie są zasady.`, "bad", pid);
        sfx.lose();
      } else if (s.effect === "drink") {
        useGame.setState({ players: st.players.map((p) => (p.id === pid ? { ...p, luck: Math.min(0.6, p.luck + 0.15), luckTimer: 60, drunk: Math.min(3, p.drunk + 0.5) } : p)) });
        const w = Math.round(bet * winMult(pid));
        changeMoney(w, pid, undefined, true);
        setResult({ text: `Darmowy drink + zwrot stawki! +15% szczęścia  +${fmt(w)}`, kind: "win" });
        sfx.drink();
      } else if (s.effect === "thief") {
        const loss = Math.round(st.wallet * 0.15);
        changeMoney(-loss, pid, undefined, true);
        setResult({ text: `KIESZONKOWIEC! Zwinął ${fmt(loss)} ze wspólnego portfela!`, kind: "lose" });
        toast(`🕵️ Kieszonkowiec przy kole okradł ekipę na ${fmt(loss)}. Dzięki, ${player.name}.`, "bad", pid);
        sfx.alarm();
      } else if (s.effect === "kick") {
        setResult({ text: "WYRZUT! Bramkarz wynosi cię za drzwi.", kind: "lose" });
        toast(`🚪 Koło zdecydowało: ${player.name} leci za drzwi.`, "bad", pid);
        sfx.alarm();
        setTimeout(() => {
          useGame.setState({ players: useGame.getState().players.map((p) => (p.id === pid ? { ...p, kickTo: [0, 12], kickSeq: p.kickSeq + 1, activity: null } : p)) });
        }, 1500);
      } else {
        const w = Math.round(bet * s.mult * winMult(pid));
        if (w > 0) changeMoney(w, pid, undefined, true);
        if (s.mult >= 10) {
          setResult({ text: `${s.label}!!! +${fmt(w)}`, kind: "big" });
          sfx.bigwin();
          if (s.mult >= 25) toast(`🎡 ${player.name} trafił JACKPOT na Kole Fortuny! +${fmt(w)}`, "epic", pid);
        } else if (s.mult > 1) {
          setResult({ text: `${s.label} — wygrana +${fmt(w)}`, kind: "win" });
          sfx.coins();
        } else if (s.mult === 1) {
          setResult({ text: "×1. Nic nie zyskałeś, nic nie straciłeś. Jak w życiu.", kind: "neutral" });
          sfx.coin();
        } else if (s.mult === 0.5) {
          setResult({ text: `Połowa stawki wraca. +${fmt(w)}`, kind: "neutral" });
          sfx.coin();
        } else {
          setResult({ text: "×0. Koło powiedziało NIE.", kind: "lose" });
          sfx.lose();
        }
      }
      setSpinning(false);
    }, 4300);
  };

  useInput(pid, (a) => {
    if (a === "cancel") {
      if (!spinning) {
        sfx.back();
        onClose();
      }
      return;
    }
    if (spinning) return;
    if (a === "left") adjust(-1);
    else if (a === "right") adjust(1);
    else if (a === "action") spin();
  });

  return (
    <Panel pid={pid} title="Koło Fortuny" icon="🎯" footer="Absurdalne nagrody i kary. Stawka ×4 minimalnego zakładu.">
      <div className="flex h-full gap-3">
        <div className="w-[48%] flex items-center justify-center">
          <div className="relative w-full aspect-square max-w-[260px]">
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-10 w-0 h-0 border-l-[12px] border-r-[12px] border-t-[24px] border-l-transparent border-r-transparent border-t-red-500 drop-shadow-lg" />
            <div className="absolute inset-0 rounded-full border-[8px] border-yellow-500 shadow-2xl" style={{ background: gradient, transform: `rotate(${angle}deg)`, transition: spinning ? "transform 4.2s cubic-bezier(0.12, 0.8, 0.15, 1)" : "none", boxShadow: "0 0 40px #ffd84d66, inset 0 0 30px #0008" }}>
              {SEGS.map((s, i) => (
                <div key={i} className="absolute left-1/2 top-1/2 text-[10px] font-black text-white drop-shadow" style={{ transform: `rotate(${(i / SEGS.length) * 360 + 360 / 24}deg) translateY(-105px) translateX(-50%)`, transformOrigin: "0 0", textShadow: "0 1px 2px #000" }}>
                  {s.label}
                </div>
              ))}
            </div>
            <div className="absolute inset-[38%] rounded-full bg-gradient-to-br from-yellow-200 to-yellow-600 border-4 border-yellow-800 shadow-inner flex items-center justify-center text-2xl">🎰</div>
          </div>
        </div>
        <div className="flex-1 flex flex-col gap-2 justify-end min-w-0">
          <div className="grid grid-cols-3 gap-1 text-[10px]">
            {SEGS.map((s, i) => (
              <div key={i} className="rounded px-1.5 py-1 text-white font-bold text-center" style={{ background: s.color + "cc" }}>
                {s.label}
              </div>
            ))}
          </div>
          <div className="flex-1" />
          {result ? <ResultBanner text={result.text} kind={result.kind} /> : <ResultBanner text={spinning ? "KRĘCI SIĘ…" : "Naciśnij akcję, by zakręcić"} kind="neutral" />}
          <BetBar bet={bet} max={max} />
        </div>
      </div>
    </Panel>
  );
}
